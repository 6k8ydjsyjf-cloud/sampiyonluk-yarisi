import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.noventra.belgecep.ogg',
  appName: 'BelgeCep ÖGG',
  webDir: 'dist',
  backgroundColor: '#070B14',
  android: {
    backgroundColor: '#070B14',
  },
  plugins: {
    // Capacitor 8: durum/gezinme çubuğu boşlukları --safe-area-inset-* CSS değişkenleriyle verilir (theme.css --safe-top).
    SystemBars: { insetsHandling: 'css', style: 'DARK' },
  },
};

export default config;
