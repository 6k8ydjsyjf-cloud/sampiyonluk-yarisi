# BelgeCep ÖGG — v1.6.1

Özel güvenlik (ÖGG) sınavına hazırlık uygulaması. React + TypeScript + Vite + Capacitor 8. Tamamen çevrimdışı çalışır, sunucusu yoktur.

## Kurulum (yalnızca telefondan: Working Copy + GitHub Actions)

1. **Yeni repo:** GitHub'da `belgecep-ogg` adında bir repo aç. Bu klasörün içeriğini Working Copy ile reponun köküne koy ve gönder (push).
2. **Paket sürümü:** `package.json` içindeki `@capgo/native-purchases` sürümünü Torpido'nun `package.json` dosyasındakiyle aynı yap. Torpido'da çalışan sürüm en güvenli sürümdür.
3. **İmza anahtarları:** Torpido reposundaki şu 4 secret'ı bu repoya da ekle (Settings › Secrets and variables › Actions): `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Torpido'da isimler farklıysa `.github/workflows/android.yml` içindeki "AAB imzala" adımında isimleri değiştir. Aynı upload anahtarını birden fazla uygulamada kullanmak Play'de serbesttir.
4. **Derleme:** Actions › "Android AAB" › Run workflow. Bittiğinde AAB dosyası Artifacts bölümünden indirilir.
   - Derleme sırasında `npm run build` önce tip kontrolünü (`tsc`) ve soru bankası doğrulamasını çalıştırır. Bir soru hatalıysa derleme durur.
5. **Gizlilik sayfası:** Repo Settings › Pages › "Deploy from branch" › `main` / `/docs`. Çıkan adresi (`https://KULLANICI.github.io/belgecep-ogg/gizlilik.html`) `src/data/meta.ts` içindeki `PRIVACY_URL` alanına yaz. `docs/gizlilik.html` içindeki `[İLETİŞİM E-POSTAN]` alanını da doldur.

## Play Console

1. **Uygulama oluştur:** Adı "BelgeCep ÖGG", dili Türkçe, Uygulama, Ücretsiz.
2. **İlk yükleme:** AAB'yi önce **Dahili test** kanalına yükle. Paket adı `com.noventra.belgecep.ogg` olur.
3. **Pro ürünü:** Para kazanma › Ürünler › **Uygulama içi ürünler** › Ürün oluştur:
   - Ürün kimliği: **`belgecep_ogg_pro`** (birebir aynı olmalı)
   - Ad: BelgeCep ÖGG Pro
   - Fiyat: 249,99 TRY
   - Durum: Etkin
4. **Lisans testi:** Ayarlar › Lisans testi bölümüne kendi Gmail adresini ekle. Böylece satın almayı para ödemeden test edebilirsin.
5. **Formlar:**
   - Veri güvenliği formu: veri toplanmıyor.
   - İçerik derecelendirmesi: Eğitim.
   - Hedef kitle: 18 yaş ve üstü.
   - Reklam: yok.
6. **Mağaza başlığı önerisi:** "BelgeCep ÖGG – Özel Güvenlik Sınav Koçu".
7. **Sürüm yükseltme:** Önceki sürüm yüklüyse yenisini aynı kanala yükle. Eski kullanıcıların verisi (deneme geçmişi, yanlış defteri, Pro) otomatik taşınır.

## Yapı

```
src/
  data/bank/*.ts      Soru bankası, ders başına bir dosya (doğru cevap her zaman o[0], ekranda karıştırılır)
  data/questions.ts   Tüm dersleri birleştirir
  data/meta.ts        Fiyat, ürün kimliği, 13 ders, deneme formatları ve dağılımı, sınav tarihleri, limitler
  lib/engine.ts       Sınav motoru (deneme dizme, puanlama, bölüm barajı, akıllı tekrar)
  lib/selectors.ts    İstatistik, seri, hazırlık puanı
  lib/storage.ts      Cihaz içi kayıt (bozuk/eski veride çökmez, v1 verisini taşır)
  lib/billing.ts      Google Play satın alma (tüm hatalar yakalanır)
  lib/native.ts       Paylaş, Android geri tuşu
  lib/report.ts       Soru hata bildirimi
  screens/            Ana sayfa, Konular, Denemeler, İstatistik, Profil, Tekrar defteri, Sınav, Sonuç, Pro
scripts/validate-bank.mjs  Soru bankası denetleyicisi
assets/               İkon + açılış ekranı kaynakları (derlemede otomatik üretilir)
docs/gizlilik.html    Gizlilik politikası (GitHub Pages)
```

## Yeni soru eklemek

İlgili dersin `src/data/bank/*.ts` dosyasında dizinin **sonuna** ekle. Kurallar:
- Kimlik dizideki sıradan otomatik üretilir (`yg-048` gibi); bu yüzden araya ekleme, silme yapma. Hatalı bir soruyu kaldırmak için kimliğini dosyanın sonundaki `build(...)` çağrısına 4. parametre olarak verilen `retired` listesine yaz (örn. `build('yangin', 'yg', rows, ['yg-012'])`).
- Doğru cevap ilk şık olmalı; yanlış şıklar doğru cevapla benzer uzunlukta olmalı.
- 5 şık olmalı; "hepsi" veya "hiçbiri" tipi şık kullanılmamalı.
- Alt konu, zorluk (1-3), açıklama ve dayanak zorunlu; hukuk sorularında dayanakta `md. X` bulunmalı.

`npm run validate` bu kuralları kontrol eder.

Yeni sınav tarihi ilan edilince `src/data/meta.ts` › `EXAM_DATES` dizisine ekle.

## v1.6.1'de neler var

- Silahlı deneme puanı Yönetmelik md. 39'a (RG 04.07.2025) göre: her kısım ayrı ayrı 100 üzerinden, silahlıda iki yazılı kısım ayrı ayrı en az 60. Ekrandaki puan resmî %50 genel / %25 silah bilgisi oranıyla (atış ölçülemediği için 2:1) hesaplanır; sonuç ekranında atış şartı açıklanır.
- Cep mevzuatına "Sınavda başarı ve puanlama" kartı, bankaya 3 soru (toplam 861).
- Mevzuat kartları ezilme hatası düzeltildi (ekran sütununda kartlar küçülmez).

## v1.6.0'da neler var

- **Karıştırılan konular** (Konular → araçlar, ücretsiz): sınavda birbirinin yerine şık olarak verilen 12 kavram grubu (kama/hat/çember, genel/özel kolluk, empati/sempati, yangın sınıfları, yakalama halleri, emanete alma, kimlik sorma yerleri, grup aşamaları ve türleri, altı şapka, problem çözme, X-ray renkleri). Fark tek satırda, ardından o gruptan 10 soruluk ayırt etme testi. Veri: `src/data/confusables.ts`.
- **Cep mevzuatı** (ücretsiz, internetsiz): 5188 md. 7, 8, 9, 10, 12, 14 ve İş Kanunu çalışma süreleri; her kartta dayanak ve "bu konudan soru çöz". Veri: `src/data/mevzuat.ts`.
- **Kimlik kartı takibi** (Profil, ücretsiz): bitiş tarihi ya da sınavı geçilen tarih (+5 yıl) girilir; 180/90/30/7 gün kala bildirim, 180 günden az kalınca ana sayfada uyarı.
- **Dinleme modu (Pro)**: soru ve şıklar okunur, 4 saniye düşünme süresi, ardından doğru cevap ve açıklama. Kaynak: karışık, tekrar defteri veya tek ders; üç hız. Android'de `@capacitor-community/text-to-speech` (cihazın Türkçe sesi); Türkçe ses yoksa ses ayarlarını açma düğmesi çıkar. Okuma sırasında ekran açık kalmalı.
- 10 yeni soru (toplam 858), karıştırılan grupların her birinde en az 4 soru olsun diye.
- Elle girilen sınav tarihi hesabında saat bilgisi testlerle tutarlı hâle getirildi.

## v1.5.1'de neler var

- Uygulama adı her yerde **BelgeCep ÖGG** (paket kimliği `com.noventra.belgecep.ogg` ve kayıt anahtarları değişmedi; Play kaydı ve kullanıcı verisi etkilenmez).
- Pro açıkları kapatıldı: istatistik sıfırlama ve yedek geri yükleme günlük ücretsiz hakları sıfırlamıyor; Pro'suz kullanıcı yarım kalmış ikiz denemeyi sürdüremiyor; tekrar defterinde Silah Bilgisi soru metni gizli.
- Üst boşluk: Capacitor 8 SystemBars (`insetsHandling: 'css'`) değişkeni önce okunuyor, durum çubuğu boşluğu iki kez eklenmiyor; ekran üst dolgusu 16→8 px; sayfa dışı kaydırma kapatıldı.
- Her ekranın altında "BelgeCep ÖGG · Noventra Studios" imzası.

## v1.5.0'da neler var

- **Geçmiş sınav analizi** (Denemeler → Geçmiş sınav analizi): 121–122. Temel, 97–98. Yenileme ve iki tarihsiz kitapçığın 600 ortak sorusu tek tek okunup derslere ayrıldı. Ekranda ortalama ve kitapçık bazında ders dağılımı, en sık çıkan 16 konu (doğrudan konu testine bağlı) görünür. Veriler `src/data/exams.ts` dosyasındadır; soru bankasından ayrıdır ve kitapçık sorularının metnini içermez.
- **İkiz deneme (Pro)**: seçilen dönemin birebir ders dağılımı ve resmî süresiyle, bankadaki özgün sorulardan silahsız (100) veya silahlı (125) deneme.
- **Deneme ağırlıkları gerçek sınavlara göre düzeltildi**: hukuk 21, iletişim 13, tedbir 12, kalabalık 10, ilk yardım 10, kolluk 8, koruma 8, yangın 8, sistem 6, uyuşturucu 2, olay yeri 2. Mesleki Davranış bu kitapçıklarda ayrı blok olarak çıkmadığı için denemeye girmez (konu çalışmasında durur).
- **38 yeni soru (toplam 848)**: kitapçıklarda olup bankada karşılığı olmayan yeni modüller için — grup dinamiği ve grup gelişim aşamaları, müdahale düzenleri (kama/hat/çember), problem çözme (PUKO, 5N1K, balık kılçığı, altı şapka), ÖGDB projeleri (KAAN, ÖGNET, PATBİS, ÖZGE), çalışma hayatı (4857 md. 41, 46, 63, 68, 69).
- Yeni kitapçık eklemek: kitapçıktaki 100 ortak soruyu derslere ayır, `PAST_EXAMS` listesine dağılımı ekle; birim testi toplamın 100 olduğunu ve ikiz denemenin dağılımı birebir kurduğunu doğrular.

## v1.4.0'da neler var

- **Günlük plan ve sınav koçu** (`src/lib/coach.ts`): sınava kalan gün, görülmemiş soru, bekleyen tekrar ve zayıf alt konulara göre her gün 2-4 görev; son 7 günde yoğun dönem, son günde yalnızca hafif tekrar. Önerilen günlük hedef tek dokunuşla uygulanır.
- **Madde analizi**: her sonuçta zorluk düzeyine göre başarı, puan kaybedilen alt konular ve tekrar eden hatalar; "Çalış" ile o alt konunun testi açılır.
- **Konu durumu** (İstatistik): 277 alt konu "Tekrar gerekli / Gelişiyor / Öğrenildi / Başlanmadı" olarak ayrılır.
- **Hızlı tekrar kartları**: soru → cevap → "Biliyordum / Bilmiyordum"; akıllı tekrar takvimini günceller.
- **Yedekleme**: Profil › Yedekleme. JSON dosyası olarak dışa aktarılır (Android paylaşım menüsü), dosya seçerek veya metin yapıştırarak geri yüklenir. Pro bilgisi yedeğe yazılmaz; Pro her zaman Google Play'den doğrulanır.
- **Güncellenebilir sınav takvimi ve formatı**: `docs/ogg-config.json` (GitHub Pages). Uygulama açılışta indirir, önbelleğe alır; internet yoksa son indirileni, o da yoksa uygulamadaki varsayılanı kullanır. Bozuk dosya hiç uygulanmaz. Kullanıcı Profil'den kendi sınav tarihini de girebilir.
- **Zorluk düzeyleri** yeniden sınıflandırıldı (`src/data/bank/difficulty.ts`): kolay 117, orta 622, zor 71.
- Uygulamada henüz çalışmayan hiçbir özellik ("Yakında" kartları) gösterilmez.

### Sınav takvimini veya formatını güncellemek (uygulama güncellemesi gerekmez)

`docs/ogg-config.json` dosyasını düzenleyip push et. Alanlar:
- `updated`: bugünün tarihi (YYYY-MM-DD)
- `examDates`: `[{ "name": "125. Dönem Temel Eğitim Sınavı", "date": "2027-02-21" }]`
- `formats`: her tür için `common` (ortak soru), `silah`, `minutes`, `pass` (baraj). EGM 80 + 20 formatına geçerse yalnızca burayı değiştir; ders dağılımı otomatik ölçeklenir.
- `notice` (isteğe bağlı, en fazla 200 karakter): ana sayfada gösterilecek duyuru.
`src/data/meta.ts` › `CONFIG_URL` adresini kendi GitHub Pages adresinle güncelle.

## v1.3.0'da neler var

- **Soru bankası 810 soruya çıktı (+274):** hukuk 139, güvenlik tedbirleri 65, sistem ve cihazlar 57, genel kolluk 50, iletişim 50, kalabalık 46, kişi koruma 50, uyuşturucu 45, yangın 65, ilk yardım 85, olay yeri 50, mesleki davranış 48, silah bilgisi 60.
- Yeni hukuk soruları CMK, TCK, Anayasa, KVKK ve TBK maddelerine dayanır; her birinde madde numarası vardır.
- Yanlış şıkların uzunluğu dengelendi: doğru cevabın belirgin şekilde en uzun şık olduğu soru oranı %36'dan %24'e indi.

## v1.2.0'da neler var

- **Seri modülü:** günlük hedef (10/20/50 soru), hedefin tutturulduğu ardışık günler, en iyi seri, 7 günlük şerit, 3-7-14-30-60-100 gün rozetleri, hedef dolunca kutlama. Gün kaydı kalıcıdır (400 gün), 50 oturumluk geçmiş sınırından etkilenmez.
- **Yerel bildirimler** (`@capacitor/local-notifications`, sunucu/Firebase yok): günlük hedef ve seri, akıllı tekrar (en az 5 soru birikince), sınava 30/7/3/1 gün kala ve sınav sabahı 08:00. Günde en fazla 1, öncelik sınav > tekrar > hedef. Bugünün hedefi tamamsa o gün yalnızca sınav bildirimi gider. 14 gün ileriye planlanır; uygulama her açıldığında ve her oturum sonunda yeniden kurulur.
- İzin ilk deneme bitince sorulur; Profil'den saat ve türler değiştirilebilir. Bildirime dokununca ilgili ekran açılır.
- CI, bildirim ikonunu (`resources/android/ic_stat_belgecep.xml`) ve Android 13 `POST_NOTIFICATIONS` iznini otomatik ekler. Tam zamanlı alarm izni (`SCHEDULE_EXACT_ALARM`) bilerek eklenmedi; Play'de ek beyan gerektirir. Bu yüzden Android bildirimi birkaç dakika gecikmeli gösterebilir.
- Play Console: Veri güvenliği formu değişmez (veri toplanmıyor).

## v1.1.0'da neler var

- **536 soru, 13 ders (v1.1):** yürürlükteki müfredatın 12 ortak dersi + Silah Bilgisi ve Atış. Her soruda alt konu, zorluk, dayanak ve son kontrol tarihi var.
- **3 deneme türü:** Silahsız (100 soru · 120 dk, ücretsiz günde 2), Silahlı (100 + 25 · 150 dk, Pro), Silah farkı (25 · 30 dk, Pro). Sorular derslere `DENEME_WEIGHTS` dağılımıyla gelir; daha az görülen sorular önce seçilir.
- **Silahlı denemede bölüm barajı:** ortak ve silah bölümünün ikisinde de 60 aranır (hazırlıkta güvenli taraf).
- **Akıllı tekrar:** yanlış/boş sorular 1-3-7-14-30 gün aralıkla geri gelir, son aşamada da doğruysa defterden çıkar.
- **İstatistik:** hazırlık puanı (geçme olasılığı değil), son denemeler grafiği, son 14 gün, seri, ders bazında başarı.
- **Favoriler, alt konu testleri, hata bildirimi.** 5 sekmeli menü.

## Yayından önce doldurulacaklar

- `src/data/meta.ts` › `PRIVACY_URL`: gizlilik sayfanın gerçek adresi.
- `src/data/meta.ts` › `SUPPORT_EMAIL`: hata bildirimlerinin geleceği e-posta. Boş kalırsa "Hata bildir" paylaşım menüsünü açar (çalışır ama sana ulaşmaz).
- `docs/gizlilik.html` › `[İLETİŞİM E-POSTAN]`.

## Bilinen sınırlar

- Çıkmış sınav simülasyonu "Yakında" olarak işaretli; Pro ekranında da "yakında" diye yazıyor, satılan bir özellik gibi gösterilmiyor.
- Temmuz 2025 yönetmelik değişikliğinde 80 + 20 soru formatı geçiyor, ancak 2026 sınavları hâlâ 100 + 25 olarak duyuruluyor. EGM yeni formata geçerse `EXAM_FORMATS` ve `DENEME_WEIGHTS` güncellenmeli.
- Deneme ders dağılımı resmî değildir; müfredat ağırlığına göre yaklaşık belirlenmiştir.
- İade yapılan satın alımlarda Pro otomatik olarak kapatılmaz. Yanlışlıkla Pro'nun kapanma riskine karşı bilinçli bir tercih.
