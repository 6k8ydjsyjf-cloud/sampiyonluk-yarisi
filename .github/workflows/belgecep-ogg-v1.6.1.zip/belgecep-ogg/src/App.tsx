import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { ActiveSession, NotifSettings, Question, SavedState, SrsItem, TopicId, Variant } from './data/types';
import { QUESTIONS } from './data/questions';
import {
  FREE_DENEME_PER_DAY, FREE_STUDY_PER_DAY, PRO_FALLBACK_PRICE, TOPIC_TEST_SIZE, topicName,
} from './data/meta';
import { pastExam, type PastExam } from './data/exams';
import PastExamScreen from './screens/PastExamScreen';
import ConfusablesScreen from './screens/ConfusablesScreen';
import MevzuatScreen from './screens/MevzuatScreen';
import ListenScreen from './screens/ListenScreen';
import type { Confusable } from './data/confusables';
import { buildDeneme, createSession, finishSession, localDateKey, sanitizeSession, updateSrs } from './lib/engine';
import { defaultState, loadState, saveState } from './lib/storage';
import { bumpUsage, dueIds, seenCounts, todayUsage } from './lib/selectors';
import { buyPro, checkOwnership, fetchProPrice, restorePro } from './lib/billing';
import { listenBackButton, listenResume } from './lib/native';
import { applyRecord, type StreakEvent } from './lib/streak';
import { listenNotifTaps, requestNotifPermission, syncNotifications } from './lib/notify';
import { examFormat, fetchConfig, loadCachedConfig } from './lib/config';
import { buildPlan, newQuestionPool, type PlanTask } from './lib/coach';
import { exportBackup, makeBackup, type ReadResult } from './lib/backup';
import { CelebrateSheet, NotifAskSheet, StreakSheet } from './components/streak';
import { reportQuestion } from './lib/report';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ConfirmSheet, Toast } from './components/ui';
import { IconChart, IconExam, IconHome, IconList, IconUser } from './components/icons';
import HomeScreen from './screens/HomeScreen';
import TopicsScreen from './screens/TopicsScreen';
import ExamsScreen from './screens/ExamsScreen';
import StatsScreen from './screens/StatsScreen';
import WrongScreen from './screens/WrongScreen';
import ProfileScreen from './screens/ProfileScreen';
import SessionScreen from './screens/SessionScreen';
import ResultScreen from './screens/ResultScreen';
import ProScreen from './screens/ProScreen';
import CardsScreen from './screens/CardsScreen';
import type { SessionRecord } from './data/types';

export const BY_ID: Map<string, Question> = new Map(QUESTIONS.map((q) => [q.id, q]));

export type Tab = 'home' | 'topics' | 'exams' | 'stats' | 'profile';
const TABS: Tab[] = ['home', 'topics', 'exams', 'stats', 'profile'];
export type Route =
  | { name: Tab }
  | { name: 'session' }
  | { name: 'wrong'; ret: Tab }
  | { name: 'cards'; ret: Tab; deck: string[] }
  | { name: 'result'; id: string; ret: Tab }
  | { name: 'past'; id: string | null }
  | { name: 'confusables'; id: string | null }
  | { name: 'mevzuat' }
  | { name: 'listen' }
  | { name: 'pro'; ret: Route };

interface PendingStart { label: string; run: () => void }

/** Silah Bilgisi ve Atış soruları yalnızca Pro'da görünür. */
function allowed(q: Question, pro: boolean): boolean {
  return pro || q.topic !== 'silah';
}

/** Ücretsiz kullanıcının devam edemeyeceği oturum (Pro deneme türü ya da silah sorusu içeren) */
function sessionNeedsPro(a: ActiveSession): boolean {
  if (a.variant === 'silahli' || a.variant === 'fark') return true;
  if (a.kind === 'deneme' && / ikizi · /.test(a.title)) return true; // geçmiş sınav ikizi
  return a.qids.some((id) => BY_ID.get(id)?.topic === 'silah');
}

function isTab(r: Route): r is { name: Tab } {
  return (TABS as string[]).includes(r.name);
}

/** Yüklenen veriyi soru bankasıyla uzlaştırır (bankadan çıkarılmış soruları ayıklar). */
function reconcile(s: SavedState): SavedState {
  const active = s.active ? sanitizeSession(s.active, BY_ID) : null;
  const srs: Record<string, SrsItem> = {};
  for (const [id, v] of Object.entries(s.srs)) if (BY_ID.has(id)) srs[id] = v;
  const favs = s.favs.filter((id) => BY_ID.has(id));
  return { ...s, active, srs, favs };
}

function initialState(): SavedState {
  loadCachedConfig();
  return reconcile(loadState());
}

export default function App() {
  const [state, setState] = useState<SavedState>(initialState);
  const [route, setRoute] = useState<Route>({ name: 'home' });
  const [toast, setToast] = useState<string | null>(null);
  const [price, setPrice] = useState<string>(PRO_FALLBACK_PRICE);
  const [pending, setPending] = useState<PendingStart | null>(null);
  const [busy, setBusy] = useState(false);
  const [sessionRet, setSessionRet] = useState<Tab>('home');
  const [celebrate, setCelebrate] = useState<StreakEvent | null>(null);
  const [askNotif, setAskNotif] = useState(false);
  const [streakOpen, setStreakOpen] = useState(false);
  const [, setCfgTick] = useState(0);

  const update = useCallback((fn: (p: SavedState) => SavedState) => {
    setState((prev) => {
      const next = fn(prev);
      saveState(next);
      return next;
    });
  }, []);

  const showToast = useCallback((t: string) => setToast(t), []);
  const clearToast = useCallback(() => setToast(null), []);

  // Başlangıç: süresi dolmuş yarım sınavı kapat, fiyatı ve satın alımı kontrol et.
  useEffect(() => {
    const now = Date.now();
    setState((prev) => {
      const a = prev.active;
      if (a && a.endAt !== null && a.endAt <= now) {
        const rec = finishSession(a, BY_ID, now);
        const next: SavedState = applyRecord({ ...prev, active: null, history: [...prev.history, rec], srs: updateSrs(prev.srs, rec, localDateKey(new Date(now))) }, rec).state;
        saveState(next);
        return next;
      }
      return prev;
    });
    let alive = true;
    void fetchConfig().then((changed) => { if (alive && changed) setCfgTick((n) => n + 1); });
    void fetchProPrice().then((p) => { if (alive && p) setPrice(p); });
    void checkOwnership().then((owned) => {
      if (alive && owned === true) update((s) => (s.pro ? s : { ...s, pro: true }));
    });
    return () => { alive = false; };
  }, [update]);

  const go = useCallback((r: Route) => setRoute(r), []);
  const openPro = useCallback((ret: Route) => setRoute({ name: 'pro', ret }), []);

  // ── Oturum başlatma ──
  const beginSession = useCallback((session: ActiveSession | null, ret: Tab, usage?: { key: 'deneme' | 'study'; n: number }) => {
    if (!session) {
      showToast('Bu bölüm için henüz soru yok.');
      return;
    }
    const now = new Date();
    update((s) => {
      const withUsage = usage ? bumpUsage(s, usage.key, usage.n, now) : s;
      return { ...withUsage, active: session };
    });
    setSessionRet(ret);
    setRoute({ name: 'session' });
  }, [showToast, update]);

  const guardActive = useCallback((label: string, run: () => void) => {
    if (state.active) setPending({ label, run });
    else run();
  }, [state.active]);

  const startDeneme = useCallback((variant: Variant, ret: Tab, sim?: PastExam) => {
    const f = examFormat(variant);
    const back: Route = sim ? { name: 'past', id: sim.id } : { name: ret };
    if ((f.pro || sim) && !state.pro) { openPro(back); return; }
    if (!state.pro && todayUsage(state, 'deneme', new Date()) >= FREE_DENEME_PER_DAY) { openPro(back); return; }
    const label = sim ? `${sim.short} ikizi` : f.name;
    guardActive(label, () => {
      const pool = buildDeneme(QUESTIONS, variant, seenCounts(state), Math.random, sim?.dist);
      const title = sim ? `${sim.short} ikizi · ${variant === 'silahli' ? 'Silahlı' : 'Silahsız'} · ${pool.length} soru` : `${f.name} · ${pool.length} soru`;
      beginSession(
        createSession({ kind: 'deneme', mode: 'exam', title, pool, size: pool.length, timed: true, now: Date.now(), ordered: true, variant, durationSec: f.minutes * 60, pass: f.pass }),
        ret,
        state.pro ? undefined : { key: 'deneme', n: 1 },
      );
    });
  }, [beginSession, guardActive, openPro, state]);

  /** Çalışma modu: Pro'da sınırsız, ücretsizde günde FREE_STUDY_PER_DAY soru. */
  const studySize = useCallback((wanted: number): number => {
    if (state.pro) return wanted;
    const left = FREE_STUDY_PER_DAY - todayUsage(state, 'study', new Date());
    return Math.max(0, Math.min(wanted, left));
  }, [state]);

  const startStudy = useCallback((pool: Question[], kind: 'konu' | 'yanlis' | 'favori', title: string, ret: Tab, label: string) => {
    if (pool.length === 0) { showToast('Bu bölümde soru yok.'); return; }
    const size = studySize(Math.min(TOPIC_TEST_SIZE, pool.length));
    if (size === 0) { openPro({ name: ret }); return; }
    guardActive(label, () => beginSession(
      createSession({ kind, mode: 'study', title, pool, size, timed: false, now: Date.now(), ordered: kind === 'yanlis' }),
      ret,
      state.pro ? undefined : { key: 'study', n: size },
    ));
  }, [beginSession, guardActive, openPro, showToast, state.pro, studySize]);

  const startTopic = useCallback((topic: TopicId, mode: 'exam' | 'study', sub?: string, ret: Tab = 'topics') => {
    if (topic === 'silah' && !state.pro) { openPro({ name: ret }); return; }
    const pool = QUESTIONS.filter((q) => q.topic === topic && (sub === undefined || q.sub === sub));
    const name = sub ? `${topicName(topic)} · ${sub}` : topicName(topic);
    if (mode === 'study') { startStudy(pool, 'konu', `${name} · çalışma`, ret, 'Çalışma modu'); return; }
    if (pool.length === 0) { showToast('Bu konunun soruları yakında eklenecek.'); return; }
    guardActive('Konu testi', () => beginSession(
      createSession({ kind: 'konu', mode: 'exam', title: `${name} · konu testi`, pool, size: Math.min(TOPIC_TEST_SIZE, pool.length), timed: false, now: Date.now() }),
      ret,
    ));
  }, [beginSession, guardActive, openPro, showToast, startStudy, state.pro]);

  const startStudyAll = useCallback(() => {
    startStudy(QUESTIONS.filter((q) => q.topic !== 'silah'), 'konu', 'Karışık çalışma', 'home', 'Çalışma modu');
  }, [startStudy]);

  /** Akıllı tekrar: vadesi gelenler önce; hiç vadesi gelen yoksa defterin tamamı en yakın vadeden başlayarak. */
  const startReview = useCallback((ret: Tab) => {
    const today = localDateKey(new Date());
    const due = dueIds(state, today);
    const ids = due.length > 0
      ? due
      : Object.entries(state.srs).sort((a, b) => (a[1].due < b[1].due ? -1 : 1)).map(([id]) => id);
    const pool = ids.map((id) => BY_ID.get(id)).filter((q): q is Question => q !== undefined && allowed(q, state.pro));
    if (pool.length === 0) {
      showToast(ids.length > 0 ? 'Defterindeki sorular Silah Bilgisi dersinden; Pro ile açılır.' : 'Tekrar defterin boş.');
      return;
    }
    startStudy(pool, 'yanlis', due.length > 0 ? 'Akıllı tekrar · bugün' : 'Akıllı tekrar · erken', ret, 'Akıllı tekrar');
  }, [showToast, startStudy, state]);

  /** Planın "yeni sorular" görevi: hiç görülmemiş ortak sorulardan, zayıf dersler önde. Ücretsiz (konu testi gibi). */
  const startNew = useCallback((size: number) => {
    const pool = newQuestionPool(state, QUESTIONS);
    if (pool.length === 0) { showToast('Bankadaki tüm ortak soruları gördün. Harika!'); return; }
    guardActive('Yeni sorular', () => beginSession(
      createSession({ kind: 'konu', mode: 'exam', title: 'Günlük plan · yeni sorular', pool, size: Math.min(size, pool.length), timed: false, now: Date.now(), ordered: true }),
      'home',
    ));
  }, [beginSession, guardActive, showToast, state]);

  const onPlanTask = useCallback((t: PlanTask) => {
    if (t.kind === 'review') startReview('home');
    else if (t.kind === 'weak' && t.topic && t.sub) startTopic(t.topic, 'exam', t.sub, 'home');
    else if (t.kind === 'new') startNew(t.size ?? 20);
    else if (t.kind === 'deneme') startDeneme('silahsiz', 'home');
  }, [startDeneme, startNew, startReview, startTopic]);

  /** Hızlı tekrar kartları: önce vadesi gelen tekrarlar, sonra defterin kalanı, sonra yanlış yapılmış sorular. */
  const startCards = useCallback((ret: Tab) => {
    const today = localDateKey(new Date());
    const ids: string[] = [];
    const add = (id: string) => { if (!ids.includes(id) && BY_ID.has(id) && (state.pro || BY_ID.get(id)?.topic !== 'silah')) ids.push(id); };
    dueIds(state, today).forEach(add);
    Object.entries(state.srs).sort((a, b) => (a[1].due < b[1].due ? -1 : 1)).forEach(([id]) => add(id));
    Object.entries(state.qstats).filter(([, v]) => v.w > 0).sort((a, b) => b[1].w - a[1].w).forEach(([id]) => add(id));
    if (ids.length === 0) { showToast('Kart oluşturmak için önce soru çöz; yanlış yaptığın sorular karta dönüşür.'); return; }
    const size = studySize(Math.min(20, ids.length));
    if (size === 0) { openPro({ name: ret }); return; }
    if (!state.pro) update((s) => bumpUsage(s, 'study', size, new Date()));
    setRoute({ name: 'cards', ret, deck: ids.slice(0, size) });
  }, [openPro, showToast, state, studySize, update]);

  const gradeCard = useCallback((qid: string, knew: boolean) => {
    const now = Date.now();
    const pseudo: SessionRecord = { id: 'kart', kind: 'yanlis', mode: 'study', title: '', finishedAt: now, total: 1, correct: knew ? 1 : 0, blank: 0, score: 0, passed: false, durationSec: 0, topicStats: {}, qids: [qid], answers: [knew ? 0 : 1] };
    update((s) => ({ ...s, srs: updateSrs(s.srs, pseudo, localDateKey(new Date(now))) }));
  }, [update]);

  const startFavs = useCallback(() => {
    const pool = state.favs.map((id) => BY_ID.get(id)).filter((q): q is Question => q !== undefined && allowed(q, state.pro));
    if (pool.length === 0) {
      showToast(state.favs.length > 0 ? 'Favorilerindeki Silah Bilgisi soruları Pro ile açılır.' : 'Henüz favori sorun yok. Soru ekranındaki yıldızla ekleyebilirsin.');
      return;
    }
    startStudy(pool, 'favori', 'Favori sorular', 'topics', 'Favori sorular');
  }, [showToast, startStudy, state.favs, state.pro]);

  const toggleFav = useCallback((id: string) => {
    const adding = !state.favs.includes(id);
    update((s) => {
      const has = s.favs.includes(id);
      return { ...s, favs: has ? s.favs.filter((x) => x !== id) : [...s.favs, id] };
    });
    showToast(adding ? 'Favorilere eklendi.' : 'Favorilerden çıkarıldı.');
  }, [showToast, state.favs, update]);

  const report = useCallback(async (q: Question) => {
    const r = await reportQuestion(q);
    if (r === 'copied') showToast('Bildirim metni panoya kopyalandı.');
    else if (r === 'failed') showToast('Bildirim açılamadı.');
  }, [showToast]);

  // ── Oturum içi ──
  const patchActive = useCallback((fn: (a: ActiveSession) => ActiveSession) => {
    update((s) => (s.active ? { ...s, active: fn(s.active) } : s));
  }, [update]);

  const finishActive = useCallback(() => {
    const a = state.active;
    if (!a) { setRoute({ name: 'home' }); return; }
    const now = Date.now();
    const rec = finishSession(a, BY_ID, now);
    const today = localDateKey(new Date(now));
    const next = (s: SavedState) => applyRecord({ ...s, active: null, history: [...s.history, rec], srs: updateSrs(s.srs, rec, today) }, rec);
    const { event } = next(state);
    update((s) => next(s).state);
    setRoute({ name: 'result', id: rec.id, ret: sessionRet });
    if (event) setCelebrate(event);
    if (!state.notifAsked && !state.notif.on && rec.kind === 'deneme') setAskNotif(true);
  }, [sessionRet, state, update]);

  // ── Seri ve bildirim ayarları ──
  const setGoal = useCallback((goal: number) => {
    const today = localDateKey(new Date());
    update((s) => {
      const d = s.days[today];
      const days = d && !d.met && d.n >= goal ? { ...s.days, [today]: { ...d, met: true } } : s.days;
      return { ...s, goal, days };
    });
  }, [update]);

  const setNotif = useCallback(async (patch: Partial<NotifSettings>) => {
    if (patch.on === true) {
      const ok = await requestNotifPermission();
      if (!ok) {
        update((s) => ({ ...s, notifAsked: true }));
        showToast('Bildirim izni verilmedi. Telefon ayarlarından BelgeCep ÖGG bildirimlerini açabilirsin.');
        return;
      }
    }
    update((s) => ({ ...s, notifAsked: true, notif: { ...s.notif, ...patch } }));
    if (patch.on === true) showToast('Hatırlatmalar açıldı.');
  }, [showToast, update]);

  // Bildirim planı: ilgili veri değiştikçe yeniden kurulur.
  useEffect(() => {
    void syncNotifications(state, new Date());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.notif, state.days, state.srs, state.goal]);

  const discardActive = useCallback(() => {
    update((s) => ({ ...s, active: null }));
  }, [update]);

  // ── Satın alma ──
  const purchase = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await buyPro();
      if (r.ok) {
        update((s) => ({ ...s, pro: true }));
        showToast('Pro açıldı. İyi çalışmalar!');
        setRoute((cur) => (cur.name === 'pro' ? cur.ret : cur));
      } else if (r.reason !== 'cancelled') {
        showToast(r.message);
      }
    } finally {
      setBusy(false);
    }
  }, [busy, showToast, update]);

  const restore = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await restorePro();
      if (r === true) { update((s) => ({ ...s, pro: true })); showToast('Pro satın alımın geri yüklendi.'); }
      else if (r === false) showToast('Bu Google hesabında Pro satın alımı bulunamadı.');
      else showToast('Şu an kontrol edilemedi. İnternet bağlantını kontrol edip tekrar dene.');
    } finally {
      setBusy(false);
    }
  }, [busy, showToast, update]);

  // ── Yedekleme ──
  const doExport = useCallback(async () => {
    const now = new Date();
    const r = await exportBackup(makeBackup(state, now), now);
    if (r === 'shared' || r === 'downloaded' || r === 'copied') {
      update((s) => ({ ...s, lastBackup: now.getTime() }));
      showToast(r === 'copied' ? 'Yedek metni panoya kopyalandı; güvenli bir yere yapıştır.' : 'Yedek dosyası hazırlandı.');
    } else if (r === 'failed') {
      showToast('Yedek oluşturulamadı. Tekrar dene.');
    }
  }, [showToast, state, update]);

  const doImport = useCallback((r: Extract<ReadResult, { ok: true }>) => {
    // Ücretsiz günlük haklar yedekten geri gelmez: cihazdaki bugünkü kullanım korunur.
    update((s) => ({ ...reconcile(r.state), pro: s.pro, lastBackup: s.lastBackup, daily: s.daily }));
    showToast('Yedek geri yüklendi.');
    setRoute({ name: 'home' });
  }, [showToast, update]);

  /** Karıştırılan konular: gruptaki sorulardan konu testi (ücretsiz, konu testi gibi). */
  const startDrill = useCallback((c: Confusable, pool: Question[]) => {
    const allowedPool = pool.filter((q) => allowed(q, state.pro));
    if (allowedPool.length === 0) { showToast('Bu grupta soru yok.'); return; }
    guardActive('Karıştırılan konular', () => beginSession(
      createSession({ kind: 'konu', mode: 'exam', title: `${c.title} · ayırt etme testi`, pool: allowedPool, size: Math.min(10, allowedPool.length), timed: false, now: Date.now() }),
      'topics',
    ));
  }, [beginSession, guardActive, showToast, state.pro]);

  const openListen = useCallback(() => {
    if (!state.pro) { openPro({ name: 'topics' }); return; }
    setRoute({ name: 'listen' });
  }, [openPro, state.pro]);

  const setCardExpiry = useCallback((date: string | null) => {
    update((s) => ({ ...s, cardExpiry: date }));
  }, [update]);

  const setExamDate = useCallback((date: string | null) => {
    update((s) => ({ ...s, examDate: date }));
  }, [update]);

  const resetStats = useCallback(() => {
    update((s) => ({ ...defaultState(), pro: s.pro, favs: s.favs, goal: s.goal, notif: s.notif, notifAsked: s.notifAsked, examDate: s.examDate, lastBackup: s.lastBackup, daily: s.daily, cardExpiry: s.cardExpiry }));
    showToast('İstatistikler sıfırlandı.');
  }, [showToast, update]);

  // ── Android geri tuşu ──
  const routeRef = useRef(route);
  routeRef.current = route;
  const pendingRef = useRef(pending);
  pendingRef.current = pending;
  const sessionBackRef = useRef<(() => boolean) | null>(null);
  const overlayRef = useRef<(() => void) | null>(null);
  overlayRef.current = celebrate ? () => setCelebrate(null) : askNotif ? () => { setAskNotif(false); update((s) => ({ ...s, notifAsked: true })); } : streakOpen ? () => setStreakOpen(false) : null;
  const screenBackRef = useRef<(() => boolean) | null>(null);

  useEffect(() => {
    let remove: (() => void) | null = null;
    let cancelled = false;
    void listenBackButton(() => {
      if (pendingRef.current) { setPending(null); return true; }
      if (overlayRef.current) { overlayRef.current(); return true; }
      if (screenBackRef.current && screenBackRef.current()) return true;
      const r = routeRef.current;
      if (r.name === 'session') return sessionBackRef.current ? sessionBackRef.current() : true;
      if (r.name === 'pro') { setRoute(r.ret); return true; }
      if (r.name === 'result' || r.name === 'wrong' || r.name === 'cards') { setRoute({ name: r.ret }); return true; }
      if (r.name === 'confusables') { setRoute(r.id ? { name: 'confusables', id: null } : { name: 'topics' }); return true; }
      if (r.name === 'mevzuat' || r.name === 'listen') { setRoute({ name: 'topics' }); return true; }
      if (r.name === 'past') { setRoute(r.id ? { name: 'past', id: null } : { name: 'exams' }); return true; }
      if (r.name !== 'home') { setRoute({ name: 'home' }); return true; }
      return false;
    }).then((fn) => {
      if (cancelled) fn(); else remove = fn;
    });
    return () => { cancelled = true; if (remove) remove(); };
  }, []);

  const stateRef = useRef(state);
  stateRef.current = state;
  useEffect(() => {
    const removers: (() => void)[] = [];
    let cancelled = false;
    const keep = (fn: () => void) => { if (cancelled) fn(); else removers.push(fn); };
    void listenResume(() => {
      setState((s) => ({ ...s })); // gün değişmiş olabilir: ekranlar ve bildirim planı tazelenir
      void syncNotifications(stateRef.current, new Date());
    }).then(keep);
    void listenNotifTaps((kind) => {
      if (routeRef.current.name === 'session') return;
      if (kind === 'review') setRoute({ name: 'wrong', ret: 'home' });
      else if (kind === 'exam') setRoute({ name: 'exams' });
      else if (kind === 'card') setRoute({ name: 'profile' });
      else setRoute({ name: 'home' });
    }).then(keep);
    return () => { cancelled = true; removers.forEach((f) => f()); };
  }, []);

  const tab: Tab | null = isTab(route) ? route.name : null;
  const activeValid = useMemo(() => (state.active ? sanitizeSession(state.active, BY_ID) : null), [state.active]);
  const favSet = useMemo(() => new Set(state.favs), [state.favs]);

  let body: ReactNode;
  if (route.name === 'session') {
    body = activeValid ? (
      <SessionScreen
        session={activeValid}
        byId={BY_ID}
        favs={favSet}
        backRef={sessionBackRef}
        onPatch={patchActive}
        onFinish={finishActive}
        onExit={() => setRoute({ name: sessionRet })}
        onFav={toggleFav}
        onReport={report}
      />
    ) : <Redirect to={() => setRoute({ name: 'home' })} />;
  } else if (route.name === 'result') {
    const rec = state.history.find((r) => r.id === route.id);
    const ret = route.ret;
    body = rec ? (
      <ResultScreen
        record={rec}
        byId={BY_ID}
        isPro={state.pro}
        favs={favSet}
        qstats={state.qstats}
        onStudySub={(topic, sub) => startTopic(topic, 'exam', sub, ret)}
        onBack={() => setRoute({ name: ret })}
        onPro={() => openPro(route)}
        onReview={() => startReview(ret)}
        onFav={toggleFav}
        onReport={report}
        onToast={showToast}
      />
    ) : <Redirect to={() => setRoute({ name: 'home' })} />;
  } else if (route.name === 'pro') {
    const ret = route.ret;
    body = <ProScreen isPro={state.pro} price={price} busy={busy} onBuy={purchase} onRestore={restore} onClose={() => setRoute(ret)} />;
  } else if (route.name === 'cards') {
    const ret = route.ret;
    const deck = route.deck.map((id) => BY_ID.get(id)).filter((q): q is Question => q !== undefined);
    body = <CardsScreen deck={deck} backRef={screenBackRef} onGrade={gradeCard} onClose={() => setRoute({ name: ret })} />;
  } else if (route.name === 'wrong') {
    const ret = route.ret;
    body = (
      <WrongScreen
        state={state}
        byId={BY_ID}
        onBack={() => setRoute({ name: ret })}
        onReview={() => startReview(ret)}
        onCards={() => startCards(ret)}
        onClear={() => { update((s) => ({ ...s, srs: {} })); showToast('Tekrar defteri temizlendi.'); }}
      />
    );
  } else if (route.name === 'topics') {
    body = (
      <TopicsScreen
        bank={QUESTIONS}
        state={state}
        backRef={screenBackRef}
        onStart={startTopic}
        onFavs={startFavs}
        onPro={() => openPro({ name: 'topics' })}
        onConfusables={() => go({ name: 'confusables', id: null })}
        onMevzuat={() => go({ name: 'mevzuat' })}
        onListen={openListen}
      />
    );
  } else if (route.name === 'confusables') {
    body = <ConfusablesScreen bank={QUESTIONS} id={route.id} onOpen={(id) => setRoute({ name: 'confusables', id })} onBack={() => setRoute({ name: 'topics' })} onDrill={startDrill} />;
  } else if (route.name === 'mevzuat') {
    body = <MevzuatScreen onBack={() => setRoute({ name: 'topics' })} onPractice={(topic, sub) => startTopic(topic, 'exam', sub, 'topics')} />;
  } else if (route.name === 'listen') {
    body = state.pro ? <ListenScreen bank={QUESTIONS} state={state} onBack={() => setRoute({ name: 'topics' })} /> : null;
  } else if (route.name === 'past') {
    const exam = route.id ? pastExam(route.id) ?? null : null;
    body = (
      <PastExamScreen
        state={state}
        exam={exam}
        onBack={() => setRoute(route.id ? { name: 'past', id: null } : { name: 'exams' })}
        onOpen={(id) => go({ name: 'past', id })}
        onSimulate={(e, v) => startDeneme(v, 'exams', e)}
        onStudy={(topic, sub) => startTopic(topic, 'exam', sub, 'exams')}
      />
    );
  } else if (route.name === 'exams') {
    body = (
      <ExamsScreen
        state={state}
        onPast={() => go({ name: 'past', id: null })}
        onStart={(v) => startDeneme(v, 'exams')}
        onOpenResult={(id) => go({ name: 'result', id, ret: 'exams' })}
        onPro={() => openPro({ name: 'exams' })}
      />
    );
  } else if (route.name === 'stats') {
    body = <StatsScreen state={state} bank={QUESTIONS} onWrong={() => go({ name: 'wrong', ret: 'stats' })} onExams={() => go({ name: 'exams' })} onStudySub={(topic, sub) => startTopic(topic, 'exam', sub, 'stats')} />;
  } else if (route.name === 'profile') {
    body = <ProfileScreen state={state} bankSize={QUESTIONS.length} busy={busy} onPro={() => openPro({ name: 'profile' })} onRestore={restore} onReset={resetStats} onNotif={setNotif} onStreak={() => setStreakOpen(true)} onExport={doExport} onImport={doImport} onExamDate={setExamDate} onCardExpiry={setCardExpiry} />;
  } else {
    body = (
      <HomeScreen
        state={state}
        onStartDeneme={() => startDeneme('silahsiz', 'home')}
        onStudy={startStudyAll}
        onReview={() => startReview('home')}
        onResume={() => {
          if (state.active && !state.pro && sessionNeedsPro(state.active)) { openPro({ name: 'home' }); return; }
          setRoute({ name: 'session' });
        }}
        onDiscard={discardActive}
        onPro={() => openPro({ name: 'home' })}
        onWrong={() => go({ name: 'wrong', ret: 'home' })}
        onCards={() => startCards('home')}
        onStreak={() => setStreakOpen(true)}
        plan={buildPlan(state, QUESTIONS, new Date())}
        onPlanTask={onPlanTask}
        onGoal={setGoal}
        onTab={(t) => setRoute({ name: t })}
      />
    );
  }

  const navBtn = (t: Tab, label: string, icon: ReactNode) => (
    <button aria-current={tab === t ? 'page' : undefined} onClick={() => setRoute({ name: t })}>{icon}{label}</button>
  );

  return (
    <ErrorBoundary onReset={() => { setRoute({ name: 'home' }); setPending(null); }}>
      <div className="app">
        {body}
        {tab && (
          <nav className="bottom-nav" aria-label="Ana menü">
            {navBtn('home', 'Ana sayfa', <IconHome />)}
            {navBtn('topics', 'Konular', <IconList />)}
            {navBtn('exams', 'Denemeler', <IconExam />)}
            {navBtn('stats', 'İstatistik', <IconChart />)}
            {navBtn('profile', 'Profil', <IconUser />)}
          </nav>
        )}
        {pending && (
          <ConfirmSheet
            title="Yarım kalan oturumun var"
            text={`"${pending.label}" başlatırsan yarım kalan oturumun silinecek.`}
            confirmLabel="Sil ve başlat"
            onConfirm={() => { const run = pending.run; setPending(null); run(); }}
            onCancel={() => setPending(null)}
          />
        )}
        {streakOpen && <StreakSheet state={state} onGoal={setGoal} onClose={() => setStreakOpen(false)} />}
        {celebrate && <CelebrateSheet event={celebrate} goal={state.goal} onClose={() => setCelebrate(null)} />}
        {!celebrate && askNotif && (
          <NotifAskSheet
            onYes={() => { setAskNotif(false); void setNotif({ on: true }); }}
            onNo={() => { setAskNotif(false); update((s) => ({ ...s, notifAsked: true })); }}
          />
        )}
        {toast && <Toast text={toast} onDone={clearToast} />}
      </div>
    </ErrorBoundary>
  );
}

function Redirect({ to }: { to: () => void }) {
  useEffect(() => { to(); }, [to]);
  return <div className="screen" />;
}
