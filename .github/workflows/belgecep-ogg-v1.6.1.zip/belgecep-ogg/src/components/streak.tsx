import type { SavedState } from '../data/types';
import { GOAL_OPTIONS, STREAK_MILESTONES } from '../data/meta';
import { localDateKey } from '../lib/engine';
import { currentStreak, streakAtRisk, weekStrip, weekdayShort, type StreakEvent } from '../lib/streak';
import { Bar, Sheet } from './ui';
import { IconCheck, IconFire } from './icons';

export function StreakCard({ state, onOpen }: { state: SavedState; onOpen: () => void }) {
  const today = localDateKey(new Date());
  const n = currentStreak(state.days, today);
  const done = state.days[today]?.n ?? 0;
  const met = state.days[today]?.met === true;
  const risk = streakAtRisk(state.days, today);
  const strip = weekStrip(state.days, today);
  const sub = met
    ? 'Bugünkü hedef tamam'
    : risk
      ? `Serin tehlikede · ${Math.max(0, state.goal - done)} soru kaldı`
      : `Bugün ${state.goal} soru çöz, seriyi başlat`;
  return (
    <button className="glass" style={{ padding: 14, textAlign: 'left', color: '#fff', display: 'flex', flexDirection: 'column', gap: 12 }} onClick={onOpen} aria-label={`Seri ${n} gün`}>
      <span className="between" style={{ width: '100%' }}>
        <span className="row" style={{ gap: 10 }}>
          <IconFire size={26} color={n > 0 ? '#FFB366' : '#A9B4C8'} />
          <span className="col" style={{ gap: 2 }}>
            <span style={{ fontSize: 17, fontWeight: 800 }}>{n} günlük seri</span>
            <span className="small" style={{ color: risk ? '#FFB366' : met ? '#6EE7A8' : 'var(--muted)' }}>{sub}</span>
          </span>
        </span>
        <span className="num muted small" style={{ fontWeight: 700 }}>{Math.min(done, state.goal)}/{state.goal}</span>
      </span>
      <Bar pct={(Math.min(done, state.goal) / state.goal) * 100} warn={!met} />
      <span className="streak-strip" style={{ width: '100%' }}>
        {strip.map((d) => (
          <span key={d.day} className={`streak-day${d.today ? ' today' : ''}`}>
            <span className={`streak-dot${d.met ? ' met' : ''}${d.today ? ' today' : ''}`}>{d.met && <IconCheck size={15} color="#1A0F05" />}</span>
            {weekdayShort(d.day)}
          </span>
        ))}
      </span>
    </button>
  );
}

export function StreakSheet({ state, onGoal, onClose }: { state: SavedState; onGoal: (g: number) => void; onClose: () => void }) {
  const today = localDateKey(new Date());
  const n = currentStreak(state.days, today);
  const best = Math.max(state.best, n);
  const metDays = Object.values(state.days).filter((d) => d.met).length;
  return (
    <Sheet title="Seri" onClose={onClose}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 8 }}>
        <div className="glass stat-tile"><span className="muted small">Şu anki</span><span className="num stat-num">{n}</span></div>
        <div className="glass stat-tile"><span className="muted small">En iyi</span><span className="num stat-num">{best}</span></div>
        <div className="glass stat-tile"><span className="muted small">Tam gün</span><span className="num stat-num">{metDays}</span></div>
      </div>
      <span className="muted small" style={{ lineHeight: 1.5 }}>
        Günlük hedefini tutturduğun her gün seriye eklenir. Bir gün atlarsan seri sıfırlanır; en iyi serin saklanır.
      </span>
      <span className="muted small" style={{ fontWeight: 700, letterSpacing: '.04em' }}>GÜNLÜK HEDEF</span>
      <div className="seg" role="group" aria-label="Günlük hedef">
        {GOAL_OPTIONS.map((g) => (
          <button key={g} aria-pressed={state.goal === g} onClick={() => onGoal(g)}>{g} soru</button>
        ))}
      </div>
      <span className="muted small" style={{ fontWeight: 700, letterSpacing: '.04em' }}>ROZETLER</span>
      <div className="badge-grid">
        {STREAK_MILESTONES.map((m) => (
          <div key={m} className={`badge${best >= m ? ' won' : ''}`} aria-label={`${m} günlük seri rozeti${best >= m ? ', kazanıldı' : ''}`}>
            <IconFire size={20} color={best >= m ? '#FFB366' : '#5F6B80'} />
            <b className="num">{m}</b>
            <span>gün</span>
          </div>
        ))}
      </div>
    </Sheet>
  );
}

export function CelebrateSheet({ event, goal, onClose }: { event: StreakEvent; goal: number; onClose: () => void }) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label="Günlük hedef tamam" onClick={onClose}>
      <div className="sheet" style={{ alignItems: 'center', textAlign: 'center' }} onClick={(e: { stopPropagation: () => void }) => e.stopPropagation()}>
        <span style={{ width: 84, height: 84, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'radial-gradient(circle at 50% 35%, rgba(255,201,138,.45), rgba(240,138,60,.12))', border: '1px solid rgba(255,179,102,.5)' }}>
          <IconFire size={44} color="#FFB366" />
        </span>
        <p className="h1" style={{ fontSize: 22 }}>Günlük hedef tamam!</p>
        <p className="muted" style={{ margin: 0, lineHeight: 1.5 }}>
          Bugün {goal} soruyu geçtin. Serin <b style={{ color: '#FFD7A6' }}>{event.streak} gün</b>.
        </p>
        {event.milestone !== null && <span className="pill pill-gold">{event.milestone} günlük seri rozeti kazandın</span>}
        {event.milestone === null && event.best && <span className="pill pill-gold">Yeni rekor!</span>}
        <button className="btn btn-primary btn-block" onClick={onClose}>Devam</button>
      </div>
    </div>
  );
}

export function NotifAskSheet({ onYes, onNo }: { onYes: () => void; onNo: () => void }) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label="Hatırlatmalar" onClick={onNo}>
      <div className="sheet" onClick={(e: { stopPropagation: () => void }) => e.stopPropagation()}>
        <p className="h2">Hatırlatmaları açalım mı?</p>
        <p className="muted" style={{ margin: 0, lineHeight: 1.5 }}>
          Günde en fazla bir bildirim: serin tehlikedeyken, tekrar soruların biriktiğinde ve sınava 30, 7, 3, 1 gün kala. Saatini ve türlerini Profil'den değiştirebilirsin.
        </p>
        <button className="btn btn-primary btn-block" onClick={onYes}>Bildirimleri aç</button>
        <button className="btn btn-glass btn-block" onClick={onNo}>Şimdi değil</button>
      </div>
    </div>
  );
}
