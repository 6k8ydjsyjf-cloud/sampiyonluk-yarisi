import { useEffect, type ReactNode } from 'react';

export function Blobs({ a, b }: { a: string; b: string }) {
  return (
    <>
      <div className="blob" aria-hidden="true" style={{ width: 320, height: 320, left: -120, top: -90, background: a, opacity: 0.42 }} />
      <div className="blob" aria-hidden="true" style={{ width: 260, height: 260, right: -110, top: 320, background: b, opacity: 0.32 }} />
    </>
  );
}

interface ConfirmProps {
  title: string;
  text: string;
  confirmLabel: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  danger?: boolean;
}

export function ConfirmSheet({ title, text, confirmLabel, cancelLabel = 'Vazgeç', onConfirm, onCancel }: ConfirmProps) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={title} onClick={onCancel}>
      <div className="sheet" onClick={(e: { stopPropagation: () => void }) => e.stopPropagation()}>
        <p className="h2">{title}</p>
        <p className="muted" style={{ margin: 0, lineHeight: 1.5 }}>{text}</p>
        <button className="btn btn-primary btn-block" onClick={onConfirm}>{confirmLabel}</button>
        <button className="btn btn-glass btn-block" onClick={onCancel}>{cancelLabel}</button>
      </div>
    </div>
  );
}

export function Sheet({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={title} onClick={onClose}>
      <div className="sheet" onClick={(e: { stopPropagation: () => void }) => e.stopPropagation()}>
        <div className="between">
          <p className="h2">{title}</p>
          <button className="icon-btn" aria-label="Kapat" onClick={onClose}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" /></svg>
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Toast({ text, onDone }: { text: string; onDone: () => void }) {
  useEffect(() => {
    const t = window.setTimeout(onDone, 2600);
    return () => window.clearTimeout(t);
  }, [text, onDone]);
  return <div className="toast" role="status">{text}</div>;
}

export function Bar({ pct, warn }: { pct: number; warn?: boolean }) {
  const w = Math.max(0, Math.min(100, Math.round(pct)));
  return (
    <div className={warn ? 'bar warn' : 'bar'}>
      <i style={{ width: `${w}%` }} />
    </div>
  );
}

export function Switch({ on, label, onChange, disabled }: { on: boolean; label: string; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button className="switch" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)}>
      <i />
    </button>
  );
}

/** Her ekranın en altındaki yayıncı imzası. İçerik kısaysa ekranın dibine yaslanır. */
export function Signature() {
  return (
    <footer className="signature">
      <span className="signature-mark" aria-hidden="true" />
      <span>BelgeCep ÖGG · <b>Noventra Studios</b></span>
    </footer>
  );
}
