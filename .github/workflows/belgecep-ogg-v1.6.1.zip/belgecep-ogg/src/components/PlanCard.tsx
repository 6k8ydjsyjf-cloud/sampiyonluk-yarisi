import type { DailyPlan, PlanTask } from '../lib/coach';
import { IconArrowRight, IconCheck } from './icons';

interface Props {
  plan: DailyPlan;
  goal: number;
  onTask: (t: PlanTask) => void;
  onGoal: (g: number) => void;
}

export default function PlanCard({ plan, goal, onTask, onGoal }: Props) {
  const done = plan.tasks.filter((t) => t.done).length;
  return (
    <section className="glass" style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }} aria-label="Bugünkü planın">
      <div className="between">
        <span className="h2">Bugünkü planın</span>
        {plan.tasks.length > 0 && <span className="muted small num">{done}/{plan.tasks.length}</span>}
      </div>
      {plan.phase === 'yogun' && <span className="pill pill-gold" style={{ alignSelf: 'flex-start' }}>YOĞUN DÖNEM</span>}
      <span className="muted small" style={{ lineHeight: 1.45 }}>{plan.message}</span>
      <div className="col" style={{ gap: 6 }}>
        {plan.tasks.map((t) => (
          <button key={t.kind} className="plan-task" onClick={() => onTask(t)} disabled={t.done && t.kind === 'review'} aria-label={`${t.title}${t.done ? ', tamamlandı' : ''}`}>
            <span className={`plan-check${t.done ? ' on' : ''}`}>{t.done && <IconCheck size={14} color="#062114" />}</span>
            <span className="col" style={{ gap: 1, flex: 1, minWidth: 0, alignItems: 'flex-start' }}>
              <span style={{ fontWeight: 700, fontSize: 14, textDecoration: t.done ? 'line-through' : 'none', opacity: t.done ? 0.7 : 1, textAlign: 'left' }}>{t.title}</span>
              <span className="muted small" style={{ textAlign: 'left' }}>{t.detail}</span>
            </span>
            {!(t.done && t.kind === 'review') && <IconArrowRight size={18} color="#8FB0FF" />}
          </button>
        ))}
      </div>
      {plan.recommendedGoal !== goal && plan.phase !== 'son-gun' && (
        <button className="btn btn-sm" style={{ background: 'transparent', color: '#8FB0FF', minHeight: 36, padding: 0, alignSelf: 'flex-start' }} onClick={() => onGoal(plan.recommendedGoal)}>
          Günlük hedefi {plan.recommendedGoal} soru yap (şu an {goal})
        </button>
      )}
    </section>
  );
}
