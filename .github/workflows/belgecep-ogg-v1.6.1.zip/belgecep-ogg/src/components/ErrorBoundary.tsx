import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props { children: ReactNode; onReset: () => void }
interface State { failed: boolean }

/** Beklenmeyen bir hata olursa beyaz ekran yerine kurtarma ekranı gösterir. */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { failed: false };

  static getDerivedStateFromError(): State {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.warn('BelgeCep hata yakalandı:', error.message, info.componentStack ?? '');
  }

  private reset = () => {
    try {
      this.props.onReset();
    } finally {
      this.setState({ failed: false });
    }
  };

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="app">
        <div className="screen" style={{ justifyContent: 'center', alignItems: 'center', textAlign: 'center' }}>
          <p className="h1">Bir sorun oluştu</p>
          <p className="muted">İlerlemen ve satın alımın güvende. Ana sayfaya dönerek devam edebilirsin.</p>
          <button className="btn btn-primary" onClick={this.reset}>Ana sayfaya dön</button>
        </div>
      </div>
    );
  }
}
