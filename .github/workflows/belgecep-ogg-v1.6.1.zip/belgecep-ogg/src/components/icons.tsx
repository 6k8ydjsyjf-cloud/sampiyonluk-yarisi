interface P { size?: number; color?: string }

const base = (size: number, color: string) => ({
  width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color,
  strokeWidth: 2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true,
});

export const IconHome = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" /></svg>
);
export const IconList = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M4 5h16M4 12h16M4 19h10" /></svg>
);
export const IconBookmark = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M6 3h12v18l-6-4-6 4z" /></svg>
);
export const IconUser = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></svg>
);
export const IconArrowRight = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M5 12h14M13 6l6 6-6 6" /></svg>
);
export const IconBack = ({ size = 20, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M15 6l-6 6 6 6" /></svg>
);
export const IconClose = ({ size = 20, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M6 6l12 12M18 6L6 18" /></svg>
);
export const IconClock = ({ size = 16, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2M9 2h6" /></svg>
);
export const IconFlag = ({ size = 18, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M5 21V4h11l-2 4 2 4H5" /></svg>
);
export const IconGrid = ({ size = 20, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><rect x="4" y="4" width="6" height="6" rx="1" /><rect x="14" y="4" width="6" height="6" rx="1" /><rect x="4" y="14" width="6" height="6" rx="1" /><rect x="14" y="14" width="6" height="6" rx="1" /></svg>
);
export const IconShare = ({ size = 20, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M12 3v13M7 8l5-5 5 5M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5" /></svg>
);
export const IconCheck = ({ size = 20, color = 'currentColor' }: P) => (
  <svg {...base(size, color)} strokeWidth={2.6}><path d="M5 12l5 5 9-10" /></svg>
);
export const IconLock = ({ size = 18, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>
);
export const IconBook = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M4 19V5a2 2 0 0 1 2-2h12v16H6a2 2 0 0 0-2 2zM8 7h6" /></svg>
);
export const IconHistory = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M12 8v4l3 2" /><circle cx="12" cy="12" r="9" /></svg>
);
export const IconStar = ({ size = 20, color = 'currentColor', filled = false }: P & { filled?: boolean }) => (
  <svg {...base(size, color)} fill={filled ? color : 'none'}><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z" /></svg>
);
export const IconChart = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></svg>
);
export const IconExam = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4V3h6v1M9 10h6M9 14h6M9 18h3" /></svg>
);
export const IconAlert = ({ size = 16, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M12 3l10 18H2z" /><path d="M12 10v5M12 18v.5" /></svg>
);
export const IconRepeat = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15M4 20v-5h5" /></svg>
);
export const IconFire = ({ size = 18, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M12 22c4 0 7-2.7 7-6.5 0-3.3-2.3-5.5-4-7.5-.5 2-1.6 3-3 3.5.5-3-1-6-4-8.5 0 4-4 6.5-4 12.5C4 19.3 8 22 12 22z" /></svg>
);
export const IconCards = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><rect x="3" y="6" width="13" height="15" rx="2" /><path d="M8 3h11a2 2 0 0 1 2 2v13" /></svg>
);
export const IconSwap = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7" /></svg>
);
export const IconScale = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M12 3v18M7 21h10M5 7h14M5 7l-3 6a3 3 0 0 0 6 0zM19 7l-3 6a3 3 0 0 0 6 0z" /></svg>
);
export const IconHeadphones = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M3 18v-6a9 9 0 0 1 18 0v6" /><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3zM3 19a2 2 0 0 0 2 2h1v-6H3z" /></svg>
);
export const IconCard = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><rect x="3" y="5" width="18" height="14" rx="2" /><circle cx="9" cy="12" r="2" /><path d="M14 10h4M14 14h3" /></svg>
);
export const IconPlay = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M7 4l13 8-13 8z" /></svg>
);
export const IconPause = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M8 5v14M16 5v14" /></svg>
);
export const IconSkip = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M5 5l10 7-10 7zM19 5v14" /></svg>
);
export const IconPrev = ({ size = 22, color = 'currentColor' }: P) => (
  <svg {...base(size, color)}><path d="M19 5L9 12l10 7zM5 5v14" /></svg>
);
