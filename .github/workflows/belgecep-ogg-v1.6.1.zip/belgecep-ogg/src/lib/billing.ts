import { PRO_PRODUCT_ID } from '../data/meta';
import { isNative } from './native';

/**
 * Google Play Faturalandırma — @capgo/native-purchases.
 * Tüm çağrılar try/catch içinde; eklenti yoksa veya hata verirse uygulama ÇÖKMEZ.
 * Not: Eklentinin sürümleri arasında küçük API farkları olabildiği için çağrılar
 * fonksiyonun varlığı kontrol edilerek yapılır.
 */

export type BuyResult =
  | { ok: true }
  | { ok: false; reason: 'cancelled' | 'unavailable' | 'error' | 'pending'; message: string };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyPlugin = any;

async function loadPlugin(): Promise<{ NP: AnyPlugin; INAPP: unknown } | null> {
  if (!isNative()) return null;
  try {
    const mod: AnyPlugin = await import('@capgo/native-purchases');
    const NP = mod?.NativePurchases;
    if (!NP) return null;
    const INAPP = mod?.PURCHASE_TYPE?.INAPP ?? 'inapp';
    return { NP, INAPP };
  } catch {
    return null;
  }
}

function errText(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === 'object' && e !== null && 'message' in e) return String((e as { message: unknown }).message);
  return String(e ?? '');
}

function ownsProduct(list: unknown): boolean {
  if (!Array.isArray(list)) return false;
  return list.some((t: AnyPlugin) => {
    const id = t?.productIdentifier ?? t?.productId ?? t?.sku;
    if (id !== PRO_PRODUCT_ID) return false;
    const state = t?.purchaseState;
    // Android: 1 = PURCHASED, "PURCHASED"; durum alanı yoksa satın alınmış kabul edilir.
    return state === undefined || state === null || state === 1 || state === '1' || String(state).toUpperCase() === 'PURCHASED';
  });
}

export async function fetchProPrice(): Promise<string | null> {
  const p = await loadPlugin();
  if (!p) return null;
  try {
    const res: AnyPlugin = await p.NP.getProducts({ productIdentifiers: [PRO_PRODUCT_ID], productType: p.INAPP });
    const prod = res?.products?.[0];
    const price = prod?.priceString ?? prod?.localizedPrice ?? null;
    return typeof price === 'string' && price.length > 0 ? price : null;
  } catch {
    return null;
  }
}

export async function buyPro(): Promise<BuyResult> {
  const p = await loadPlugin();
  if (!p) return { ok: false, reason: 'unavailable', message: 'Satın alma bu cihazda kullanılamıyor.' };
  try {
    if (typeof p.NP.isBillingSupported === 'function') {
      const sup: AnyPlugin = await p.NP.isBillingSupported();
      if (sup && sup.isBillingSupported === false) {
        return { ok: false, reason: 'unavailable', message: 'Google Play ödeme sistemi bu cihazda desteklenmiyor.' };
      }
    }
    const tx: AnyPlugin = await p.NP.purchaseProduct({ productIdentifier: PRO_PRODUCT_ID, productType: p.INAPP, quantity: 1, autoAcknowledgePurchases: true });
    // Android: 2 / "PENDING" = ödeme henüz tamamlanmadı (ör. nakit/havale). Pro, ödeme onaylanınca açılışta otomatik açılır.
    const st = tx?.purchaseState;
    if (st === 2 || st === '2' || String(st ?? '').toUpperCase() === 'PENDING') {
      return { ok: false, reason: 'pending', message: 'Ödemen onay bekliyor. Onaylanınca Pro otomatik açılır.' };
    }
    return { ok: true };
  } catch (e) {
    const msg = errText(e);
    if (/cancel|iptal|USER_CANCELED/i.test(msg)) return { ok: false, reason: 'cancelled', message: 'Satın alma iptal edildi.' };
    if (/already|ITEM_ALREADY_OWNED|zaten/i.test(msg)) return { ok: true };
    return { ok: false, reason: 'error', message: 'Satın alma tamamlanamadı. Lütfen tekrar dene.' };
  }
}

/** Sahip olunan satın alımları kontrol eder. true = Pro sahibi, false = değil, null = kontrol edilemedi. */
export async function checkOwnership(): Promise<boolean | null> {
  const p = await loadPlugin();
  if (!p) return null;
  try {
    if (typeof p.NP.getPurchases === 'function') {
      const res: AnyPlugin = await p.NP.getPurchases({ productType: p.INAPP });
      return ownsProduct(res?.purchases);
    }
    return null;
  } catch {
    return null;
  }
}

export async function restorePro(): Promise<boolean | null> {
  const p = await loadPlugin();
  if (!p) return null;
  try {
    let restored: AnyPlugin = null;
    if (typeof p.NP.restorePurchases === 'function') {
      restored = await p.NP.restorePurchases();
    }
    if (restored && (ownsProduct(restored?.purchases) || ownsProduct(restored?.transactions))) return true;
    return await checkOwnership();
  } catch {
    return null;
  }
}
