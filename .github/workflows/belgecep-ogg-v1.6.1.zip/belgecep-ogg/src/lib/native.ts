import { Capacitor } from '@capacitor/core';

export function isNative(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

export type ShareOutcome = 'shared' | 'copied' | 'cancelled' | 'failed';

function isCancel(e: unknown): boolean {
  const msg = e instanceof Error ? e.message : String(e ?? '');
  return /cancel|abort|iptal/i.test(msg);
}

export async function shareText(title: string, text: string, url: string): Promise<ShareOutcome> {
  try {
    if (isNative()) {
      const { Share } = await import('@capacitor/share');
      await Share.share(url ? { title, text, url, dialogTitle: 'Paylaş' } : { title, text, dialogTitle: 'Gönder' });
      return 'shared';
    }
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      await navigator.share(url ? { title, text, url } : { title, text });
      return 'shared';
    }
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      await navigator.clipboard.writeText(url ? `${text} ${url}` : text);
      return 'copied';
    }
    return 'failed';
  } catch (e) {
    return isCancel(e) ? 'cancelled' : 'failed';
  }
}

/**
 * Android geri tuşu. handler true dönerse olay tüketilmiştir; false dönerse uygulama kapanır.
 * Dönen fonksiyon dinleyiciyi kaldırır.
 */
export async function listenBackButton(handler: () => boolean): Promise<() => void> {
  if (!isNative()) return () => undefined;
  try {
    const { App } = await import('@capacitor/app');
    const handle = await App.addListener('backButton', () => {
      let consumed = false;
      try {
        consumed = handler();
      } catch {
        consumed = true;
      }
      if (!consumed) void App.exitApp();
    });
    return () => {
      void handle.remove();
    };
  } catch {
    return () => undefined;
  }
}

/** Uygulama arka plandan öne gelince çağrılır (gün değişmiş olabilir; bildirim planı tazelenir). */
export async function listenResume(handler: () => void): Promise<() => void> {
  if (!isNative()) return () => undefined;
  try {
    const { App } = await import('@capacitor/app');
    const handle = await App.addListener('resume', () => {
      try { handler(); } catch { /* yoksay */ }
    });
    return () => { void handle.remove(); };
  } catch {
    return () => undefined;
  }
}
