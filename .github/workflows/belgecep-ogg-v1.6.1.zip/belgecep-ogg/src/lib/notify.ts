import type { SavedState } from '../data/types';
import { EXAM_REMIND_DAYS, NOTIF_DAYS_AHEAD, REVIEW_NOTIFY_MIN } from '../data/meta';
import { activeExamDates } from './selectors';
import { addDays, daysUntil, localDateKey } from './engine';
import { currentStreak, streakAtRisk } from './streak';
import { isNative } from './native';
import { CARD_REMIND_DAYS } from './card';

export type NotifKind = 'exam' | 'review' | 'daily' | 'card';

export interface PlannedNotif {
  id: number;
  at: Date;
  title: string;
  body: string;
  kind: NotifKind;
}

/** Bildirim kimlikleri: 1000 + gün sırası. Her planlamada bu aralık temizlenip yeniden kurulur. */
const BASE_ID = 1000;
const ALL_IDS = Array.from({ length: NOTIF_DAYS_AHEAD + 1 }, (_, i) => BASE_ID + i);
const CHANNEL = 'hatirlatmalar';

function at(day: string, time: string): Date | null {
  const d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day);
  const t = /^(\d{2}):(\d{2})$/.exec(time);
  if (!d || !t) return null;
  return new Date(Number(d[1]), Number(d[2]) - 1, Number(d[3]), Number(t[1]), Number(t[2]), 0, 0);
}

function dateOf(day: string): Date {
  return at(day, '12:00') ?? new Date();
}

/**
 * Önümüzdeki günlerin bildirim planı. Günde en fazla 1 bildirim; öncelik sınav > tekrar > günlük hedef.
 * Bugünün hedefi tutturulduysa bugün için yalnızca sınav bildirimi kalır.
 */
export function planNotifications(s: SavedState, now: Date): PlannedNotif[] {
  const n = s.notif;
  if (!n.on || (!n.daily && !n.review && !n.exam)) return [];
  const today = localDateKey(now);
  const metToday = s.days[today]?.met === true;
  const streakNow = currentStreak(s.days, today);
  const out: PlannedNotif[] = [];

  for (let d = 0; d < NOTIF_DAYS_AHEAD; d++) {
    const day = addDays(today, d);
    const id = BASE_ID + d;
    let item: PlannedNotif | null = null;

    if (n.exam) {
      for (const e of activeExamDates(s, now)) {
        const left = daysUntil(e.date, dateOf(day));
        if (left === 0) {
          const when = at(day, '08:00');
          if (when) item = { id, at: when, kind: 'exam', title: 'Bugün sınav günü', body: 'Başarılar! Kimliğini ve sınav giriş belgeni yanına almayı unutma.' };
        } else if (left !== null && (EXAM_REMIND_DAYS as readonly number[]).includes(left)) {
          const when = at(day, n.time);
          if (when) {
            item = {
              id, at: when, kind: 'exam',
              title: `Sınava ${left} gün kaldı`,
              body: left === 1 ? 'Yarın sınav günü. Kısa bir tekrar yap ve erken uyu.' : 'Bir deneme çözüp hazırlığını ölç; eksik konularını tekrar et.',
            };
          }
        }
        if (item) break;
      }
    }

    if (!item && n.exam && s.cardExpiry) {
      const left = daysUntil(s.cardExpiry, dateOf(day));
      if (left !== null && (CARD_REMIND_DAYS as readonly number[]).includes(left)) {
        const when = at(day, n.time);
        if (when) {
          item = left === 0
            ? { id, at: when, kind: 'card', title: 'Kimlik kartının süresi bugün doluyor', body: 'Kart olmadan yetkiler kullanılamaz. Yenileme eğitimi için eğitim kurumuna başvur.' }
            : { id, at: when, kind: 'card', title: `Kimlik kartına ${left} gün kaldı`, body: 'Yenileme eğitimi ve sınavı kart süresi dolmadan tamamlanmalı.' };
        }
      }
    }

    const quiet = d === 0 && metToday;
    if (!item && !quiet && n.review) {
      const due = Object.values(s.srs).filter((x) => x.due <= day).length;
      const when = at(day, n.time);
      if (due >= REVIEW_NOTIFY_MIN && when) {
        item = { id, at: when, kind: 'review', title: 'Akıllı tekrar zamanı', body: `${due} soru tekrarını bekliyor. Bugün birkaçını çöz, bilgin kalıcı olsun.` };
      }
    }

    if (!item && !quiet && n.daily) {
      const when = at(day, n.time);
      if (when) {
        let title = 'Günlük hedefin seni bekliyor';
        let body = `Bugün ${s.goal} soru çöz, serini sürdür.`;
        if (d === 0) {
          if (streakAtRisk(s.days, today)) {
            title = `${streakNow} günlük serin tehlikede`;
            body = `Bugün ${s.goal} soru çöz, serin devam etsin.`;
          } else {
            title = 'Bugünkü hedefin hazır';
            body = `${s.goal} soru çözerek serini başlat.`;
          }
        } else if (d === 1 && metToday && streakNow > 0) {
          title = `${streakNow} günlük serini sürdür`;
          body = `Bugün de ${s.goal} soru çöz, seri ${streakNow + 1}. gününe geçsin.`;
        }
        item = { id, at: when, kind: 'daily', title, body };
      }
    }

    if (item && item.at.getTime() > now.getTime() + 60_000) out.push(item);
  }
  return out;
}

// ── Yerel bildirim eklentisi (yalnızca Android uygulamasında) ──

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function plugin(): Promise<any | null> {
  if (!isNative()) return null;
  try {
    const mod = await import('@capacitor/local-notifications');
    return mod.LocalNotifications ?? null;
  } catch {
    return null;
  }
}

export type PermissionState = 'granted' | 'denied' | 'prompt' | 'unavailable';

export async function notifPermission(): Promise<PermissionState> {
  const p = await plugin();
  if (!p) return 'unavailable';
  try {
    const r = await p.checkPermissions();
    const v = r?.display;
    return v === 'granted' ? 'granted' : v === 'denied' ? 'denied' : 'prompt';
  } catch {
    return 'unavailable';
  }
}

/** İzin ister; verildiyse true. Hiçbir durumda hata fırlatmaz. */
export async function requestNotifPermission(): Promise<boolean> {
  const p = await plugin();
  if (!p) return false;
  try {
    const cur = await p.checkPermissions();
    if (cur?.display === 'granted') return true;
    const r = await p.requestPermissions();
    return r?.display === 'granted';
  } catch {
    return false;
  }
}

let chain: Promise<void> = Promise.resolve();

/** Bekleyen bildirimleri temizleyip planı yeniden kurar. Çağrılar sıraya girer; hata asla dışarı taşmaz. */
export function syncNotifications(s: SavedState, now: Date): Promise<void> {
  const plan = planNotifications(s, now);
  const wanted = s.notif.on;
  chain = chain.then(async () => {
    const p = await plugin();
    if (!p) return;
    try {
      await p.cancel({ notifications: ALL_IDS.map((id) => ({ id })) });
    } catch {
      // yoksay
    }
    if (!wanted || plan.length === 0) return;
    try {
      const perm = await p.checkPermissions();
      if (perm?.display !== 'granted') return;
      try {
        await p.createChannel({ id: CHANNEL, name: 'Hatırlatmalar', description: 'Çalışma, tekrar ve sınav hatırlatmaları', importance: 3 });
      } catch {
        // Kanal desteklenmiyorsa varsayılan kanal kullanılır.
      }
      await p.schedule({
        notifications: plan.map((x) => ({
          id: x.id,
          title: x.title,
          body: x.body,
          schedule: { at: x.at, allowWhileIdle: true },
          channelId: CHANNEL,
          smallIcon: 'ic_stat_belgecep',
          iconColor: '#2F5BEA',
          extra: { kind: x.kind },
        })),
      });
    } catch {
      // Planlanamadıysa uygulama normal çalışmaya devam eder.
    }
  });
  return chain;
}

/** Bildirime dokunulunca türünü bildirir. Dönen fonksiyon dinleyiciyi kaldırır. */
export async function listenNotifTaps(handler: (kind: NotifKind) => void): Promise<() => void> {
  const p = await plugin();
  if (!p) return () => undefined;
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const h = await p.addListener('localNotificationActionPerformed', (e: any) => {
      const k = e?.notification?.extra?.kind;
      handler(k === 'exam' || k === 'review' || k === 'card' ? k : 'daily');
    });
    return () => { void h?.remove?.(); };
  } catch {
    return () => undefined;
  }
}
