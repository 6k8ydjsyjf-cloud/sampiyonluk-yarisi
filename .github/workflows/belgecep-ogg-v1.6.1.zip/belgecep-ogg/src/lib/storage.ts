import type { ActiveSession, DayLog, NotifSettings, QStat, SavedState, SessionRecord, SrsItem, TopicStat, Variant } from '../data/types';
import { DEFAULT_GOAL, DEFAULT_NOTIF_TIME, GOAL_OPTIONS } from '../data/meta';
import { MAX_DAYS, daysFromHistory, trimDays } from './streak';
import { qstatsFromHistory } from './analysis';

const KEY = 'belgecep.ogg.v1';
const MAX_HISTORY = 50;

export function defaultState(): SavedState {
  return {
    v: 2, pro: false, history: [], srs: {}, favs: [], daily: { date: '', deneme: 0, study: 0 }, cardExpiry: null, active: null,
    days: {}, goal: DEFAULT_GOAL, best: 0, notif: defaultNotif(), notifAsked: false,
    qstats: {}, examDate: null, lastBackup: null,
  };
}

export function defaultNotif(): NotifSettings {
  return { on: false, time: DEFAULT_NOTIF_TIME, daily: true, review: true, exam: true };
}

function isObj(x: unknown): x is Record<string, unknown> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

function num(x: unknown, fallback = 0): number {
  return typeof x === 'number' && Number.isFinite(x) ? x : fallback;
}

function strArr(x: unknown): string[] {
  return Array.isArray(x) ? x.filter((v): v is string => typeof v === 'string') : [];
}

function variantOf(x: unknown): Variant | undefined {
  return x === 'silahsiz' || x === 'silahli' || x === 'fark' ? x : undefined;
}

function passOf(x: unknown): { pass?: number } {
  return typeof x === 'number' && Number.isInteger(x) && x >= 1 && x <= 100 ? { pass: x } : {};
}

function kindOf(x: unknown): SessionRecord['kind'] {
  return x === 'konu' || x === 'yanlis' || x === 'favori' ? x : 'deneme';
}

function stat(x: unknown): TopicStat {
  return isObj(x) ? { c: Math.max(0, num(x.c)), t: Math.max(0, num(x.t)) } : { c: 0, t: 0 };
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function parseSrs(data: Record<string, unknown>): Record<string, SrsItem> {
  const out: Record<string, SrsItem> = {};
  if (isObj(data.srs)) {
    for (const [id, v] of Object.entries(data.srs)) {
      if (!isObj(v)) continue;
      const box = Math.min(5, Math.max(0, Math.floor(num(v.box))));
      const due = typeof v.due === 'string' && DATE_RE.test(v.due) ? v.due : '';
      out[id] = { box, due };
    }
  }
  // v1 göçü: eski yanlış defteri bugün tekrar edilecek şekilde aktarılır.
  for (const id of strArr(data.wrong)) if (!out[id]) out[id] = { box: 0, due: '' };
  return out;
}

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

function parseNotif(x: unknown): NotifSettings {
  const d = defaultNotif();
  if (!isObj(x)) return d;
  return {
    on: x.on === true,
    time: typeof x.time === 'string' && TIME_RE.test(x.time) ? x.time : d.time,
    daily: x.daily !== false,
    review: x.review !== false,
    exam: x.exam !== false,
  };
}

function parseQStats(x: unknown): Record<string, QStat> | null {
  if (!isObj(x)) return null;
  const out: Record<string, QStat> = {};
  for (const [id, v] of Object.entries(x)) {
    if (!isObj(v)) continue;
    const sN = Math.max(0, Math.floor(num(v.s)));
    if (sN === 0) continue;
    out[id] = { s: sN, w: Math.min(sN, Math.max(0, Math.floor(num(v.w)))), last: typeof v.last === 'string' && DATE_RE.test(v.last) ? v.last : '' };
  }
  return out;
}

function parseDays(x: unknown): Record<string, DayLog> | null {
  if (!isObj(x)) return null;
  const out: Record<string, DayLog> = {};
  for (const [k, v] of Object.entries(x)) {
    if (!DATE_RE.test(k) || !isObj(v)) continue;
    out[k] = { n: Math.max(0, Math.floor(num(v.n))), met: v.met === true };
  }
  return out;
}

function parseRecord(x: unknown): SessionRecord | null {
  if (!isObj(x)) return null;
  if (typeof x.id !== 'string' || typeof x.title !== 'string') return null;
  const qids = strArr(x.qids);
  const answersRaw = Array.isArray(x.answers) ? x.answers : [];
  const answers = qids.map((_, i) => {
    const a = answersRaw[i];
    return typeof a === 'number' && a >= 0 && a <= 4 ? a : null;
  });
  const kind = kindOf(x.kind);
  const mode = x.mode === 'study' ? 'study' : 'exam';
  const variant = variantOf(x.variant);
  const sections = isObj(x.sections) ? { genel: stat(x.sections.genel), silah: stat(x.sections.silah) } : undefined;
  return {
    ...(variant ? { variant } : {}),
    ...passOf(x.pass),
    ...(sections ? { sections } : {}),
    id: x.id,
    kind,
    mode,
    title: x.title,
    finishedAt: num(x.finishedAt),
    total: num(x.total),
    correct: num(x.correct),
    blank: num(x.blank),
    score: num(x.score),
    passed: x.passed === true,
    durationSec: num(x.durationSec),
    topicStats: isObj(x.topicStats) ? (x.topicStats as SessionRecord['topicStats']) : {},
    qids,
    answers,
  };
}

function parseActive(x: unknown): ActiveSession | null {
  if (!isObj(x)) return null;
  if (typeof x.id !== 'string' || typeof x.title !== 'string') return null;
  const qids = strArr(x.qids);
  if (qids.length === 0) return null;
  const answersRaw = Array.isArray(x.answers) ? x.answers : [];
  const flagsRaw = Array.isArray(x.flags) ? x.flags : [];
  const variant = variantOf(x.variant);
  return {
    ...(variant ? { variant } : {}),
    ...passOf(x.pass),
    id: x.id,
    kind: kindOf(x.kind),
    mode: x.mode === 'study' ? 'study' : 'exam',
    title: x.title,
    qids,
    answers: qids.map((_, i) => {
      const a = answersRaw[i];
      return typeof a === 'number' && a >= 0 && a <= 4 ? a : null;
    }),
    flags: qids.map((_, i) => flagsRaw[i] === true),
    index: num(x.index),
    startedAt: num(x.startedAt, Date.now()),
    endAt: typeof x.endAt === 'number' && Number.isFinite(x.endAt) ? x.endAt : null,
  };
}

/** Bozuk veya eski veride ASLA hata fırlatmaz; en kötü durumda varsayılan durumu döndürür. */
export function parseState(raw: string | null): SavedState {
  const d = defaultState();
  if (!raw) return d;
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return d;
  }
  if (!isObj(data)) return d;
  const history = Array.isArray(data.history)
    ? data.history.map(parseRecord).filter((r): r is SessionRecord => r !== null).slice(-MAX_HISTORY)
    : [];
  const daily = isObj(data.daily)
    ? { date: typeof data.daily.date === 'string' ? data.daily.date : '', deneme: num(data.daily.deneme), study: num(data.daily.study) }
    : d.daily;
  const goal = (GOAL_OPTIONS as readonly number[]).includes(num(data.goal)) ? num(data.goal) : DEFAULT_GOAL;
  const days = trimDays(parseDays(data.days) ?? daysFromHistory(history, goal));
  return {
    days,
    goal,
    best: Math.max(0, Math.floor(num(data.best))),
    notif: parseNotif(data.notif),
    notifAsked: data.notifAsked === true,
    qstats: parseQStats(data.qstats) ?? qstatsFromHistory(history),
    examDate: typeof data.examDate === 'string' && DATE_RE.test(data.examDate) ? data.examDate : null,
    lastBackup: typeof data.lastBackup === 'number' && Number.isFinite(data.lastBackup) && data.lastBackup > 0 ? data.lastBackup : null,
    v: 2,
    pro: data.pro === true,
    history,
    srs: parseSrs(data),
    favs: Array.from(new Set(strArr(data.favs))),
    daily,
    cardExpiry: typeof data.cardExpiry === 'string' && DATE_RE.test(data.cardExpiry) ? data.cardExpiry : null,
    active: parseActive(data.active),
  };
}

export function loadState(): SavedState {
  try {
    return parseState(window.localStorage.getItem(KEY));
  } catch {
    return defaultState();
  }
}

export function saveState(s: SavedState): void {
  try {
    const trimmed: SavedState = { ...s, history: s.history.slice(-MAX_HISTORY), days: Object.keys(s.days).length > MAX_DAYS ? trimDays(s.days) : s.days };
    window.localStorage.setItem(KEY, JSON.stringify(trimmed));
  } catch {
    // Depolama dolu veya erişilemez: uygulama çalışmaya devam eder.
  }
}

export function clearState(): void {
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    // yoksay
  }
}
