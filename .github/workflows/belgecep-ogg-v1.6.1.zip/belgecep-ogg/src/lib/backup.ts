import type { SavedState } from '../data/types';
import { APP_VERSION } from '../data/meta';
import { parseState } from './storage';
import { localDateKey } from './engine';
import { isNative } from './native';

/**
 * Yedekleme: tüm çalışma verisi (geçmiş, tekrar defteri, seri, favoriler, ayarlar) tek bir JSON dosyasına yazılır.
 * Pro bilgisi yedeğe GÜVENİLMEZ: geri yüklemede Pro durumu mevcut cihazdaki/Google Play'deki satın alıma göre belirlenir.
 */
export const BACKUP_FORMAT = 'belgecep-ogg-yedek';

export function makeBackup(s: SavedState, now: Date): string {
  const data: SavedState = { ...s, pro: false };
  return JSON.stringify({ format: BACKUP_FORMAT, version: 1, app: APP_VERSION, createdAt: now.toISOString(), data });
}

export type ReadResult =
  | { ok: true; state: SavedState; createdAt: string; sessions: number }
  | { ok: false; message: string };

export function readBackup(text: string): ReadResult {
  let obj: unknown;
  try {
    obj = JSON.parse(text.trim());
  } catch {
    return { ok: false, message: 'Dosya okunamadı. BelgeCep ÖGG yedek dosyası seçtiğinden emin ol.' };
  }
  if (typeof obj !== 'object' || obj === null) return { ok: false, message: 'Geçersiz yedek dosyası.' };
  const o = obj as Record<string, unknown>;
  if (o.format !== BACKUP_FORMAT) return { ok: false, message: 'Bu dosya bir BelgeCep ÖGG yedeği değil.' };
  if (typeof o.version !== 'number' || o.version > 1) return { ok: false, message: 'Bu yedek daha yeni bir sürümle alınmış. Önce uygulamayı güncelle.' };
  if (typeof o.data !== 'object' || o.data === null) return { ok: false, message: 'Yedek dosyası boş veya bozuk.' };
  const state = parseState(JSON.stringify(o.data));
  return { ok: true, state, createdAt: typeof o.createdAt === 'string' ? o.createdAt : '', sessions: state.history.length };
}

export type ExportResult = 'shared' | 'copied' | 'downloaded' | 'cancelled' | 'failed';

/** Yedeği dosya olarak paylaşır (Android: Drive, e-posta, WhatsApp vb.). Olmazsa panoya kopyalar. */
export async function exportBackup(json: string, now: Date): Promise<ExportResult> {
  const name = `belgecep-ogg-yedek-${localDateKey(now)}.json`;
  if (isNative()) {
    try {
      const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
      const w = await Filesystem.writeFile({ path: name, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
      const { Share } = await import('@capacitor/share');
      await Share.share({ title: 'BelgeCep ÖGG yedeği', files: [w.uri], dialogTitle: 'Yedeği kaydet veya gönder' });
      return 'shared';
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e ?? '');
      if (/cancel|iptal/i.test(msg)) return 'cancelled';
      // dosya paylaşımı olmazsa panoya kopyalamayı dene
    }
  } else {
    try {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 2000);
      return 'downloaded';
    } catch {
      // panoya kopyalamayı dene
    }
  }
  try {
    await navigator.clipboard.writeText(json);
    return 'copied';
  } catch {
    return 'failed';
  }
}
