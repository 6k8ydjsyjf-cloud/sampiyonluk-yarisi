import type { Question, SavedState, TopicId } from '../data/types';
import { GOAL_OPTIONS, topicName } from '../data/meta';
import { localDateKey } from './engine';
import { dueIds, nextExam } from './selectors';
import { subtopicStatus, unseenCommon, type SubStatus } from './analysis';

/**
 * Sınav koçu: sınava kalan süre, görülmemiş soru sayısı, bekleyen tekrarlar ve zayıf alt konulara göre
 * günlük plan üretir. Tamamen cihaz içinde, kurala dayalı çalışır (yapay zekâ değildir).
 */

export type Phase = 'tarihsiz' | 'normal' | 'yogun' | 'son-gun' | 'gecti';
export type TaskKind = 'review' | 'weak' | 'new' | 'deneme';

export interface PlanTask {
  kind: TaskKind;
  title: string;
  detail: string;
  done: boolean;
  /** weak görevinde çalışılacak alt konu */
  topic?: TopicId;
  sub?: string;
  /** new görevinde önerilen soru sayısı */
  size?: number;
}

export interface DailyPlan {
  phase: Phase;
  daysLeft: number | null;
  message: string;
  recommendedGoal: number;
  tasks: PlanTask[];
}

/** Son haftaya kadar tüm ortak bankayı bir kez görmek için gereken günlük yeni soru sayısı */
export function dailyNewTarget(unseen: number, daysLeft: number | null): number {
  if (unseen <= 0) return 0;
  if (daysLeft === null) return Math.min(unseen, 20);
  const studyDays = Math.max(1, daysLeft - 7);
  return Math.min(unseen, Math.max(10, Math.min(60, Math.ceil(unseen / studyDays))));
}

export function nearestGoal(n: number): number {
  for (const g of GOAL_OPTIONS) if (g >= n) return g;
  return GOAL_OPTIONS[GOAL_OPTIONS.length - 1] as number;
}

export function weakSubs(s: SavedState, bank: Question[], today: string, includeSilah: boolean): SubStatus[] {
  return subtopicStatus(s, bank, today, includeSilah)
    .filter((x) => x.state === 'zayif')
    .sort((a, b) => (a.acc ?? 0) - (b.acc ?? 0) || b.due - a.due);
}

export function buildPlan(s: SavedState, bank: Question[], now: Date): DailyPlan {
  const today = localDateKey(now);
  const exam = nextExam(now, s);
  const daysLeft = exam ? exam.days : null;
  const phase: Phase = daysLeft === null ? 'tarihsiz' : daysLeft <= 1 ? 'son-gun' : daysLeft <= 7 ? 'yogun' : 'normal';
  const unseen = unseenCommon(s, bank).length;
  const due = dueIds(s, today).length;
  const weak = weakSubs(s, bank, today, s.pro);
  const doneToday = s.days[today]?.n ?? 0;
  const denemeToday = s.history.some((r) => r.kind === 'deneme' && r.mode === 'exam' && localDateKey(new Date(r.finishedAt)) === today);
  const lastDeneme = s.history.filter((r) => r.kind === 'deneme' && r.mode === 'exam').slice(-1)[0];
  const daysSinceDeneme = lastDeneme ? Math.floor((now.getTime() - lastDeneme.finishedAt) / 86400000) : null;

  const newTarget = phase === 'son-gun' ? 0 : phase === 'yogun' ? Math.min(unseen, 20) : dailyNewTarget(unseen, daysLeft);
  const recommendedGoal = nearestGoal(Math.max(10, newTarget + Math.min(due, 20)));
  const tasks: PlanTask[] = [];

  if (due > 0) {
    tasks.push({ kind: 'review', title: `Akıllı tekrar · ${Math.min(due, 20)} soru`, detail: `${due} soru tekrar zamanında`, done: false });
  } else if (Object.keys(s.srs).length > 0) {
    tasks.push({ kind: 'review', title: 'Akıllı tekrar', detail: 'Bugün tekrar zamanı gelen soru yok', done: true });
  }

  const w = weak[0];
  if (w) {
    const studied = bank.some((q) => q.topic === w.topic && q.sub === w.sub && s.qstats[q.id]?.last === today);
    tasks.push({
      kind: 'weak', title: `Zayıf konu · ${w.sub}`, topic: w.topic, sub: w.sub,
      detail: `${topicName(w.topic)}${w.acc !== null ? ` · başarı %${w.acc}` : ''}`, done: studied,
    });
  }

  if (newTarget > 0) {
    tasks.push({
      kind: 'new', title: `Yeni sorular · ${Math.min(newTarget, 25)} soru`, size: Math.min(newTarget, 25),
      detail: `Bankada henüz görmediğin ${unseen} ortak soru var`, done: doneToday >= recommendedGoal,
    });
  }

  const wantDeneme = phase === 'yogun' || phase === 'son-gun' ? phase === 'yogun' : daysSinceDeneme === null || daysSinceDeneme >= 3;
  if (wantDeneme || denemeToday) {
    tasks.push({ kind: 'deneme', title: 'Deneme sınavı', detail: phase === 'yogun' ? 'Son hafta: her gün bir deneme' : 'Üç günde bir gerçek sınav provası', done: denemeToday });
  }

  let message: string;
  if (phase === 'tarihsiz') message = 'Takvimde yaklaşan sınav yok. Sınav tarihini Profil\'den girersen plan ona göre ayarlanır.';
  else if (phase === 'son-gun') message = daysLeft === 0 ? 'Bugün sınav günü. Yeni konuya başlama; sakin ol ve başarılar!' : 'Yarın sınav: yeni konu yok. Kısa bir tekrar yap ve erken dinlen.';
  else if (phase === 'yogun') message = `Sınava ${daysLeft} gün kaldı · yoğun dönem: her gün deneme, zayıf konular ve tekrar.`;
  else if (unseen === 0) message = `Sınava ${daysLeft} gün kaldı. Bankanın tamamını gördün; deneme ve zayıf konulara odaklan.`;
  else message = `Sınava ${daysLeft} gün kaldı. Günde yaklaşık ${newTarget} yeni soru çözersen bankayı son haftadan önce bitirirsin.`;

  return { phase, daysLeft, message, recommendedGoal, tasks };
}

/** Görülmemiş ortak sorular; zayıf derslerdeki sorular öne alınır. */
export function newQuestionPool(s: SavedState, bank: Question[]): Question[] {
  const unseen = unseenCommon(s, bank);
  const sum = new Map<TopicId, { c: number; t: number }>();
  for (const q of bank) {
    const qs = s.qstats[q.id];
    if (!qs) continue;
    const cur = sum.get(q.topic) ?? { c: 0, t: 0 };
    cur.c += qs.s - qs.w;
    cur.t += qs.s;
    sum.set(q.topic, cur);
  }
  // Başarı oranı düşük (veya hiç çalışılmamış = 0.5 kabul) dersler önce gelir
  const score = (t: TopicId) => { const x = sum.get(t); return x && x.t > 0 ? x.c / x.t : 0.5; };
  return unseen
    .map((q) => ({ q, k: score(q.topic) + Math.random() * 0.25 }))
    .sort((a, b) => a.k - b.k)
    .map((x) => x.q);
}
