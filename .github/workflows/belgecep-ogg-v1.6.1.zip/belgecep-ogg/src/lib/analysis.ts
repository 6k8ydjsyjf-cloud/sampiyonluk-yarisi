import type { Difficulty, QStat, Question, SavedState, SessionRecord, TopicId, TopicStat } from '../data/types';
import { localDateKey } from './engine';

/** Biten oturumun cevaplarını soru bazlı kalıcı istatistiğe işler. Boş bırakılan soru yanlış sayılır. */
export function updateQStats(q: Record<string, QStat>, rec: SessionRecord): Record<string, QStat> {
  const day = localDateKey(new Date(rec.finishedAt));
  const out = { ...q };
  rec.qids.forEach((id, i) => {
    const a = rec.answers[i];
    const cur = out[id] ?? { s: 0, w: 0, last: '' };
    out[id] = { s: cur.s + 1, w: cur.w + (a === 0 ? 0 : 1), last: day > cur.last ? day : cur.last };
  });
  return out;
}

/** Eski sürümden gelen veride geçmiş oturumlardan soru istatistiği üretir. */
export function qstatsFromHistory(history: SessionRecord[]): Record<string, QStat> {
  let q: Record<string, QStat> = {};
  for (const r of history) q = updateQStats(q, r);
  return q;
}

export type SubState = 'yeni' | 'zayif' | 'gelisiyor' | 'ogrenildi';

export interface SubStatus {
  topic: TopicId;
  sub: string;
  total: number;
  seen: number;
  answers: number;
  correct: number;
  acc: number | null;
  due: number;
  state: SubState;
}

export const SUB_STATE_LABEL: Record<SubState, string> = {
  yeni: 'Başlanmadı',
  zayif: 'Tekrar gerekli',
  gelisiyor: 'Gelişiyor',
  ogrenildi: 'Öğrenildi',
};

/**
 * Alt konu durumu:
 *  - Başlanmadı: hiç soru görülmemiş
 *  - Tekrar gerekli: doğruluk %60'ın altında ya da vadesi gelmiş tekrar sorusu var
 *  - Öğrenildi: doğruluk en az %80, soruların en az %60'ı görülmüş ve bekleyen tekrar yok
 *  - Gelişiyor: diğer durumlar
 */
export function subtopicStatus(s: SavedState, bank: Question[], today: string, includeSilah: boolean): SubStatus[] {
  const map = new Map<string, SubStatus>();
  for (const q of bank) {
    if (!includeSilah && q.topic === 'silah') continue;
    const key = `${q.topic}|${q.sub}`;
    let st = map.get(key);
    if (!st) {
      st = { topic: q.topic, sub: q.sub, total: 0, seen: 0, answers: 0, correct: 0, acc: null, due: 0, state: 'yeni' };
      map.set(key, st);
    }
    st.total += 1;
    const qs = s.qstats[q.id];
    if (qs && qs.s > 0) {
      st.seen += 1;
      st.answers += qs.s;
      st.correct += qs.s - qs.w;
    }
    const srs = s.srs[q.id];
    if (srs && srs.due <= today) st.due += 1;
  }
  const out = Array.from(map.values());
  for (const st of out) {
    st.acc = st.answers > 0 ? Math.round((st.correct / st.answers) * 100) : null;
    if (st.seen === 0) st.state = st.due > 0 ? 'zayif' : 'yeni';
    else if ((st.acc ?? 0) < 60 || st.due > 0) st.state = 'zayif';
    else if ((st.acc ?? 0) >= 80 && st.seen / st.total >= 0.6) st.state = 'ogrenildi';
    else st.state = 'gelisiyor';
  }
  return out;
}

export interface ItemAnalysis {
  byDifficulty: Record<Difficulty, TopicStat>;
  /** Yanlış/boş yapılan alt konular, en çok kaybedilenden başlayarak */
  lostSubs: { topic: TopicId; sub: string; lost: number; total: number }[];
  /** Bu oturumdaki yanlış/boş sorulardan daha önce de yanlış yapılmış olanlar */
  repeatedMistakes: number;
}

/** Bir oturumun madde analizi: zorluk düzeyine göre başarı ve puan kaybedilen alt konular. */
export function analyzeRecord(rec: SessionRecord, byId: Map<string, Question>, qstats: Record<string, QStat>): ItemAnalysis {
  const byDifficulty: Record<Difficulty, TopicStat> = { 1: { c: 0, t: 0 }, 2: { c: 0, t: 0 }, 3: { c: 0, t: 0 } };
  const lost = new Map<string, { topic: TopicId; sub: string; lost: number; total: number }>();
  let repeatedMistakes = 0;
  rec.qids.forEach((id, i) => {
    const q = byId.get(id);
    if (!q) return;
    const ok = rec.answers[i] === 0;
    const d = byDifficulty[q.d];
    d.t += 1;
    if (ok) d.c += 1;
    const key = `${q.topic}|${q.sub}`;
    const cur = lost.get(key) ?? { topic: q.topic, sub: q.sub, lost: 0, total: 0 };
    cur.total += 1;
    if (!ok) {
      cur.lost += 1;
      // qstats bu oturumu da içerir: daha önce de yanlış yapılmışsa w >= 2 olur
      if ((qstats[id]?.w ?? 0) >= 2) repeatedMistakes += 1;
    }
    lost.set(key, cur);
  });
  const lostSubs = Array.from(lost.values()).filter((x) => x.lost > 0).sort((a, b) => b.lost - a.lost || b.total - a.total);
  return { byDifficulty, lostSubs, repeatedMistakes };
}

/** Bankadaki ortak (silah dışı) sorulardan hiç görülmemiş olanlar */
export function unseenCommon(s: SavedState, bank: Question[]): Question[] {
  return bank.filter((q) => q.topic !== 'silah' && !(s.qstats[q.id]?.s));
}
