import { daysUntil } from './engine';

/**
 * Özel güvenlik kimlik kartı takibi.
 * Kart beş yıl geçerlidir; ilk kartın süresi başarılı olunan sınav tarihine beş yıl eklenerek belirlenir
 * (EGM geçici kimlik kartı genelgesi). Yenileme için beş yılda bir yenileme eğitimi ve sınavı gerekir (Yönetmelik md. 34).
 */
export const CARD_YEARS = 5;
/** Bildirim gönderilecek kalan gün eşikleri */
export const CARD_REMIND_DAYS = [180, 90, 30, 7, 0] as const;

export type CardLevel = 'ok' | 'soon' | 'warn' | 'urgent' | 'expired';

export interface CardStatus {
  daysLeft: number;
  level: CardLevel;
  title: string;
  text: string;
}

/** Sınav tarihinden kartın bitiş tarihini hesaplar (YYYY-AA-GG). 29 Şubat → 28 Şubat. */
export function expiryFromExam(examDate: string): string | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(examDate);
  if (!m) return null;
  const y = Number(m[1]) + CARD_YEARS;
  const mo = Number(m[2]);
  let d = Number(m[3]);
  const last = new Date(y, mo, 0).getDate();
  if (d > last) d = last;
  return `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

export function cardStatus(expiry: string, now: Date): CardStatus | null {
  const left = daysUntil(expiry, now);
  if (left === null) return null;
  if (left < 0) {
    return { daysLeft: left, level: 'expired', title: 'Kimlik kartının süresi doldu',
      text: 'Kimlik kartı olmadan özel güvenlik yetkileri kullanılamaz (5188 md. 12). Yenileme eğitimi ve sınavı için bir eğitim kurumuna başvur.' };
  }
  if (left <= 60) {
    return { daysLeft: left, level: 'urgent', title: `Kartının bitmesine ${left} gün kaldı`,
      text: 'Yenileme eğitimini ve sınavı kart süresi dolmadan tamamlaman gerekir. Hâlâ kaydolmadıysan hemen bir eğitim kurumuna başvur.' };
  }
  if (left <= 180) {
    return { daysLeft: left, level: 'warn', title: `Kartının bitmesine ${left} gün kaldı`,
      text: 'Yenileme eğitimine kaydolma zamanı. Eğitim en az 60 ders saatidir; ardından yenileme sınavına girersin.' };
  }
  if (left <= 365) {
    return { daysLeft: left, level: 'soon', title: `Kartının bitmesine ${left} gün kaldı`,
      text: 'Bir yıldan az kaldı. Yenileme eğitimi ve sınav takvimini takip etmeye başla.' };
  }
  return { daysLeft: left, level: 'ok', title: `Kartın geçerli · ${left} gün kaldı`,
    text: 'Süre dolmadan yenileme eğitimi alıp sınavı geçmen gerekir. Zamanı yaklaşınca seni uyaracağız.' };
}
