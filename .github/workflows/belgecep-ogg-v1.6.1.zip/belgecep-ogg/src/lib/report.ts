import type { Question } from '../data/types';
import { APP_VERSION, SUPPORT_EMAIL, topicName } from '../data/meta';
import { shareText, type ShareOutcome } from './native';

/** Soru hata bildirimi: e-posta tanımlıysa posta uygulaması, değilse paylaşım menüsü açılır. */
export async function reportQuestion(q: Question): Promise<ShareOutcome | 'mail'> {
  const subject = `BelgeCep ÖGG hata bildirimi · ${q.id}`;
  const body = [
    `Soru kimliği: ${q.id}`,
    `Ders: ${topicName(q.topic)} · ${q.sub}`,
    `Soru: ${q.q}`,
    '',
    'Hata nedir? (buraya yazın):',
    '',
    '',
    `Uygulama sürümü: ${APP_VERSION}`,
  ].join('\n');
  if (SUPPORT_EMAIL) {
    try {
      window.location.href = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      return 'mail';
    } catch {
      return 'failed';
    }
  }
  return shareText(subject, body, '');
}
