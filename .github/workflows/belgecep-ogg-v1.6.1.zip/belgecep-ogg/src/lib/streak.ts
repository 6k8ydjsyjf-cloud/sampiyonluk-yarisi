import type { DayLog, SavedState, SessionRecord } from '../data/types';
import { STREAK_MILESTONES } from '../data/meta';
import { addDays, localDateKey } from './engine';
import { updateQStats } from './analysis';

export const MAX_DAYS = 400;

/** Güne cevap ekler; hedef bir kez tutturulduysa o gün "tamamlandı" kalır (hedef sonradan değişse de). */
export function logAnswers(days: Record<string, DayLog>, day: string, n: number, goal: number): Record<string, DayLog> {
  const cur = days[day] ?? { n: 0, met: false };
  const total = cur.n + Math.max(0, n);
  return { ...days, [day]: { n: total, met: cur.met || total >= goal } };
}

export function trimDays(days: Record<string, DayLog>): Record<string, DayLog> {
  const keys = Object.keys(days).sort();
  if (keys.length <= MAX_DAYS) return days;
  const out: Record<string, DayLog> = {};
  for (const k of keys.slice(-MAX_DAYS)) out[k] = days[k] as DayLog;
  return out;
}

/** Bugün ya da dün biten, hedefin tutturulduğu ardışık gün sayısı */
export function currentStreak(days: Record<string, DayLog>, today: string): number {
  let day = days[today]?.met ? today : addDays(today, -1);
  let n = 0;
  while (days[day]?.met) {
    n += 1;
    day = addDays(day, -1);
  }
  return n;
}

/** Seri bugün hedef tutturulmazsa kırılacak mı (dün tamamlandı, bugün henüz değil) */
export function streakAtRisk(days: Record<string, DayLog>, today: string): boolean {
  return !days[today]?.met && currentStreak(days, today) > 0;
}

export interface StripDay { day: string; met: boolean; n: number; today: boolean }

export function weekStrip(days: Record<string, DayLog>, today: string): StripDay[] {
  const out: StripDay[] = [];
  for (let i = 6; i >= 0; i--) {
    const day = addDays(today, -i);
    const d = days[day];
    out.push({ day, met: d?.met === true, n: d?.n ?? 0, today: i === 0 });
  }
  return out;
}

const WD = ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'];
export function weekdayShort(day: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day);
  if (!m) return '';
  return WD[new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])).getDay()] ?? '';
}

export interface StreakEvent { recordId: string; streak: number; milestone: number | null; best: boolean }

/**
 * Oturum bitince günlük kaydı ve en iyi seriyi günceller. Bu oturumla bugünün hedefi İLK KEZ
 * tutturulduysa kutlama olayı döner.
 */
export function applyRecord(s: SavedState, rec: SessionRecord): { state: SavedState; event: StreakEvent | null } {
  const day = localDateKey(new Date(rec.finishedAt));
  const answered = rec.answers.filter((a) => a !== null).length;
  const wasMet = s.days[day]?.met === true;
  const days = trimDays(logAnswers(s.days, day, answered, s.goal));
  const streak = currentStreak(days, day);
  const best = Math.max(s.best, streak);
  let event: StreakEvent | null = null;
  if (!wasMet && days[day]?.met) {
    const milestone = (STREAK_MILESTONES as readonly number[]).includes(streak) ? streak : null;
    event = { recordId: rec.id, streak, milestone, best: streak > s.best && streak > 1 };
  }
  return { state: { ...s, days, best, qstats: updateQStats(s.qstats, rec) }, event };
}

/** v1.1 verisinden (gün kaydı yokken) geçmiş oturumlarla gün kaydı üretir. */
export function daysFromHistory(history: SessionRecord[], goal: number): Record<string, DayLog> {
  let days: Record<string, DayLog> = {};
  for (const r of history) {
    const day = localDateKey(new Date(r.finishedAt));
    days = logAnswers(days, day, r.answers.filter((a) => a !== null).length, goal);
  }
  return days;
}
