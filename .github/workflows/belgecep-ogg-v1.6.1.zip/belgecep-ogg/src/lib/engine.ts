import type { ActiveSession, Question, SessionKind, SessionMode, SessionRecord, SrsItem, TopicId, TopicStat, Variant } from '../data/types';
import { DENEME_WEIGHTS, PASS_SCORE, SECONDS_PER_QUESTION, SRS_INTERVALS } from '../data/meta';
import { examFormat } from './config';

/** FNV-1a tabanlı sabit hash */
export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Tohumlu sözde rastgele sayı üreteci (mulberry32) */
export function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function shuffle<T>(arr: readonly T[], rand: () => number = Math.random): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const tmp = a[i] as T;
    a[i] = a[j] as T;
    a[j] = tmp;
  }
  return a;
}

/** Bir sorunun ekranda gösterilecek şık sırası: displayOrder[i] = ekrandaki i. şıkkın orijinal indeksi. */
export function displayOrder(qid: string): number[] {
  return shuffle([0, 1, 2, 3, 4], rng(hashString(qid)));
}

export const LETTERS = ['A', 'B', 'C', 'D', 'E'] as const;

export function letterOfOriginal(qid: string, original: number): string {
  const idx = displayOrder(qid).indexOf(original);
  return LETTERS[idx] ?? '?';
}

export function makeId(): string {
  return `${Date.now().toString(36)}-${Math.floor(Math.random() * 1e9).toString(36)}`;
}

export interface NewSessionInput {
  kind: SessionKind;
  mode: SessionMode;
  title: string;
  pool: Question[];
  size: number;
  timed: boolean;
  now: number;
  /** true ise havuz verilen sırayla kullanılır (deneme sınavları önceden dizilir) */
  ordered?: boolean;
  variant?: Variant;
  /** Süreli oturumda toplam süre (sn). Verilmezse soru başına SECONDS_PER_QUESTION. */
  durationSec?: number;
  pass?: number;
}

export function createSession(input: NewSessionInput): ActiveSession | null {
  const picked = (input.ordered ? input.pool.slice() : shuffle(input.pool)).slice(0, Math.max(0, input.size));
  if (picked.length === 0) return null;
  return {
    id: makeId(),
    kind: input.kind,
    mode: input.mode,
    title: input.title,
    qids: picked.map((q) => q.id),
    answers: picked.map(() => null),
    flags: picked.map(() => false),
    index: 0,
    startedAt: input.now,
    endAt: input.timed ? input.now + (input.durationSec ?? picked.length * SECONDS_PER_QUESTION) * 1000 : null,
    ...(input.variant ? { variant: input.variant } : {}),
    ...(input.pass !== undefined ? { pass: input.pass } : {}),
  };
}

/** Az görülen soruları öne alarak havuzdan n soru seçer (eşitlikte rastgele). */
export function pickFresh(pool: Question[], n: number, seen: Map<string, number>, rand: () => number = Math.random): Question[] {
  const keyed = pool.map((q) => ({ q, k: (seen.get(q.id) ?? 0) + rand() * 0.9 }));
  keyed.sort((a, b) => a.k - b.k);
  return keyed.slice(0, Math.max(0, n)).map((x) => x.q);
}

/**
 * Deneme sınavı soru dizisi: ortak bölüm DENEME_WEIGHTS dağılımıyla (karışık sırada),
 * silahlı denemede silah bölümü sona eklenir. Bir dersin sorusu yetmezse eksik kısım diğer derslerden tamamlanır.
 */
/** weights verilirse (ör. bir geçmiş sınavın ders dağılımı) varsayılan ağırlıklar yerine o kullanılır; toplam formatın ortak soru sayısına ölçeklenir. */
export function buildDeneme(bank: Question[], variant: Variant, seen: Map<string, number>, rand: () => number = Math.random, weights: Record<string, number> = DENEME_WEIGHTS): Question[] {
  const f = examFormat(variant);
  const common: Question[] = [];
  if (f.common > 0) {
    const used = new Set<string>();
    for (const [topic, w] of Object.entries(scaleWeights(weights, f.common))) {
      const pool = bank.filter((q) => q.topic === topic);
      for (const q of pickFresh(pool, w, seen, rand)) { common.push(q); used.add(q.id); }
    }
    if (common.length < f.common) {
      const rest = bank.filter((q) => q.topic !== 'silah' && !used.has(q.id));
      common.push(...pickFresh(rest, f.common - common.length, seen, rand));
    }
  }
  const silah = f.silah > 0 ? pickFresh(bank.filter((q) => q.topic === 'silah'), f.silah, seen, rand) : [];
  return [...shuffle(common.slice(0, f.common), rand), ...shuffle(silah, rand)];
}

/** Kayıtlı oturumu soru bankasıyla uzlaştırır: bankadan çıkarılmış sorular atılır, diziler hizalanır. */
export function sanitizeSession(s: ActiveSession, byId: Map<string, Question>): ActiveSession | null {
  const keep: number[] = [];
  s.qids.forEach((id, i) => {
    if (byId.has(id)) keep.push(i);
  });
  if (keep.length === 0) return null;
  const answers = keep.map((i) => {
    const a = s.answers[i];
    return typeof a === 'number' && a >= 0 && a <= 4 ? a : null;
  });
  const flags = keep.map((i) => s.flags[i] === true);
  const qids = keep.map((i) => s.qids[i] as string);
  const index = Math.min(Math.max(0, Math.floor(Number(s.index) || 0)), qids.length - 1);
  return { ...s, qids, answers, flags, index };
}

export function finishSession(s: ActiveSession, byId: Map<string, Question>, now: number): SessionRecord {
  const topicStats: Partial<Record<TopicId, TopicStat>> = {};
  let correct = 0;
  let blank = 0;
  s.qids.forEach((id, i) => {
    const q = byId.get(id);
    if (!q) return;
    const st = topicStats[q.topic] ?? { c: 0, t: 0 };
    st.t += 1;
    const a = s.answers[i];
    if (a === null || a === undefined) blank += 1;
    else if (a === 0) {
      correct += 1;
      st.c += 1;
    }
    topicStats[q.topic] = st;
  });
  const total = s.qids.length;
  let score = total > 0 ? Math.round((correct / total) * 100) : 0;
  const endTime = s.endAt !== null ? Math.min(now, s.endAt) : now;
  let sections: SessionRecord['sections'];
  const P = s.pass ?? PASS_SCORE;
  let passed = score >= P;
  if (s.variant === 'silahli') {
    const silah = topicStats.silah ?? { c: 0, t: 0 };
    const genel = { c: correct - silah.c, t: total - silah.t };
    sections = { genel: { ...genel }, silah: { ...silah } };
    // Yönetmelik md. 39 (RG 04.07.2025): her kısım ayrı ayrı 100 üzerinden; silahlı adayda yazılı iki kısım
    // ve atış ayrı ayrı en az 60. Sınav puanı = genel %50 + silah bilgisi %25 + atış %25.
    // Atış uygulamada ölçülemediği için puan yalnızca iki yazılı kısmın aynı oranlarıyla (2:1) hesaplanır.
    passed = pct(genel) >= P && pct(silah) >= P;
    score = writtenScore(genel, silah);
  }
  return {
    id: s.id,
    kind: s.kind,
    mode: s.mode,
    title: s.title,
    finishedAt: now,
    total,
    correct,
    blank,
    score,
    passed,
    durationSec: Math.max(0, Math.round((endTime - s.startedAt) / 1000)),
    topicStats,
    qids: s.qids.slice(),
    answers: s.answers.slice(),
    ...(s.variant ? { variant: s.variant } : {}),
    ...(s.pass !== undefined ? { pass: s.pass } : {}),
    ...(sections ? { sections } : {}),
  };
}

/** Silahlı yazılı puan: genel kısım ile silah bilgisi kısmı 2:1 ağırlıkla (resmî %50/%25 oranı, atış hariç). */
export function writtenScore(genel: TopicStat, silah: TopicStat): number {
  const g = genel.t > 0 ? genel.c / genel.t : 0;
  const w = silah.t > 0 ? silah.c / silah.t : 0;
  return Math.round(((2 * g + w) / 3) * 100);
}

export function pct(st: TopicStat | undefined): number {
  return st && st.t > 0 ? Math.round((st.c / st.t) * 100) : 0;
}

/**
 * Akıllı tekrar (Leitner): yanlış/boş → kutu 0, bugün tekrar. Defterdeki bir soru doğru cevaplanırsa
 * bir üst kutuya geçer ve 1-3-7-14-30 gün sonra tekrar gelir; son kutuda da doğruysa defterden çıkar.
 * Defterde olmayan bir soruyu doğru cevaplamak deftere eklemez.
 */
export function updateSrs(srs: Record<string, SrsItem>, rec: SessionRecord, today: string): Record<string, SrsItem> {
  const out: Record<string, SrsItem> = { ...srs };
  rec.qids.forEach((id, i) => {
    const a = rec.answers[i];
    if (a !== 0) { out[id] = { box: 0, due: today }; return; }
    const cur = out[id];
    if (!cur) return;
    if (cur.due > today) return; // vadesi gelmeden doğru: takvimi değiştirme
    const box = cur.box + 1;
    if (box > SRS_INTERVALS.length) { delete out[id]; return; }
    out[id] = { box, due: addDays(today, SRS_INTERVALS[box - 1] ?? 30) };
  });
  return out;
}

/** YYYY-MM-DD + n gün */
export function addDays(dateKey: string, n: number): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateKey);
  if (!m) return dateKey;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]) + n);
  return localDateKey(d);
}

export function formatClock(totalSec: number): string {
  const s = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(sec).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

export function formatDuration(totalSec: number): string {
  const s = Math.max(0, Math.round(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h} sa ${m} dk`;
  if (m > 0) return `${m} dk`;
  return `${s} sn`;
}

export function localDateKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** YYYY-MM-DD tarihine kalan tam gün (bugün = 0). Geçmişse negatif. Geçersizse null. */
export function daysUntil(dateStr: string, now: Date): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr);
  if (!m) return null;
  const target = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (Number.isNaN(target.getTime())) return null;
  return Math.round((target.getTime() - today.getTime()) / 86400000);
}

/** YYYY-MM-DD → GG.AA.YYYY */
export function formatDateKey(d: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : d;
}

/** Ağırlıkları toplamı n olacak şekilde ölçekler (en büyük kalan yöntemi). */
export function scaleWeights<K extends string>(w: Record<K, number>, n: number): Record<K, number> {
  const entries = Object.entries(w) as [K, number][];
  const total = entries.reduce((a, [, v]) => a + v, 0);
  if (total === n) return { ...w };
  const raw = entries.map(([k, v]) => ({ k, exact: (v * n) / total }));
  const out = {} as Record<K, number>;
  let used = 0;
  for (const r of raw) { out[r.k] = Math.floor(r.exact); used += out[r.k]; }
  raw.sort((a, b) => (b.exact - Math.floor(b.exact)) - (a.exact - Math.floor(a.exact)));
  for (let i = 0; used < n && i < raw.length; i++, used++) out[(raw[i] as { k: K }).k] += 1;
  return out;
}
