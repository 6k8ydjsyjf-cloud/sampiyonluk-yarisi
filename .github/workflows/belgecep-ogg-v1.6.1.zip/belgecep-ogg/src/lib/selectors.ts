import type { Question, SavedState, SessionRecord, TopicId } from '../data/types';
import { TOPICS } from '../data/meta';
import type { ExamDate } from '../data/types';
import { examDates } from './config';
import { addDays, daysUntil, localDateKey } from './engine';
import { currentStreak } from './streak';

export function todayUsage(s: SavedState, key: 'deneme' | 'study', now: Date): number {
  return s.daily.date === localDateKey(now) ? s.daily[key] : 0;
}

export function bumpUsage(s: SavedState, key: 'deneme' | 'study', n: number, now: Date): SavedState {
  const k = localDateKey(now);
  const base = s.daily.date === k ? s.daily : { date: k, deneme: 0, study: 0 };
  return { ...s, daily: { ...base, [key]: base[key] + n } };
}

/** Geçerli sınav listesi: kullanıcının elle girdiği tarih varsa o, yoksa yapılandırmadaki takvim. */
export function activeExamDates(s: SavedState | null, now: Date = new Date()): ExamDate[] {
  // Elle girilen tarih geçtiyse resmî takvime dönülür
  if (s?.examDate && s.examDate >= localDateKey(now)) return [{ name: 'Sınav tarihim', date: s.examDate }];
  return examDates();
}

export function nextExam(now: Date, s: SavedState | null = null): { name: string; days: number } | null {
  let best: { name: string; days: number } | null = null;
  for (const e of activeExamDates(s, now)) {
    const d = daysUntil(e.date, now);
    if (d === null || d < 0) continue;
    if (!best || d < best.days) best = { name: e.name, days: d };
  }
  return best;
}

export function denemeRecords(s: SavedState): SessionRecord[] {
  return s.history.filter((r) => r.kind === 'deneme' && r.mode === 'exam');
}

export function lastDenemeAverage(s: SavedState, n = 5): number | null {
  const list = denemeRecords(s).slice(-n);
  if (list.length === 0) return null;
  return Math.round(list.reduce((sum, r) => sum + r.score, 0) / list.length);
}

export function topicTotals(s: SavedState): Partial<Record<TopicId, { c: number; t: number }>> {
  const out: Partial<Record<TopicId, { c: number; t: number }>> = {};
  for (const r of s.history) {
    for (const t of TOPICS) {
      const st = r.topicStats[t.id];
      if (!st) continue;
      const cur = out[t.id] ?? { c: 0, t: 0 };
      cur.c += Number(st.c) || 0;
      cur.t += Number(st.t) || 0;
      out[t.id] = cur;
    }
  }
  return out;
}

/** En az 5 soru çözülmüş dersler arasında en zayıf/en güçlü */
export function rankedTopics(s: SavedState): { id: TopicId; pct: number; t: number }[] {
  const totals = topicTotals(s);
  const out: { id: TopicId; pct: number; t: number }[] = [];
  for (const t of TOPICS) {
    const st = totals[t.id];
    if (!st || st.t < 5) continue;
    out.push({ id: t.id, pct: Math.round((st.c / st.t) * 100), t: st.t });
  }
  return out.sort((a, b) => a.pct - b.pct);
}

export function weakestTopic(s: SavedState): { id: TopicId; pct: number } | null {
  return rankedTopics(s)[0] ?? null;
}

export function countByTopic(bank: Question[]): Record<TopicId, number> {
  const out = Object.fromEntries(TOPICS.map((t) => [t.id, 0])) as Record<TopicId, number>;
  for (const q of bank) out[q.topic] = (out[q.topic] ?? 0) + 1;
  return out;
}

export function subtopics(bank: Question[], topic: TopicId): { sub: string; n: number }[] {
  const m = new Map<string, number>();
  for (const q of bank) if (q.topic === topic) m.set(q.sub, (m.get(q.sub) ?? 0) + 1);
  return Array.from(m, ([sub, n]) => ({ sub, n }));
}

/** Geçmişte her sorunun kaç kez sorulduğu */
export function seenCounts(s: SavedState): Map<string, number> {
  const m = new Map<string, number>();
  for (const r of s.history) for (const id of r.qids) m.set(id, (m.get(id) ?? 0) + 1);
  return m;
}

export function dueIds(s: SavedState, today: string): string[] {
  return Object.entries(s.srs).filter(([, v]) => v.due <= today).map(([id]) => id);
}

/** Gün bazında cevaplanan soru sayısı (son n gün, en eski başta) */
export function activity(s: SavedState, now: Date, n: number): { day: string; count: number }[] {
  const today = localDateKey(now);
  const out: { day: string; count: number }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const day = addDays(today, -i);
    out.push({ day, count: s.days[day]?.n ?? 0 });
  }
  return out;
}

/** Günlük hedefin tutturulduğu ardışık gün serisi (bugün ya da dün biten) */
export function streak(s: SavedState, now: Date): number {
  return currentStreak(s.days, localDateKey(now));
}

export interface Totals { answered: number; correct: number; seconds: number; unique: number }

export function totals(s: SavedState): Totals {
  let answered = 0;
  let correct = 0;
  let seconds = 0;
  const unique = new Set<string>();
  for (const r of s.history) {
    seconds += r.durationSec;
    r.answers.forEach((a, i) => {
      if (a === null) return;
      answered += 1;
      if (a === 0) correct += 1;
      const id = r.qids[i];
      if (id) unique.add(id);
    });
  }
  return { answered, correct, seconds, unique: unique.size };
}

/**
 * Hazırlık puanı (0-100): son 300 cevabın doğruluğu %60, ortak soru bankasının kapsanma oranı %25,
 * son 7 gündeki düzenli çalışma %15. Geçme olasılığı DEĞİLDİR. En az 20 cevap yoksa null.
 */
export function readiness(s: SavedState, bank: Question[], now: Date): { score: number; acc: number; cover: number; regular: number } | null {
  const recent: boolean[] = [];
  const seen = new Set<string>();
  for (let i = s.history.length - 1; i >= 0; i--) {
    const r = s.history[i];
    if (!r) continue;
    r.answers.forEach((a, j) => {
      const id = r.qids[j];
      if (a !== null && id) seen.add(id);
    });
    for (let j = r.answers.length - 1; j >= 0 && recent.length < 300; j--) {
      const a = r.answers[j];
      if (a !== null && a !== undefined) recent.push(a === 0);
    }
  }
  if (recent.length < 20) return null;
  const common = bank.filter((q) => q.topic !== 'silah');
  const coveredCount = common.filter((q) => seen.has(q.id)).length;
  const acc = Math.round((recent.filter(Boolean).length / recent.length) * 100);
  const cover = common.length > 0 ? Math.round((coveredCount / common.length) * 100) : 0;
  const regular = Math.round((activity(s, now, 7).filter((d) => d.count > 0).length / 7) * 100);
  const score = Math.round(acc * 0.6 + cover * 0.25 + regular * 0.15);
  return { score: Math.max(0, Math.min(100, score)), acc, cover, regular };
}
