import type { ExamDate, Variant } from '../data/types';
import { CONFIG_URL, DEFAULT_EXAM_DATES, DEFAULT_EXAM_FORMATS, type ExamFormat } from '../data/meta';

/**
 * Güncellenebilir sınav yapılandırması.
 * Sınav tarihleri ve formatları (soru sayısı, süre, baraj) uygulama güncellemesi gerektirmeden
 * docs/ogg-config.json dosyasından okunur. İnternet yoksa son indirilen sürüm, o da yoksa
 * uygulamayla gelen varsayılanlar kullanılır. Dosya bozuksa veya kurallara uymuyorsa yok sayılır.
 */

export interface FormatOverride { common: number; silah: number; minutes: number; pass: number }

export interface RemoteConfig {
  v: 1;
  /** YYYY-MM-DD: dosyanın son güncellendiği gün */
  updated: string;
  examDates: ExamDate[];
  formats?: Partial<Record<Variant, FormatOverride>>;
  /** Ana sayfada gösterilecek kısa duyuru (isteğe bağlı) */
  notice?: string;
}

const CACHE_KEY = 'belgecep.ogg.config';
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

let current: RemoteConfig | null = null;

function isObj(x: unknown): x is Record<string, unknown> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

function int(x: unknown, min: number, max: number): number | null {
  return typeof x === 'number' && Number.isInteger(x) && x >= min && x <= max ? x : null;
}

/** Yapılandırmayı doğrular; en küçük kural ihlalinde null döner (yarım veri uygulanmaz). */
export function validateConfig(x: unknown): RemoteConfig | null {
  if (!isObj(x) || x.v !== 1) return null;
  if (typeof x.updated !== 'string' || !DATE_RE.test(x.updated)) return null;
  if (!Array.isArray(x.examDates)) return null;
  const examDates: ExamDate[] = [];
  for (const e of x.examDates) {
    if (!isObj(e) || typeof e.name !== 'string' || e.name.length < 3 || e.name.length > 80) return null;
    if (typeof e.date !== 'string' || !DATE_RE.test(e.date)) return null;
    examDates.push({ name: e.name, date: e.date });
  }
  let formats: RemoteConfig['formats'];
  if (x.formats !== undefined) {
    if (!isObj(x.formats)) return null;
    formats = {};
    for (const v of ['silahsiz', 'silahli', 'fark'] as const) {
      const f = x.formats[v];
      if (f === undefined) continue;
      if (!isObj(f)) return null;
      const common = int(f.common, 0, 150);
      const silah = int(f.silah, 0, 60);
      const minutes = int(f.minutes, 5, 300);
      const pass = int(f.pass, 1, 100);
      if (common === null || silah === null || minutes === null || pass === null || common + silah === 0) return null;
      formats[v] = { common, silah, minutes, pass };
    }
  }
  const notice = typeof x.notice === 'string' && x.notice.length <= 200 ? x.notice : undefined;
  return { v: 1, updated: x.updated, examDates, ...(formats ? { formats } : {}), ...(notice ? { notice } : {}) };
}

export function loadCachedConfig(): void {
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    current = raw ? validateConfig(JSON.parse(raw)) : null;
  } catch {
    current = null;
  }
}

/** Yapılandırmayı internetten indirir. Başarılı ve önbellektekinden yeni/ farklıysa true döner. */
export async function fetchConfig(timeoutMs = 6000): Promise<boolean> {
  if (typeof fetch !== 'function') return false;
  const ctrl = typeof AbortController === 'function' ? new AbortController() : null;
  const timer = ctrl ? window.setTimeout(() => ctrl.abort(), timeoutMs) : 0;
  try {
    const res = await fetch(`${CONFIG_URL}?t=${Date.now()}`, { cache: 'no-store', ...(ctrl ? { signal: ctrl.signal } : {}) });
    if (!res.ok) return false;
    const cfg = validateConfig(await res.json());
    if (!cfg) return false;
    const changed = JSON.stringify(cfg) !== JSON.stringify(current);
    current = cfg;
    try { window.localStorage.setItem(CACHE_KEY, JSON.stringify(cfg)); } catch { /* yoksay */ }
    return changed;
  } catch {
    return false;
  } finally {
    if (timer) window.clearTimeout(timer);
  }
}

/** Testler ve önizleme için yapılandırmayı doğrudan ayarlar. */
export function setConfig(cfg: RemoteConfig | null): void {
  current = cfg;
}

export function configInfo(): { source: 'remote' | 'default'; updated: string | null; notice: string | null } {
  return current ? { source: 'remote', updated: current.updated, notice: current.notice ?? null } : { source: 'default', updated: null, notice: null };
}

export function examDates(): ExamDate[] {
  return current ? current.examDates : DEFAULT_EXAM_DATES;
}

export function examFormat(v: Variant): ExamFormat {
  const base = DEFAULT_EXAM_FORMATS.find((f) => f.variant === v) ?? (DEFAULT_EXAM_FORMATS[0] as ExamFormat);
  const o = current?.formats?.[v];
  return o ? { ...base, ...o } : base;
}

export function examFormats(): ExamFormat[] {
  return DEFAULT_EXAM_FORMATS.map((f) => examFormat(f.variant));
}
