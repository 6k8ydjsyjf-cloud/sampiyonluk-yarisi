import { isNative } from './native';

/**
 * Sesli okuma. Android uygulamasında @capacitor-community/text-to-speech (cihazın kendi Türkçe sesi),
 * tarayıcıda Web Speech API. İkisi de yoksa özellik kapalı gösterilir.
 */
interface NativeTts {
  speak(o: { text: string; lang?: string; rate?: number; pitch?: number; volume?: number; queueStrategy?: number }): Promise<void>;
  stop(): Promise<void>;
  isLanguageSupported(o: { lang: string }): Promise<{ supported: boolean }>;
  openInstall(): Promise<void>;
}

const LANG = 'tr-TR';
let nativeCache: NativeTts | null | undefined;

async function nativeTts(): Promise<NativeTts | null> {
  if (nativeCache !== undefined) return nativeCache;
  if (!isNative()) { nativeCache = null; return null; }
  try {
    const mod = await import('@capacitor-community/text-to-speech');
    nativeCache = (mod.TextToSpeech as unknown as NativeTts) ?? null;
  } catch {
    nativeCache = null;
  }
  return nativeCache;
}

function webSynth(): SpeechSynthesis | null {
  try {
    return typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis : null;
  } catch {
    return null;
  }
}

export type TtsState = 'ok' | 'no-turkish' | 'unsupported';

export async function ttsState(): Promise<TtsState> {
  const n = await nativeTts();
  if (n) {
    try {
      const r = await n.isLanguageSupported({ lang: LANG });
      return r.supported ? 'ok' : 'no-turkish';
    } catch {
      return 'ok';
    }
  }
  return webSynth() ? 'ok' : 'unsupported';
}

/** Okuma bitince (veya durdurulunca) çözülür. Hata fırlatmaz. */
export async function speak(text: string, rate = 1): Promise<void> {
  const clean = speechText(text);
  if (!clean) return;
  const n = await nativeTts();
  if (n) {
    try { await n.speak({ text: clean, lang: LANG, rate, queueStrategy: 0 }); } catch { /* durduruldu veya motor hatası */ }
    return;
  }
  const s = webSynth();
  if (!s) return;
  await new Promise<void>((resolve) => {
    try {
      const u = new SpeechSynthesisUtterance(clean);
      u.lang = LANG;
      u.rate = rate;
      const done = () => resolve();
      u.onend = done;
      u.onerror = done;
      s.speak(u);
    } catch {
      resolve();
    }
  });
}

export async function stopSpeaking(): Promise<void> {
  const n = await nativeTts();
  if (n) { try { await n.stop(); } catch { /* yoksay */ } return; }
  try { webSynth()?.cancel(); } catch { /* yoksay */ }
}

/** Android: Türkçe ses paketi kurulu değilse ses ayarlarını açar. */
export async function openVoiceInstall(): Promise<void> {
  const n = await nativeTts();
  if (n) { try { await n.openInstall(); } catch { /* yoksay */ } }
}

/** Kısaltmaları okunur hâle getirir. */
export function speechText(t: string): string {
  return t
    .replace(/\bmd\.\s*/gi, 'madde ')
    .replace(/\bs\.\s*Kanun/gi, 'sayılı Kanun')
    .replace(/\bvb\./gi, 've benzeri')
    .replace(/\bTCK\b/g, 'Türk Ceza Kanunu')
    .replace(/\bCMK\b/g, 'Ceza Muhakemesi Kanunu')
    .replace(/\bTMK\b/g, 'Türk Medeni Kanunu')
    .replace(/\bÖGG\b/g, 'özel güvenlik görevlisi')
    .replace(/\s+/g, ' ')
    .trim();
}
