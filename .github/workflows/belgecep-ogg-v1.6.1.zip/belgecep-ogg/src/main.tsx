import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './theme.css';

function detectLite(): boolean {
  try {
    const nav = navigator as Navigator & { deviceMemory?: number };
    const mem = typeof nav.deviceMemory === 'number' ? nav.deviceMemory : 8;
    const cores = typeof nav.hardwareConcurrency === 'number' ? nav.hardwareConcurrency : 8;
    const supportsBlur = typeof CSS !== 'undefined' && typeof CSS.supports === 'function'
      && (CSS.supports('backdrop-filter', 'blur(2px)') || CSS.supports('-webkit-backdrop-filter', 'blur(2px)'));
    return !supportsBlur || mem <= 3 || cores <= 4;
  } catch {
    return false;
  }
}

if (detectLite()) document.documentElement.classList.add('lite');

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
