import { useState } from 'react';
import type { SavedState } from '../data/types';
import { FREE_DENEME_PER_DAY, PASS_SCORE, topicName } from '../data/meta';
import { cardStatus } from '../lib/card';
import { configInfo, examFormat } from '../lib/config';
import { dueIds, lastDenemeAverage, nextExam, todayUsage, weakestTopic } from '../lib/selectors';
import { StreakCard } from '../components/streak';
import PlanCard from '../components/PlanCard';
import type { DailyPlan, PlanTask } from '../lib/coach';
import { localDateKey } from '../lib/engine';
import { Blobs, ConfirmSheet, Signature } from '../components/ui';
import { IconArrowRight, IconBook, IconCards, IconRepeat } from '../components/icons';
import type { Tab } from '../App';

interface Props {
  state: SavedState;
  onStartDeneme: () => void;
  onStudy: () => void;
  onReview: () => void;
  onResume: () => void;
  onDiscard: () => void;
  onPro: () => void;
  onWrong: () => void;
  onCards: () => void;
  onStreak: () => void;
  plan: DailyPlan;
  onPlanTask: (t: PlanTask) => void;
  onGoal: (g: number) => void;
  onTab: (t: Tab) => void;
}

export default function HomeScreen({ state, onStartDeneme, onStudy, onReview, onResume, onDiscard, onPro, onWrong, onCards, onStreak, plan, onPlanTask, onGoal, onTab }: Props) {
  const now = new Date();
  const exam = nextExam(now, state);
  const notice = configInfo().notice;
  const card = state.cardExpiry ? cardStatus(state.cardExpiry, now) : null;
  const avg = lastDenemeAverage(state);
  const weak = weakestTopic(state);
  const usedDeneme = todayUsage(state, 'deneme', now);
  const leftDeneme = Math.max(0, FREE_DENEME_PER_DAY - usedDeneme);
  const f = examFormat('silahsiz');
  const due = dueIds(state, localDateKey(now)).length;
  const bookSize = Object.keys(state.srs).length;
  const active = state.active;
  const [confirmDiscard, setConfirmDiscard] = useState(false);

  return (
    <>
      <Blobs a="#2F5BEA" b="#8B3CF0" />
      <main className="screen with-nav">
        <header className="between">
          <div className="col" style={{ gap: 2 }}>
            <span className="muted small">Özel Güvenlik Sınavına Hazırlık</span>
            <h1 className="h1">BelgeCep ÖGG</h1>
          </div>
          {state.pro
            ? <span className="pill pill-gold">PRO</span>
            : <button className="btn btn-gold btn-sm" style={{ borderRadius: 999, whiteSpace: 'nowrap', flexShrink: 0 }} onClick={onPro}>Pro'ya geç</button>}
        </header>

        {notice && (
          <section className="glass" style={{ padding: 12, borderColor: 'rgba(143,176,255,.45)' }} role="note">
            <span className="small" style={{ lineHeight: 1.45 }}>{notice}</span>
          </section>
        )}

        {card && card.level !== 'ok' && card.level !== 'soon' && (
          <button className={`card-status card-${card.level}`} style={{ textAlign: 'left', color: '#fff', font: 'inherit' }} onClick={() => onTab('profile')}>
            <span style={{ fontWeight: 800 }}>{card.title}</span>
            <span className="small" style={{ lineHeight: 1.45 }}>{card.text}</span>
          </button>
        )}

        {active && (
          <section className="glass" style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div className="col" style={{ gap: 2 }}>
              <span className="h2">Yarım kalan oturum</span>
              <span className="muted small">{active.title} · {active.answers.filter((a) => a !== null).length}/{active.qids.length} cevaplandı</span>
            </div>
            <div className="row">
              <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={onResume}>Devam et</button>
              <button className="btn btn-glass btn-sm" onClick={() => setConfirmDiscard(true)}>Sil</button>
            </div>
          </section>
        )}

        <section className="glass" style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
          {exam ? (
            <div className="between" style={{ alignItems: 'flex-end' }}>
              <div className="col" style={{ gap: 4 }}>
                <span className="muted small">{exam.name}</span>
                <span className="row" style={{ gap: 8, alignItems: 'baseline' }}>
                  <span className="num" style={{ fontSize: 42, fontWeight: 800, lineHeight: 1 }}>{exam.days === 0 ? 'Bugün' : `${exam.days} gün`}</span>
                  {exam.days > 0 && <span className="muted" style={{ fontSize: 17, fontWeight: 600 }}>kaldı</span>}
                </span>
              </div>
            </div>
          ) : (
            <div className="col" style={{ gap: 4 }}>
              <span className="h2">Sınav takvimi</span>
              <span className="muted small">Bir sonraki sınav tarihini EGM Özel Güvenlik Denetleme Başkanlığı duyurularından takip et.</span>
            </div>
          )}
          <button className="btn btn-primary btn-block" style={{ justifyContent: 'space-between', minHeight: 58 }} onClick={onStartDeneme}>
            <span className="col" style={{ gap: 2, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 16 }}>Silahsız deneme başlat</span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#E3EBFF' }}>{f.common + f.silah} soru · {f.minutes} dakika · baraj {f.pass}</span>
            </span>
            <IconArrowRight />
          </button>
          <div className="between">
            <span className="muted small">
              {state.pro ? 'Pro: sınırsız deneme' : leftDeneme > 0 ? `Bugün ${leftDeneme} ücretsiz deneme hakkın var` : 'Bugünkü ücretsiz hakların bitti · Pro ile sınırsız'}
            </span>
            <button className="btn btn-sm" style={{ background: 'transparent', color: '#8FB0FF', minHeight: 36, padding: 0 }} onClick={() => onTab('exams')}>Silahlı deneme</button>
          </div>
        </section>

        <PlanCard plan={plan} goal={state.goal} onTask={onPlanTask} onGoal={onGoal} />

        <StreakCard state={state} onOpen={onStreak} />

        <section style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
          <button className="glass" style={{ padding: 14, textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 8, color: '#fff' }} onClick={onStudy}>
            <span className="between" style={{ width: '100%' }}><IconBook color="#8FB0FF" />{!state.pro && <span className="tag-pro">PRO</span>}</span>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Çalışma modu</span>
            <span className="muted small">Her soruda anında açıklama{!state.pro ? ' · günde 10 soru ücretsiz' : ''}</span>
          </button>
          <button className="glass" style={{ padding: 14, textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 8, color: '#fff' }} onClick={onReview}>
            <span className="between" style={{ width: '100%' }}><IconRepeat color="#6EE7A8" />{due > 0 ? <span className="tag-due">{due} BUGÜN</span> : !state.pro && <span className="tag-pro">PRO</span>}</span>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Akıllı tekrar</span>
            <span className="muted small">{bookSize === 0 ? 'Yanlışların 1-3-7-14-30 gün aralıkla geri gelir' : `Defterde ${bookSize} soru`}{!state.pro ? ' · günde 10 soru ücretsiz' : ''}</span>
          </button>
        </section>

        <button className="glass row" style={{ padding: 14, gap: 12, color: '#fff', textAlign: 'left' }} onClick={onCards}>
          <IconCards color="#C59BFF" />
          <span className="col" style={{ gap: 2, flex: 1 }}>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Hızlı tekrar kartları</span>
            <span className="muted small">Yanlışlarını soru-cevap kartlarıyla birkaç dakikada gözden geçir</span>
          </span>
          {!state.pro && <span className="tag-pro">PRO</span>}
        </button>


        <section className="glass" style={{ padding: '4px 0' }}>
          <div className="list-row">
            <span>Son denemeler ortalaman</span>
            <span className="num" style={{ fontWeight: 800, color: avg === null ? '#A9B4C8' : avg >= PASS_SCORE ? '#6EE7A8' : '#FFB366' }}>{avg === null ? '—' : avg}</span>
          </div>
          <button className="list-row" onClick={onWrong}>
            <span>Tekrar defteri</span>
            <span style={{ fontWeight: 700, color: '#8FB0FF' }}>{bookSize} soru</span>
          </button>
          <button className="list-row" onClick={() => onTab('topics')}>
            <span>En zayıf konun</span>
            <span style={{ fontWeight: 600, color: weak ? '#FFB366' : '#A9B4C8', textAlign: 'right' }}>{weak ? `${topicName(weak.id)} · %${weak.pct}` : 'Henüz veri yok'}</span>
          </button>
        </section>

        <p className="small" style={{ color: '#8D98AD', lineHeight: 1.45, margin: 0 }}>
          Bağımsız bir hazırlık uygulamasıdır; Emniyet Genel Müdürlüğü veya herhangi bir kamu kurumuyla bağlantısı yoktur. Sorular güncel mevzuata dayanılarak özgün olarak hazırlanmıştır.
        </p>
        <Signature />
      </main>
      {confirmDiscard && (
        <ConfirmSheet
          title="Yarım kalan oturum silinsin mi?"
          text="Bu oturumdaki cevapların kaydedilmeden silinecek."
          confirmLabel="Sil"
          onConfirm={() => { setConfirmDiscard(false); onDiscard(); }}
          onCancel={() => setConfirmDiscard(false)}
        />
      )}
    </>
  );
}
