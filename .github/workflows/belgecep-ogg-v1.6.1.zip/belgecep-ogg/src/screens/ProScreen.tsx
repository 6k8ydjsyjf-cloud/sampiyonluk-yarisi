import { Blobs, Signature } from '../components/ui';
import { IconCheck, IconClose } from '../components/icons';
import { PRIVACY_URL } from '../data/meta';
import { QUESTIONS } from '../data/questions';

const SILAH_COUNT = QUESTIONS.filter((q) => q.topic === 'silah').length;

interface Props {
  isPro: boolean;
  price: string;
  busy: boolean;
  onBuy: () => void;
  onRestore: () => void;
  onClose: () => void;
}

const FEATURES = [
  'Sınırsız silahsız deneme sınavı',
  'Silahlı deneme ve silah farkı sınavı',
  'Geçmiş sınavların ikiz denemeleri: her dönemin birebir ders dağılımıyla',
  `Silah Bilgisi ve Atış: ${SILAH_COUNT} soru, konu testi ve çalışma`,
  'Sınırsız çalışma modu: her soruda anında açıklama ve dayanak',
  'Sınırsız akıllı tekrar ve hızlı tekrar kartları',
  'Dinleme modu: soru, doğru cevap ve açıklama sesli okunur',
  'Sonuçlarda tüm açıklamalar, favori soruları çalışma',
  'Reklamsız, internetsiz kullanım',
];

export default function ProScreen({ isPro, price, busy, onBuy, onRestore, onClose }: Props) {
  return (
    <>
      <Blobs a="#F08A3C" b="#8B3CF0" />
      <main className="screen">
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button className="icon-btn" aria-label="Kapat" onClick={onClose}><IconClose /></button>
        </div>

        <div className="col" style={{ gap: 10 }}>
          <span className="pill pill-gold" style={{ alignSelf: 'flex-start' }}>SINAVA KADAR PRO</span>
          <h1 style={{ margin: 0, fontSize: 31, lineHeight: 1.15, fontWeight: 800, letterSpacing: '-0.02em' }}>Sınava eksiksiz hazırlan, ilk girişte geç.</h1>
          <p style={{ margin: 0, color: '#C8D3E6', lineHeight: 1.5, fontSize: 14 }}>Abonelik yok, otomatik yenileme yok. Bir kez al, sonsuza kadar kullan.</p>
        </div>

        <section className="glass" style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {FEATURES.map((f) => (
            <div key={f} className="row" style={{ alignItems: 'flex-start', gap: 12 }}>
              <span style={{ flexShrink: 0, display: "inline-flex" }}><IconCheck color="#FFB366" /></span>
              <span style={{ fontSize: 15, lineHeight: 1.35 }}>{f}</span>
            </div>
          ))}
        </section>

        <p className="small" style={{ margin: 0, color: '#A9B4C8', lineHeight: 1.5 }}>
          Ücretsiz sürümde de: günde 2 silahsız deneme, 12 ortak dersin tüm konu testleri, günlük plan, madde analizi, geçmiş sınav analizi, karıştırılan konular, cep mevzuatı, kimlik kartı takibi, istatistikler, seri, bildirimler ve yedekleme. Çalışma modu, akıllı tekrar ve kartlar günde toplam 10 soru.
        </p>

        <div className="col" style={{ gap: 10, marginTop: 'auto' }}>
          {isPro ? (
            <div className="glass" style={{ padding: 16, textAlign: 'center' }}>
              <span className="h2">Pro zaten açık. İyi çalışmalar!</span>
            </div>
          ) : (
            <>
              <div className="between" style={{ alignItems: 'baseline' }}>
                <span style={{ fontSize: 13, fontWeight: 800, letterSpacing: '0.04em', color: '#FFD7A6' }}>TEK SEFERLİK ÖDEME</span>
                <span className="num" style={{ fontSize: 30, fontWeight: 800 }}>{price}</span>
              </div>
              <button className="btn btn-gold btn-block" style={{ minHeight: 58, fontSize: 17 }} onClick={onBuy} disabled={busy}>
                {busy ? 'İşleniyor…' : "Pro'yu aç"}
              </button>
              <span className="muted small" style={{ textAlign: 'center' }}>Ödeme Google Play üzerinden alınır.</span>
            </>
          )}
          <div className="row" style={{ justifyContent: 'center', gap: 20 }}>
            <button className="btn btn-sm" style={{ background: 'transparent', color: '#A9B4C8' }} onClick={onRestore} disabled={busy}>Satın alımı geri yükle</button>
            <a className="btn btn-sm" style={{ color: '#A9B4C8' }} href={PRIVACY_URL} rel="noopener noreferrer">Gizlilik</a>
          </div>
        </div>
        <Signature />
      </main>
    </>
  );
}
