import { useEffect, useState, type MutableRefObject } from 'react';
import type { Question, SavedState, TopicId } from '../data/types';
import { TOPICS, TOPIC_TEST_SIZE } from '../data/meta';
import { countByTopic, subtopics, topicTotals } from '../lib/selectors';
import { Bar, Blobs, Sheet, Signature } from '../components/ui';
import { IconArrowRight, IconHeadphones, IconLock, IconScale, IconStar, IconSwap } from '../components/icons';

interface Props {
  bank: Question[];
  state: SavedState;
  backRef: MutableRefObject<(() => boolean) | null>;
  onStart: (t: TopicId, mode: 'exam' | 'study', sub?: string) => void;
  onFavs: () => void;
  onPro: () => void;
  onConfusables: () => void;
  onMevzuat: () => void;
  onListen: () => void;
}

export default function TopicsScreen({ bank, state, backRef, onStart, onFavs, onPro, onConfusables, onMevzuat, onListen }: Props) {
  const counts = countByTopic(bank);
  const totals = topicTotals(state);
  const [open, setOpen] = useState<TopicId | null>(null);
  const openTopic = TOPICS.find((t) => t.id === open) ?? null;

  useEffect(() => {
    backRef.current = () => {
      if (open === null) return false;
      setOpen(null);
      return true;
    };
    return () => { backRef.current = null; };
  }, [backRef, open]);

  return (
    <>
      <Blobs a="#2F5BEA" b="#1FAE6B" />
      <main className="screen with-nav">
        <h1 className="h1">Konular</h1>
        <p className="muted small" style={{ margin: 0 }}>Yürürlükteki temel eğitim müfredatının 12 ortak dersi ve silahlılar için Silah Bilgisi ve Atış. 12 ortak dersin konu testleri ücretsizdir; Silah Bilgisi Pro ile açılır.</p>

        <section className="tool-grid" aria-label="Pratik araçlar">
          <button className="glass tool-btn" onClick={onConfusables}><IconSwap color="#A57BFF" /><span>Karıştırılan konular</span></button>
          <button className="glass tool-btn" onClick={onMevzuat}><IconScale color="#8FB0FF" /><span>Cep mevzuatı</span></button>
          <button className="glass tool-btn" onClick={onListen}>
            <span className="between" style={{ width: '100%' }}><IconHeadphones color="#6EE7A8" />{!state.pro && <span className="tag-pro">PRO</span>}</span>
            <span>Dinleme modu</span>
          </button>
        </section>

        <button className="glass row" style={{ padding: 14, color: '#fff', textAlign: 'left' }} onClick={onFavs}>
          <IconStar color="#FFB366" filled />
          <span className="col" style={{ gap: 2, flex: 1 }}>
            <span style={{ fontSize: 15, fontWeight: 700 }}>Favori sorularım</span>
            <span className="muted small">{state.favs.length === 0 ? 'Soru ekranındaki yıldızla ekle' : `${state.favs.length} soru · açıklamalı çöz`}</span>
          </span>
          {!state.pro && <span className="tag-pro">PRO</span>}
        </button>

        <section className="col" style={{ gap: 10 }}>
          {TOPICS.map((t, i) => {
            const n = counts[t.id];
            const st = totals[t.id];
            const p = st && st.t > 0 ? Math.round((st.c / st.t) * 100) : null;
            return (
              <button key={t.id} className="glass" style={{ padding: 14, textAlign: 'left', color: '#fff', display: 'flex', flexDirection: 'column', gap: 10 }}
                onClick={() => (t.id === 'silah' && !state.pro ? onPro() : n > 0 ? setOpen(t.id) : undefined)} aria-disabled={n === 0}>
                <span className="between" style={{ width: '100%', alignItems: 'flex-start' }}>
                  <span style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.3 }}>
                    <span className="muted" style={{ fontWeight: 600 }}>{t.id === 'silah' ? 'S' : i + 1}. </span>{t.name}
                  </span>
                  {n === 0 ? <span className="tag-soon">YAKINDA</span>
                    : t.id === 'silah' && !state.pro ? <span className="row" style={{ gap: 6, whiteSpace: 'nowrap' }}><IconLock size={15} color="#FFB366" /><span className="tag-pro">PRO</span></span>
                    : <span className="muted small" style={{ whiteSpace: 'nowrap' }}>{n} soru</span>}
                </span>
                {n > 0 && (
                  <span className="col" style={{ gap: 6, width: '100%' }}>
                    <Bar pct={p ?? 0} warn={p !== null && p < 60} />
                    <span className="muted small">{t.id === 'silah' && !state.pro ? `${n} soru · silahlı adaylar için, Pro ile açılır` : p === null ? 'Henüz çözülmedi' : `Başarın %${p} · ${st?.t ?? 0} cevap`}</span>
                  </span>
                )}
              </button>
            );
          })}
        </section>
        <Signature />
      </main>
      {openTopic && (
        <Sheet title={openTopic.name} onClose={() => setOpen(null)}>
          <button className="btn btn-primary btn-block" onClick={() => { setOpen(null); onStart(openTopic.id, 'exam'); }}>
            Konu testi · {Math.min(TOPIC_TEST_SIZE, counts[openTopic.id])} soru
          </button>
          <button className="btn btn-glass btn-block" onClick={() => { setOpen(null); onStart(openTopic.id, 'study'); }}>
            Çalışma modu{state.pro ? '' : ' · PRO'}
          </button>
          {!state.pro && (
            <button className="btn btn-sm" style={{ background: 'transparent', color: '#FFB366' }} onClick={() => { setOpen(null); onPro(); }}>
              Pro ile sınırsız çalışma
            </button>
          )}
          <span className="muted small" style={{ fontWeight: 700, letterSpacing: '.04em' }}>ALT KONULAR · KONU TESTİ</span>
          <div className="glass" style={{ padding: '2px 0' }}>
            {subtopics(bank, openTopic.id).map(({ sub, n }) => (
              <button key={sub} className="list-row" style={{ width: '100%' }} onClick={() => { setOpen(null); onStart(openTopic.id, 'exam', sub); }}>
                <span style={{ textAlign: 'left', lineHeight: 1.35, padding: '8px 0' }}>{sub}</span>
                <span className="row muted small" style={{ gap: 4, whiteSpace: 'nowrap' }}>{n} soru<IconArrowRight size={16} /></span>
              </button>
            ))}
          </div>
        </Sheet>
      )}
    </>
  );
}
