import { useCallback, useEffect, useRef, useState, type MutableRefObject } from 'react';
import type { ActiveSession, Question } from '../data/types';
import { DIFFICULTY_LABEL, topicName } from '../data/meta';
import { LETTERS, displayOrder, formatClock, formatDateKey } from '../lib/engine';
import { Blobs, ConfirmSheet, Sheet, Signature } from '../components/ui';
import { IconAlert, IconClock, IconClose, IconFlag, IconGrid, IconStar } from '../components/icons';

interface Props {
  session: ActiveSession;
  byId: Map<string, Question>;
  favs: Set<string>;
  backRef: MutableRefObject<(() => boolean) | null>;
  onPatch: (fn: (a: ActiveSession) => ActiveSession) => void;
  onFinish: () => void;
  onExit: () => void;
  onFav: (id: string) => void;
  onReport: (q: Question) => void;
}

type Dialog = null | 'exit' | 'finish' | 'map';

export default function SessionScreen({ session, byId, favs, backRef, onPatch, onFinish, onExit, onFav, onReport }: Props) {
  const [dialog, setDialog] = useState<Dialog>(null);
  const [now, setNow] = useState(() => Date.now());
  const finishedRef = useRef(false);
  const scrollRef = useRef<HTMLElement | null>(null);

  const total = session.qids.length;
  const idx = Math.min(Math.max(0, session.index), total - 1);
  const qid = session.qids[idx] ?? '';
  const q = byId.get(qid);
  const chosen = session.answers[idx] ?? null;
  const flagged = session.flags[idx] === true;
  const study = session.mode === 'study';
  const revealed = study && chosen !== null;
  const answeredCount = session.answers.filter((a) => a !== null).length;
  const remainingSec = session.endAt !== null ? Math.max(0, Math.ceil((session.endAt - now) / 1000)) : null;

  const finishOnce = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    onFinish();
  }, [onFinish]);

  // Sayaç
  useEffect(() => {
    if (session.endAt === null) return;
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [session.endAt]);

  useEffect(() => {
    if (remainingSec !== null && remainingSec <= 0) finishOnce();
  }, [remainingSec, finishOnce]);

  // Soru değişince başa kaydır
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [idx]);

  // Android geri tuşu
  useEffect(() => {
    backRef.current = () => {
      if (dialog) { setDialog(null); return true; }
      setDialog('exit');
      return true;
    };
    return () => { backRef.current = null; };
  }, [backRef, dialog]);

  const goTo = (i: number) => {
    const n = Math.min(Math.max(0, i), total - 1);
    onPatch((a) => ({ ...a, index: n }));
  };

  const choose = (original: number) => {
    if (revealed) return;
    onPatch((a) => {
      const answers = a.answers.slice();
      answers[idx] = original;
      return { ...a, answers };
    });
  };

  const toggleFlag = () => {
    onPatch((a) => {
      const flags = a.flags.slice();
      flags[idx] = !flags[idx];
      return { ...a, flags };
    });
  };

  if (!q) {
    // Soru bulunamazsa (çok uç durum) güvenle oturumu bitir.
    return (
      <main className="screen" style={{ justifyContent: 'center', alignItems: 'center' }}>
        <p className="muted">Soru yüklenemedi.</p>
        <button className="btn btn-primary" onClick={finishOnce}>Oturumu bitir</button>
      </main>
    );
  }

  const order = displayOrder(q.id);
  const isFav = favs.has(q.id);
  const isLast = idx === total - 1;
  const unanswered = total - answeredCount;

  return (
    <>
      <Blobs a="#2F5BEA" b="#8B3CF0" />
      <header style={{ position: 'relative', zIndex: 2, padding: 'calc(14px + var(--safe-top)) 18px 0 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div className="between">
          <button className="icon-btn" aria-label="Oturumdan çık" onClick={() => setDialog('exit')}><IconClose /></button>
          <div className="col" style={{ alignItems: 'center', gap: 2 }}>
            <span className="muted small" style={{ maxWidth: 190, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{session.title}</span>
            <span style={{ fontSize: 15, fontWeight: 800 }}>Soru {idx + 1} / {total}</span>
          </div>
          {remainingSec !== null ? (
            <span className="row num" style={{ gap: 6, minHeight: 44, padding: '0 12px', borderRadius: 14, background: 'rgba(255,255,255,.08)', border: '1px solid var(--stroke)', fontWeight: 800, color: remainingSec < 300 ? '#FFB366' : '#fff' }} aria-label="Kalan süre">
              <IconClock color="#8FB0FF" />{formatClock(remainingSec)}
            </span>
          ) : (
            <span className="pill pill-glass">{study ? 'Çalışma' : 'Süresiz'}</span>
          )}
        </div>
        <div className="bar" aria-hidden="true"><i style={{ width: `${Math.round(((idx + 1) / total) * 100)}%` }} /></div>
      </header>

      <main className="screen with-bar" ref={scrollRef} style={{ paddingTop: 16 }}>
        <div className="between" style={{ alignItems: 'flex-start' }}>
          <span className="col" style={{ gap: 4, minWidth: 0 }}>
            <span className="pill pill-glass" style={{ alignSelf: 'flex-start', maxWidth: '100%' }}>{topicName(q.topic)}</span>
            <span className="muted small" style={{ paddingLeft: 4 }}>{q.sub} · {DIFFICULTY_LABEL[q.d]}</span>
          </span>
          <span className="row" style={{ gap: 2, flexShrink: 0 }}>
            <button className="icon-btn" style={{ background: 'transparent', border: 0 }} onClick={() => onFav(q.id)} aria-pressed={isFav} aria-label={isFav ? 'Favorilerden çıkar' : 'Favorilere ekle'}>
              <IconStar color={isFav ? '#FFB366' : '#A9B4C8'} filled={isFav} />
            </button>
            {!study && (
              <button className="row" style={{ border: 0, background: 'transparent', color: flagged ? '#FFB366' : '#A9B4C8', fontWeight: 600, fontSize: 13, minHeight: 44, gap: 6 }} onClick={toggleFlag} aria-pressed={flagged}>
                <IconFlag />{flagged ? 'İşaretli' : 'İşaretle'}
              </button>
            )}
          </span>
        </div>

        <p style={{ margin: 0, fontSize: 18, lineHeight: 1.5, fontWeight: 650 }}>{q.q}</p>

        <div className="col" style={{ gap: 10 }} role="radiogroup" aria-label="Şıklar">
          {order.map((orig, i) => {
            let cls = 'opt';
            if (revealed) {
              if (orig === 0) cls += ' correct';
              else if (orig === chosen) cls += ' wrong';
            } else if (orig === chosen) cls += ' selected';
            return (
              <button key={orig} className={cls} role="radio" aria-checked={orig === chosen} onClick={() => choose(orig)} disabled={revealed && orig !== chosen && orig !== 0}>
                <span className="letter">{LETTERS[i]}</span>
                <span>{q.o[orig]}</span>
              </button>
            );
          })}
        </div>

        {revealed && (
          <div className="explain">
            <strong style={{ color: chosen === 0 ? '#6EE7A8' : '#FF8A8A' }}>{chosen === 0 ? 'Doğru!' : `Yanlış. Doğru cevap: ${LETTERS[order.indexOf(0)]}`}</strong>
            <span>{q.e}</span>
            <span className="pill pill-glass" style={{ alignSelf: 'flex-start', whiteSpace: 'normal' }}>Dayanak: {q.ref}</span>
            <span className="between small" style={{ color: '#8D98AD' }}>
              <span>Son kontrol: {formatDateKey(q.checked)}</span>
              <button className="row" style={{ border: 0, background: 'transparent', color: '#A9B4C8', gap: 4, minHeight: 36, fontSize: 12, padding: 0 }} onClick={() => onReport(q)}>
                <IconAlert size={14} />Hata bildir
              </button>
            </span>
          </div>
        )}

        {!study && <span className="small" style={{ color: '#8D98AD' }}>Sınav modunda doğru cevaplar ve açıklamalar sınav bitince gösterilir.</span>}
        <Signature />
      </main>

      <div className="action-bar">
        <button className="btn btn-glass btn-sm" disabled={idx === 0} onClick={() => goTo(idx - 1)}>Önceki</button>
        <button className="icon-btn" aria-label="Soru haritası" onClick={() => setDialog('map')} style={{ width: 48, height: 48, borderRadius: 16 }}><IconGrid /></button>
        {isLast ? (
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => (study ? finishOnce() : setDialog('finish'))}>Bitir</button>
        ) : (
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => goTo(idx + 1)} disabled={study && chosen === null}>
            {study && chosen === null ? 'Bir şık seç' : 'Sonraki'}
          </button>
        )}
      </div>

      {dialog === 'exit' && (
        <ConfirmSheet
          title="Oturumdan çıkılsın mı?"
          text={session.endAt !== null ? 'İlerlemen kaydedilir; ana sayfadan devam edebilirsin. Sınav süresi işlemeye devam eder.' : 'İlerlemen kaydedilir; ana sayfadan devam edebilirsin.'}
          confirmLabel="Kaydet ve çık"
          cancelLabel="Devam et"
          onConfirm={() => { setDialog(null); onExit(); }}
          onCancel={() => setDialog(null)}
        />
      )}
      {dialog === 'finish' && (
        <ConfirmSheet
          title="Sınav bitirilsin mi?"
          text={unanswered > 0 ? `${unanswered} soru boş. Boş sorular yanlış sayılır.` : 'Tüm soruları cevapladın.'}
          confirmLabel="Sınavı bitir"
          cancelLabel="Geri dön"
          onConfirm={() => { setDialog(null); finishOnce(); }}
          onCancel={() => setDialog(null)}
        />
      )}
      {dialog === 'map' && (
        <Sheet title={`Soru haritası · ${answeredCount}/${total}`} onClose={() => setDialog(null)}>
          <div className="grid-map">
            {session.qids.map((id, i) => {
              const cls = [
                session.answers[i] !== null ? 'answered' : '',
                session.flags[i] ? 'flagged' : '',
                i === idx ? 'current' : '',
              ].join(' ').trim();
              return (
                <button key={id} className={cls} aria-label={`Soru ${i + 1}`} onClick={() => { goTo(i); setDialog(null); }}>{i + 1}</button>
              );
            })}
          </div>
          <span className="muted small">Mavi: cevaplandı · Turuncu çerçeve: işaretli</span>
          <button className="btn btn-primary btn-block" onClick={() => setDialog(study ? null : 'finish')}>
            {study ? 'Kapat' : 'Sınavı bitir'}
          </button>
          {study && <button className="btn btn-glass btn-block" onClick={() => { setDialog(null); finishOnce(); }}>Oturumu bitir</button>}
        </Sheet>
      )}
    </>
  );
}
