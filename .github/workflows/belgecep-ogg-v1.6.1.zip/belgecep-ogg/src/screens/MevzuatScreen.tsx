import { useState } from 'react';
import type { TopicId } from '../data/types';
import { LAW_CARDS, MEVZUAT_CHECKED } from '../data/mevzuat';
import { Blobs, Signature } from '../components/ui';
import { IconBack } from '../components/icons';

interface Props {
  onBack: () => void;
  onPractice: (topic: TopicId, sub?: string) => void;
}

export default function MevzuatScreen({ onBack, onPractice }: Props) {
  const [open, setOpen] = useState<string | null>(LAW_CARDS[0]?.id ?? null);

  return (
    <>
      <Blobs a="#2F5BEA" b="#F08A3C" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={onBack}><IconBack /></button>
          <span className="h2" style={{ textAlign: 'center' }}>Cep mevzuatı</span>
          <span style={{ width: 44 }} />
        </div>
        <p className="muted small" style={{ margin: 0, lineHeight: 1.5 }}>
          Görevde ve sınavda en çok bakılan hükümlerin kısa özeti. İnternetsiz çalışır. Kanun metninin yerine geçmez; güncel metin için mevzuat.gov.tr.
        </p>

        {LAW_CARDS.map((c) => {
          const isOpen = open === c.id;
          return (
            <section key={c.id} id={`law-${c.id}`} className="glass" style={{ padding: 0, overflow: 'hidden' }}>
              <button className="list-row" style={{ width: '100%', borderBottom: 'none' }} aria-expanded={isOpen} onClick={() => {
                setOpen(isOpen ? null : c.id);
                if (!isOpen) requestAnimationFrame(() => document.getElementById(`law-${c.id}`)?.scrollIntoView({ block: 'start', behavior: 'smooth' }));
              }}>
                <span className="col" style={{ gap: 2, alignItems: 'flex-start', padding: '10px 0', textAlign: 'left' }}>
                  <span style={{ fontWeight: 750 }}>{c.title}</span>
                  <span className="muted small">{c.ref}</span>
                </span>
                <span className="muted" style={{ fontSize: 20, lineHeight: 1 }}>{isOpen ? '−' : '+'}</span>
              </button>
              {isOpen && (
                <div className="col" style={{ gap: 8, padding: '0 16px 16px' }}>
                  {c.items.map((it) => (
                    <span key={it} className="law-item">{it}</span>
                  ))}
                  {c.note && <span className="small" style={{ color: '#FFC98A', lineHeight: 1.45 }}>{c.note}</span>}
                  {c.practice && (
                    <button className="btn btn-glass btn-block btn-sm" onClick={() => onPractice(c.practice!.topic, c.practice!.sub)}>Bu konudan soru çöz</button>
                  )}
                </div>
              )}
            </section>
          );
        })}
        <span className="small" style={{ color: '#8D98AD' }}>Son kontrol: {MEVZUAT_CHECKED}</span>
        <Signature />
      </main>
    </>
  );
}
