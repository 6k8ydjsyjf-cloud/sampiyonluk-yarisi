import { useEffect, useState } from 'react';
import type { NotifSettings, SavedState } from '../data/types';
import { APP_VERSION, EGM_EXAMS_URL, PRIVACY_URL } from '../data/meta';
import { localDateKey } from '../lib/engine';
import { notifPermission, planNotifications, type PermissionState } from '../lib/notify';
import { readBackup, type ReadResult } from '../lib/backup';
import { configInfo, examDates } from '../lib/config';
import { formatDateKey } from '../lib/engine';
import { nextExam } from '../lib/selectors';
import { Blobs, ConfirmSheet, Sheet, Switch, Signature } from '../components/ui';
import { IconArrowRight, IconCard } from '../components/icons';
import { cardStatus, expiryFromExam } from '../lib/card';

function whenLabel(d: Date, now: Date): string {
  const day = localDateKey(d);
  const today = localDateKey(now);
  const tomorrow = localDateKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));
  const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  if (day === today) return `Bugün ${hm}`;
  if (day === tomorrow) return `Yarın ${hm}`;
  try {
    return `${d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' })} ${hm}`;
  } catch {
    return `${day} ${hm}`;
  }
}

interface Props {
  state: SavedState;
  bankSize: number;
  busy: boolean;
  onPro: () => void;
  onRestore: () => void;
  onReset: () => void;
  onNotif: (patch: Partial<NotifSettings>) => void;
  onStreak: () => void;
  onExport: () => void;
  onImport: (r: Extract<ReadResult, { ok: true }>) => void;
  onExamDate: (date: string | null) => void;
  onCardExpiry: (date: string | null) => void;
}

function fmtTime(ms: number): string {
  try {
    return new Date(ms).toLocaleString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export default function ProfileScreen({ state, bankSize, busy, onPro, onRestore, onReset, onNotif, onStreak, onExport, onImport, onExamDate, onCardExpiry }: Props) {
  const [cardEdit, setCardEdit] = useState(false);
  const card = state.cardExpiry ? cardStatus(state.cardExpiry, new Date()) : null;
  const [confirm, setConfirm] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [pasted, setPasted] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const [pendingImport, setPendingImport] = useState<Extract<ReadResult, { ok: true }> | null>(null);
  const cfg = configInfo();
  const exam = nextExam(new Date(), state);
  const tryImport = (text: string) => {
    const r = readBackup(text);
    if (r.ok) { setImportError(null); setImportOpen(false); setPendingImport(r); }
    else setImportError(r.message);
  };
  const onFile = (e: { target: { files: FileList | null; value: string } }) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (f.size > 5_000_000) { setImportError('Dosya çok büyük; bu bir BelgeCep yedeği olamaz.'); return; }
    const reader = new FileReader();
    reader.onload = () => tryImport(typeof reader.result === 'string' ? reader.result : '');
    reader.onerror = () => setImportError('Dosya okunamadı.');
    reader.readAsText(f);
  };
  const [perm, setPerm] = useState<PermissionState>('prompt');
  useEffect(() => {
    let alive = true;
    void notifPermission().then((p) => { if (alive) setPerm(p); });
    return () => { alive = false; };
  }, [state.notif.on]);
  const now = new Date();
  const next = planNotifications(state, now)[0];
  const n = state.notif;
  const exams = state.history.filter((r) => r.kind === 'deneme').length;

  return (
    <>
      <Blobs a="#F08A3C" b="#2F5BEA" />
      <main className="screen with-nav">
        <h1 className="h1">Profil</h1>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="between">
            <span className="h2">Üyelik</span>
            {state.pro ? <span className="pill pill-gold">PRO</span> : <span className="pill pill-glass">Ücretsiz</span>}
          </div>
          {state.pro
            ? <span className="muted small">Pro tek seferlik satın alındı. Tüm özellikler açık.</span>
            : <button className="btn btn-gold btn-block" onClick={onPro}>Pro'ya geç</button>}
          <button className="btn btn-glass btn-sm" disabled={busy} onClick={onRestore}>{busy ? 'Kontrol ediliyor…' : 'Satın alımı geri yükle'}</button>
        </section>

        <section className="glass" style={{ padding: '4px 0' }}>
          <div className="list-row">
            <span className="col" style={{ gap: 2, padding: '8px 0' }}>
              <span style={{ fontWeight: 700 }}>Hatırlatmalar</span>
              <span className="muted small">Günde en fazla bir bildirim</span>
            </span>
            <Switch on={n.on} label="Hatırlatmalar" onChange={(v) => onNotif({ on: v })} />
          </div>
          {n.on && (
            <>
              <div className="list-row">
                <span>Saat</span>
                <input className="time-input" type="time" aria-label="Hatırlatma saati" value={n.time}
                  onChange={(e: { target: { value: string } }) => { if (/^\d{2}:\d{2}$/.test(e.target.value)) onNotif({ time: e.target.value }); }} />
              </div>
              <div className="list-row"><span>Günlük hedef ve seri</span><Switch on={n.daily} label="Günlük hedef ve seri" onChange={(v) => onNotif({ daily: v })} /></div>
              <div className="list-row"><span>Akıllı tekrar</span><Switch on={n.review} label="Akıllı tekrar" onChange={(v) => onNotif({ review: v })} /></div>
              <div className="list-row"><span>Sınav geri sayımı</span><Switch on={n.exam} label="Sınav geri sayımı" onChange={(v) => onNotif({ exam: v })} /></div>
              <div className="list-row" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 3, padding: '10px 14px' }}>
                <span className="muted small">Sıradaki bildirim</span>
                {next ? (
                  <>
                    <span style={{ fontWeight: 700 }}>{whenLabel(next.at, now)} · {next.title}</span>
                    <span className="muted small" style={{ lineHeight: 1.4 }}>{next.body}</span>
                  </>
                ) : <span className="muted small">Önümüzdeki günler için planlı bildirim yok.</span>}
                {perm === 'denied' && <span className="small" style={{ color: '#FFB366', lineHeight: 1.4 }}>Bildirim izni kapalı. Telefon ayarları › Uygulamalar › BelgeCep ÖGG › Bildirimler'den aç.</span>}
              </div>
            </>
          )}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <span className="h2">Sınav tarihi</span>
          <span className="muted small" style={{ lineHeight: 1.45 }}>
            {exam ? `${exam.name}: ${exam.days === 0 ? 'bugün' : `${exam.days} gün kaldı`}.` : 'Takvimde yaklaşan sınav yok.'}{' '}
            {state.examDate ? 'Kendi girdiğin tarih kullanılıyor.' : cfg.source === 'remote' ? `Takvim ${formatDateKey(cfg.updated ?? '')} tarihinde güncellendi.` : 'Uygulamadaki takvim kullanılıyor.'}
          </span>
          <div className="between">
            <span className="small">Kendi sınav tarihim</span>
            <input className="time-input" type="date" aria-label="Kendi sınav tarihim" value={state.examDate ?? ''}
              onChange={(e: { target: { value: string } }) => onExamDate(/^\d{4}-\d{2}-\d{2}$/.test(e.target.value) ? e.target.value : null)} />
          </div>
          {state.examDate && <button className="btn btn-glass btn-sm" onClick={() => onExamDate(null)}>Resmî takvime dön{examDates()[0] ? ` (${examDates()[0]?.name})` : ''}</button>}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }} aria-label="Kimlik kartım">
          <span className="row" style={{ gap: 8 }}><IconCard color="#8FB0FF" /><span className="h2">Kimlik kartım</span></span>
          {card ? (
            <>
              <div className={`card-status card-${card.level}`}>
                <span style={{ fontWeight: 800 }}>{card.title}</span>
                <span className="small" style={{ lineHeight: 1.45 }}>{card.text}</span>
              </div>
              <span className="muted small">Bitiş tarihi: {formatDateKey(state.cardExpiry ?? '')}</span>
              <div className="row" style={{ gap: 8 }}>
                <button className="btn btn-glass btn-sm" style={{ flex: 1 }} onClick={() => setCardEdit(true)}>Tarihi değiştir</button>
                <button className="btn btn-glass btn-sm" style={{ flex: 1 }} onClick={() => onCardExpiry(null)}>Kaldır</button>
              </div>
            </>
          ) : (
            <span className="muted small" style={{ lineHeight: 1.45 }}>
              Özel güvenlik kimlik kartın beş yıl geçerlidir. Bitiş tarihini gir; yenileme eğitimi zamanı gelince seni uyaralım. Kartın yoksa bu bölümü boş bırakabilirsin.
            </span>
          )}
          {(!card || cardEdit) && (
            <>
              <div className="between">
                <span className="small">Kartın bitiş tarihi</span>
                <input className="time-input" type="date" aria-label="Kimlik kartı bitiş tarihi" value={state.cardExpiry ?? ''}
                  onChange={(e: { target: { value: string } }) => { if (/^\d{4}-\d{2}-\d{2}$/.test(e.target.value)) { onCardExpiry(e.target.value); setCardEdit(false); } }} />
              </div>
              <div className="between">
                <span className="small" style={{ lineHeight: 1.35 }}>veya ilk kart için<br />sınavı geçtiğin tarih</span>
                <input className="time-input" type="date" aria-label="Sınavı geçtiğim tarih"
                  onChange={(e: { target: { value: string } }) => { const x = expiryFromExam(e.target.value); if (x) { onCardExpiry(x); setCardEdit(false); } }} />
              </div>
              <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45 }}>İlk kartın süresi, başarılı olunan sınav tarihine beş yıl eklenerek belirlenir. Kartının üstündeki tarih farklıysa onu gir.</span>
            </>
          )}
          {card && <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45 }}>Hatırlatmalar 180, 90, 30 ve 7 gün kala, bildirimler açıksa gönderilir.</span>}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <span className="h2">Yedekleme</span>
          <span className="muted small" style={{ lineHeight: 1.45 }}>
            İlerlemen yalnızca bu cihazda saklanır. Telefon değiştirirken veya uygulamayı silmeden önce yedek al; dosyayı Drive'a, e-postana veya WhatsApp'a kaydedebilirsin.
          </span>
          <span className="small" style={{ color: state.lastBackup ? '#6EE7A8' : state.history.length > 0 ? '#FFB366' : 'var(--muted)' }}>
            {state.lastBackup ? `Son yedek: ${fmtTime(state.lastBackup)}` : 'Henüz yedek almadın.'}
          </span>
          <button className="btn btn-primary btn-sm" onClick={onExport}>Yedeği dışa aktar</button>
          <button className="btn btn-glass btn-sm" onClick={() => { setImportError(null); setPasted(''); setImportOpen(true); }}>Yedekten geri yükle</button>
        </section>

        <section className="glass" style={{ padding: '4px 0' }}>
          <button className="list-row" style={{ width: '100%' }} onClick={onStreak}>
            <span>Seri ve günlük hedef</span>
            <span className="row muted small" style={{ gap: 4 }}>{state.goal} soru/gün<IconArrowRight size={16} /></span>
          </button>
          <div className="list-row"><span>Çözülen deneme</span><span className="num" style={{ fontWeight: 700 }}>{exams}</span></div>
          <div className="list-row"><span>Soru bankası</span><span className="num" style={{ fontWeight: 700 }}>{bankSize} soru · 13 ders</span></div>
          <div className="list-row"><span>Favori soru</span><span className="num" style={{ fontWeight: 700 }}>{state.favs.length}</span></div>
          <a className="list-row" href={EGM_EXAMS_URL} rel="noopener noreferrer">
            <span>Resmî sınav kitapçıkları (EGM)</span><span className="muted small">Aç</span>
          </a>
          <a className="list-row" href={PRIVACY_URL} rel="noopener noreferrer">
            <span>Gizlilik politikası</span><span className="muted small">Aç</span>
          </a>
          <button className="list-row" onClick={() => setConfirm(true)}>
            <span style={{ color: '#FF8A8A' }}>İstatistikleri sıfırla</span><span />
          </button>
        </section>

        <p className="small" style={{ color: '#8D98AD', lineHeight: 1.45, margin: 0 }}>
          BelgeCep ÖGG, Noventra Studios tarafından geliştirilen bağımsız bir hazırlık uygulamasıdır. Emniyet Genel Müdürlüğü veya herhangi bir kamu kurumuyla bağlantısı yoktur. Resmî bilgi ve sınav duyuruları için EGM Özel Güvenlik Denetleme Başkanlığını takip et. Tüm verilerin yalnızca bu cihazda saklanır.
        </p>
        <p className="small" style={{ color: '#5F6B80', margin: 0 }}>Sürüm {APP_VERSION}</p>
        <Signature />
      </main>
      {importOpen && (
        <Sheet title="Yedekten geri yükle" onClose={() => setImportOpen(false)}>
          <label className="btn btn-primary btn-block" style={{ cursor: 'pointer' }}>
            Yedek dosyasını seç
            <input type="file" accept=".json,application/json,text/plain" onChange={onFile} style={{ display: 'none' }} />
          </label>
          <span className="muted small">veya yedek metnini yapıştır:</span>
          <textarea className="paste-box" aria-label="Yedek metni" value={pasted} rows={4} placeholder='{"format":"belgecep-ogg-yedek", ...}'
            onChange={(e: { target: { value: string } }) => setPasted(e.target.value)} />
          <button className="btn btn-glass btn-block" disabled={pasted.trim().length === 0} onClick={() => tryImport(pasted)}>Metinden geri yükle</button>
          {importError && <span className="small" role="alert" style={{ color: '#FF8A8A' }}>{importError}</span>}
        </Sheet>
      )}
      {pendingImport && (
        <ConfirmSheet
          title="Yedek geri yüklensin mi?"
          text={`${pendingImport.createdAt ? `Yedek tarihi: ${fmtTime(Date.parse(pendingImport.createdAt))}. ` : ''}${pendingImport.sessions} oturum içeriyor. Bu cihazdaki mevcut ilerlemen yedektekiyle değiştirilecek. Pro satın alımın etkilenmez.`}
          confirmLabel="Geri yükle"
          onConfirm={() => { const r = pendingImport; setPendingImport(null); onImport(r); }}
          onCancel={() => setPendingImport(null)}
        />
      )}
      {confirm && (
        <ConfirmSheet
          title="İstatistikler sıfırlansın mı?"
          text="Deneme geçmişin, serin, tekrar defterin ve yarım kalan oturumun silinecek. Favorilerin, ayarların ve Pro satın alımın etkilenmez."
          confirmLabel="Sıfırla"
          onConfirm={() => { setConfirm(false); onReset(); }}
          onCancel={() => setConfirm(false)}
        />
      )}
    </>
  );
}
