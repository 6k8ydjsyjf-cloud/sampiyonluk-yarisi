import { useCallback, useEffect, useRef, useState } from 'react';
import type { Question, SavedState, TopicId } from '../data/types';
import { TOPICS, topicName } from '../data/meta';
import { displayOrder, LETTERS, letterOfOriginal, shuffle } from '../lib/engine';
import { openVoiceInstall, speak, stopSpeaking, ttsState, type TtsState } from '../lib/tts';
import { Blobs, Signature } from '../components/ui';
import { IconBack, IconPause, IconPlay, IconPrev, IconSkip } from '../components/icons';

interface Props {
  bank: Question[];
  state: SavedState;
  onBack: () => void;
}

type Source = 'mix' | 'book' | TopicId;
type Phase = 'question' | 'think' | 'answer' | 'gap';

export const LISTEN_SIZE = 20;
const RATES = [0.85, 1, 1.15] as const;
const THINK_MS = 4000;
const GAP_MS = 1200;

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export default function ListenScreen({ bank, state, onBack }: Props) {
  const [tts, setTts] = useState<TtsState | null>(null);
  const [source, setSource] = useState<Source>('mix');
  const [rate, setRate] = useState<number>(1);
  const [withOptions, setWithOptions] = useState(true);
  const [list, setList] = useState<Question[] | null>(null);
  const [idx, setIdx] = useState(0);
  const [phase, setPhase] = useState<Phase>('question');
  const [playing, setPlaying] = useState(false);
  const run = useRef(0);

  useEffect(() => { void ttsState().then(setTts); }, []);
  useEffect(() => () => { run.current++; void stopSpeaking(); }, []);

  const bookIds = Object.keys(state.srs);
  const poolFor = (s: Source): Question[] => {
    if (s === 'mix') return bank.filter((q) => q.topic !== 'silah');
    if (s === 'book') return bookIds.map((id) => bank.find((q) => q.id === id)).filter((q): q is Question => q !== undefined);
    return bank.filter((q) => q.topic === s);
  };

  const play = useCallback(async (items: Question[], from: number, startPhase: Phase = 'question') => {
    const my = ++run.current;
    const alive = () => run.current === my;
    setPlaying(true);
    for (let i = from; i < items.length && alive(); i++) {
      const q = items[i] as Question;
      setIdx(i);
      const order = displayOrder(q.id);
      const first = i === from ? startPhase : 'question';
      if (first === 'question') {
        setPhase('question');
        let text = `Soru ${i + 1}. ${q.q}`;
        if (withOptions) text += ' ' + order.map((o, k) => `${LETTERS[k]} şıkkı: ${q.o[o]}.`).join(' ');
        await speak(text, rate);
        if (!alive()) return;
        setPhase('think');
        await wait(THINK_MS);
        if (!alive()) return;
      }
      if (first === 'question' || first === 'think' || first === 'answer') {
        setPhase('answer');
        await speak(`Doğru cevap ${letterOfOriginal(q.id, 0)} şıkkı: ${q.o[0]}. ${q.e}`, rate);
        if (!alive()) return;
      }
      setPhase('gap');
      await wait(GAP_MS);
    }
    if (alive()) { setPlaying(false); setPhase('gap'); setIdx(items.length); }
  }, [rate, withOptions]);

  const start = () => {
    const pool = poolFor(source);
    if (pool.length === 0) return;
    const items = shuffle(pool).slice(0, LISTEN_SIZE);
    setList(items);
    void play(items, 0);
  };

  const pause = () => { run.current++; setPlaying(false); void stopSpeaking(); };
  const resume = () => { if (list) void play(list, idx, phase === 'answer' || phase === 'gap' ? 'answer' : 'question'); };
  const jump = (to: number) => {
    if (!list) return;
    run.current++;
    if (to >= list.length) { setPlaying(false); void stopSpeaking(); setIdx(list.length); return; }
    void stopSpeaking().then(() => {
      const t = Math.max(0, Math.min(list.length - 1, to));
      setIdx(t); setPhase('question');
      void play(list, t);
    });
  };
  const close = () => { run.current++; void stopSpeaking(); onBack(); };

  const q = list && idx < list.length ? list[idx] : null;
  const done = list !== null && idx >= list.length;
  const sources: { id: Source; label: string; n: number }[] = [
    { id: 'mix', label: 'Karışık', n: poolFor('mix').length },
    { id: 'book', label: 'Tekrar defterim', n: bookIds.length },
    ...TOPICS.map((t) => ({ id: t.id as Source, label: t.name, n: poolFor(t.id).length })),
  ];

  return (
    <>
      <Blobs a="#1FAE6B" b="#2F5BEA" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={close}><IconBack /></button>
          <span className="h2" style={{ textAlign: 'center' }}>Dinleme modu</span>
          <span style={{ width: 44 }} />
        </div>

        {tts === 'unsupported' && (
          <section className="glass" style={{ padding: 16 }}>
            <span className="small" style={{ lineHeight: 1.5 }}>Bu cihazda sesli okuma desteklenmiyor.</span>
          </section>
        )}
        {tts === 'no-turkish' && (
          <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span className="small" style={{ lineHeight: 1.5 }}>Telefonunda Türkçe ses paketi kurulu görünmüyor. Ses ayarlarından Türkçe sesi indirip tekrar dene.</span>
            <button className="btn btn-glass btn-sm" onClick={() => void openVoiceInstall()}>Ses ayarlarını aç</button>
          </section>
        )}

        {!list ? (
          <>
            <p className="muted small" style={{ margin: 0, lineHeight: 1.5 }}>
              Soru ve şıklar okunur, {THINK_MS / 1000} saniye düşünme süresi verilir, ardından doğru cevap ve açıklama okunur. Yolda veya vardiyada kulaklıkla dinle. Okuma sırasında ekran açık kalmalı.
            </p>
            <span className="muted small" style={{ fontWeight: 700, letterSpacing: '.04em' }}>NEYİ DİNLEYECEKSİN?</span>
            <section className="glass" style={{ padding: '4px 0' }}>
              {sources.map((s) => (
                <button key={s.id} className="list-row" style={{ width: '100%' }} aria-pressed={source === s.id} disabled={s.n === 0} onClick={() => setSource(s.id)}>
                  <span style={{ textAlign: 'left', padding: '8px 0', fontWeight: source === s.id ? 800 : 500, color: source === s.id ? '#8FB0FF' : undefined }}>{s.label}</span>
                  <span className="muted small" style={{ whiteSpace: 'nowrap' }}>{s.n} soru{source === s.id ? ' ✓' : ''}</span>
                </button>
              ))}
            </section>
            <div className="between">
              <span className="small">Okuma hızı</span>
              <span className="row" style={{ gap: 6 }}>
                {RATES.map((r) => (
                  <button key={r} className={`pill ${rate === r ? 'pill-on' : 'pill-glass'}`} aria-pressed={rate === r} onClick={() => setRate(r)}>{r === 1 ? 'Normal' : r < 1 ? 'Yavaş' : 'Hızlı'}</button>
                ))}
              </span>
            </div>
            <div className="between">
              <span className="small">Şıkları da oku</span>
              <button className={`pill ${withOptions ? 'pill-on' : 'pill-glass'}`} aria-pressed={withOptions} onClick={() => setWithOptions(!withOptions)}>{withOptions ? 'Açık' : 'Kapalı'}</button>
            </div>
            <button className="btn btn-primary btn-block" disabled={tts !== 'ok' || poolFor(source).length === 0} onClick={start}>
              Dinlemeye başla · {Math.min(LISTEN_SIZE, poolFor(source).length)} soru
            </button>
          </>
        ) : done ? (
          <section className="glass" style={{ padding: 18, display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'center', textAlign: 'center' }}>
            <span className="h2">Dinleme bitti</span>
            <span className="muted small">{list.length} soruyu dinledin. Şimdi bir konu testiyle pekiştirebilirsin.</span>
            <button className="btn btn-primary btn-block" onClick={() => { setList(null); setIdx(0); }}>Yeniden başla</button>
            <button className="btn btn-glass btn-block" onClick={close}>Kapat</button>
          </section>
        ) : q && (
          <>
            <span className="between small">
              <span className="muted">{topicName(q.topic)}</span>
              <span className="num" style={{ fontWeight: 700 }}>Soru {idx + 1} / {list.length}</span>
            </span>
            <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }} aria-live="polite">
              <span style={{ fontSize: 16, fontWeight: 650, lineHeight: 1.45 }}>{q.q}</span>
              {displayOrder(q.id).map((o, k) => {
                const reveal = phase === 'answer' || phase === 'gap';
                const right = o === 0;
                return (
                  <span key={o} className="small" style={{ lineHeight: 1.4, padding: '8px 10px', borderRadius: 12, background: reveal && right ? 'rgba(110,231,168,.14)' : 'rgba(255,255,255,.04)', color: reveal && right ? '#6EE7A8' : undefined, fontWeight: reveal && right ? 700 : 500 }}>
                    {LETTERS[k]}) {q.o[o]}
                  </span>
                );
              })}
              <span className="small" style={{ color: phase === 'think' ? '#FFC98A' : '#8D98AD', fontWeight: 700 }}>
                {phase === 'question' ? 'Soru okunuyor…' : phase === 'think' ? 'Düşünme süresi…' : phase === 'answer' ? 'Cevap okunuyor…' : playing ? 'Sıradaki soru…' : 'Duraklatıldı'}
              </span>
              {(phase === 'answer' || phase === 'gap') && <span className="small" style={{ lineHeight: 1.5 }}>{q.e}</span>}
            </section>
            <div className="row" style={{ gap: 10, justifyContent: 'center' }}>
              <button className="icon-btn" aria-label="Önceki soru" disabled={idx === 0} onClick={() => jump(idx - 1)}><IconPrev /></button>
              {playing
                ? <button className="icon-btn listen-main" aria-label="Duraklat" onClick={pause}><IconPause size={26} /></button>
                : <button className="icon-btn listen-main" aria-label="Devam et" onClick={resume}><IconPlay size={26} /></button>}
              <button className="icon-btn" aria-label="Sonraki soru" onClick={() => jump(idx + 1)}><IconSkip /></button>
            </div>
            <button className="btn btn-glass btn-block btn-sm" onClick={() => { pause(); setList(null); setIdx(0); }}>Bitir</button>
          </>
        )}
        <Signature />
      </main>
    </>
  );
}
