import type { Question } from '../data/types';
import { topicName } from '../data/meta';
import { CONFUSABLES, confusableQuestions, type Confusable } from '../data/confusables';
import { Blobs, Signature } from '../components/ui';
import { IconArrowRight, IconBack } from '../components/icons';

interface Props {
  bank: Question[];
  /** Açık grup; null ise liste */
  id: string | null;
  onOpen: (id: string | null) => void;
  onBack: () => void;
  onDrill: (c: Confusable, pool: Question[]) => void;
}

export default function ConfusablesScreen({ bank, id, onOpen, onBack, onDrill }: Props) {
  const c = id ? CONFUSABLES.find((x) => x.id === id) ?? null : null;
  const pool = c ? confusableQuestions(c, bank) : [];

  return (
    <>
      <Blobs a="#8B3CF0" b="#2F5BEA" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={c ? () => onOpen(null) : onBack}><IconBack /></button>
          <span className="h2" style={{ textAlign: 'center' }}>{c ? c.title : 'Karıştırılan konular'}</span>
          <span style={{ width: 44 }} />
        </div>

        {c ? (
          <>
            <span className="muted small">{topicName(c.topic)}</span>
            <section className="glass" style={{ padding: '4px 0' }}>
              {c.items.map((it) => (
                <div key={it.name} className="list-row" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: 4, padding: '12px 16px' }}>
                  <span style={{ fontWeight: 800, color: '#8FB0FF' }}>{it.name}</span>
                  <span style={{ lineHeight: 1.45 }}>{it.key}</span>
                </div>
              ))}
            </section>
            <section className="glass" style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 4 }}>
              <span className="small" style={{ fontWeight: 800, color: '#FFC98A', letterSpacing: '.04em' }}>AKILDA TUT</span>
              <span style={{ lineHeight: 1.45 }}>{c.tip}</span>
              <span className="muted small">Dayanak: {c.ref}</span>
            </section>
            <button className="btn btn-primary btn-block" disabled={pool.length === 0} onClick={() => onDrill(c, pool)}>
              Bu konudan soru çöz · {Math.min(10, pool.length)} soru
            </button>
          </>
        ) : (
          <>
            <p className="muted small" style={{ margin: 0, lineHeight: 1.5 }}>
              Resmî sınavlarda birbirinin yerine şık olarak verilen kavramlar. Farkı tek satırda gör, hemen ardından o konudan soru çöz.
            </p>
            <section className="glass" style={{ padding: '4px 0' }}>
              {CONFUSABLES.map((x) => (
                <button key={x.id} className="list-row" style={{ width: '100%' }} onClick={() => onOpen(x.id)}>
                  <span className="col" style={{ gap: 2, alignItems: 'flex-start', padding: '8px 0', textAlign: 'left' }}>
                    <span style={{ fontWeight: 650 }}>{x.title}</span>
                    <span className="muted small">{x.items.map((i) => i.name).join(' · ')}</span>
                  </span>
                  <IconArrowRight size={18} color="#8FB0FF" />
                </button>
              ))}
            </section>
          </>
        )}
        <Signature />
      </main>
    </>
  );
}
