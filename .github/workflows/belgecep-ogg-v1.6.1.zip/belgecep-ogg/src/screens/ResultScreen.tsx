import { useState } from 'react';
import type { QStat, Question, SessionRecord, TopicId } from '../data/types';
import { DIFFICULTY_LABEL, FREE_EXPLANATIONS, PASS_SCORE, PLAY_URL, TOPICS, topicName } from '../data/meta';
import { analyzeRecord } from '../lib/analysis';
import { formatDuration, letterOfOriginal, pct } from '../lib/engine';
import { shareText } from '../lib/native';
import { Bar, Blobs, Signature } from '../components/ui';
import { IconAlert, IconBack, IconLock, IconShare, IconStar } from '../components/icons';

interface Props {
  record: SessionRecord;
  byId: Map<string, Question>;
  isPro: boolean;
  favs: Set<string>;
  qstats: Record<string, QStat>;
  onStudySub: (topic: TopicId, sub: string) => void;
  onBack: () => void;
  onPro: () => void;
  onReview: () => void;
  onFav: (id: string) => void;
  onReport: (q: Question) => void;
  onToast: (t: string) => void;
}

export default function ResultScreen({ record, byId, isPro, favs, qstats, onStudySub, onBack, onPro, onReview, onFav, onReport, onToast }: Props) {
  const [filter, setFilter] = useState<'wrong' | 'all'>('wrong');
  const [sharing, setSharing] = useState(false);
  const isExam = record.mode === 'exam';
  const wrongCount = record.total - record.correct;
  const canSeeAll = isPro || record.mode === 'study';

  const items = record.qids
    .map((id, i) => ({ q: byId.get(id), a: record.answers[i] ?? null, n: i + 1 }))
    .filter((x): x is { q: Question; a: number | null; n: number } => x.q !== undefined)
    .filter((x) => (filter === 'all' ? true : x.a !== 0));

  const share = async () => {
    if (sharing) return;
    setSharing(true);
    try {
      const label = record.variant === 'silahli' ? 'silahlı deneme' : record.variant === 'fark' ? 'silah farkı deneme' : 'deneme';
      const text = record.kind === 'deneme'
        ? `BelgeCep ÖGG ${label} sınavında ${record.score} puan aldım${record.passed ? ' ve barajı geçtim' : ''}! Özel güvenlik sınavına sen de hazırlan:`
        : `BelgeCep ÖGG ile özel güvenlik sınavına çalışıyorum: ${record.correct}/${record.total} doğru. Sen de hazırlan:`;
      const r = await shareText('BelgeCep ÖGG', text, PLAY_URL);
      if (r === 'copied') onToast('Metin panoya kopyalandı.');
      else if (r === 'failed') onToast('Paylaşım açılamadı.');
    } finally {
      setSharing(false);
    }
  };

  const ia = analyzeRecord(record, byId, qstats);
  let explainedSoFar = 0;

  return (
    <>
      <Blobs a={record.passed ? '#1FAE6B' : '#F08A3C'} b="#2F5BEA" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={onBack}><IconBack /></button>
          <span className="h2" style={{ textAlign: 'center' }}>Sonuç</span>
          <button className="icon-btn" aria-label="Sonucu paylaş" onClick={share} disabled={sharing}><IconShare /></button>
        </div>

        <section className="glass" style={{ padding: 22, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, textAlign: 'center' }}>
          {isExam && record.kind === 'deneme' && (
            <span className={`pill ${record.passed ? 'pill-green' : 'pill-red'}`}>{record.passed ? 'BARAJI GEÇTİN' : 'BARAJIN ALTINDA'} · baraj {record.pass ?? PASS_SCORE}</span>
          )}
          <span className="num" style={{ fontSize: 72, fontWeight: 800, lineHeight: 1 }}>{record.score}</span>
          <span className="muted small">{record.title}</span>
          <span className="muted small">{record.correct} doğru · {wrongCount - record.blank} yanlış · {record.blank} boş · {formatDuration(record.durationSec)}</span>
          {record.sections && (
            <div className="row" style={{ gap: 8, marginTop: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
              {([['Ortak dersler', record.sections.genel], ['Silah bilgisi', record.sections.silah]] as const).map(([name, st]) => (
                <span key={name} className={`pill ${pct(st) >= (record.pass ?? PASS_SCORE) ? 'pill-green' : 'pill-red'}`}>{name}: {pct(st)} · {st.c}/{st.t}</span>
              ))}
            </div>
          )}
          {record.sections && (
            <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45, marginTop: 4 }}>
              Resmî sınavda her kısım ayrı ayrı 100 üzerinden puanlanır ve silahlı adayda yazılı iki kısım ile atış sınavının her birinden en az 60 gerekir. Sınav puanı: genel %50, silah bilgisi %25, atış %25. Atış burada ölçülemediği için puan yalnızca yazılı kısımlardan hesaplandı.
            </span>
          )}
          {record.variant === 'fark' && (
            <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45, marginTop: 4 }}>
              Resmî sınavda silah bilgisi yazılı kısmının yanında atış sınavından da en az 60 gerekir.
            </span>
          )}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="h2">Konu bazında</span>
          {TOPICS.filter((t) => record.topicStats[t.id as TopicId]).map((t) => {
            const st = record.topicStats[t.id as TopicId];
            if (!st || st.t === 0) return null;
            const pct = Math.round((st.c / st.t) * 100);
            return (
              <div key={t.id} className="col" style={{ gap: 5 }}>
                <div className="between small"><span>{t.name}</span><span style={{ fontWeight: 700, color: pct < PASS_SCORE ? '#FFB366' : '#fff' }}>%{pct} · {st.c}/{st.t}</span></div>
                <Bar pct={pct} warn={pct < PASS_SCORE} />
              </div>
            );
          })}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }} aria-label="Madde analizi">
          <span className="h2">Madde analizi</span>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 8 }}>
            {([1, 2, 3] as const).map((d) => {
              const st = ia.byDifficulty[d];
              const p = st.t > 0 ? Math.round((st.c / st.t) * 100) : null;
              return (
                <div key={d} className="glass stat-tile" style={{ padding: 10, alignItems: 'center' }}>
                  <span className="muted small">{DIFFICULTY_LABEL[d]}</span>
                  <span className="num" style={{ fontSize: 20, fontWeight: 800 }}>{p === null ? '—' : `%${p}`}</span>
                  <span className="muted small num">{st.c}/{st.t}</span>
                </div>
              );
            })}
          </div>
          {ia.repeatedMistakes > 0 && (
            <span className="small" style={{ color: '#FFB366', lineHeight: 1.45 }}>{ia.repeatedMistakes} soruyu daha önce de yanlış yapmıştın. Bu sorular akıllı tekrarda öne çıkar.</span>
          )}
          {ia.lostSubs.length > 0 ? (
            <>
              <span className="muted small" style={{ fontWeight: 700, letterSpacing: '.04em' }}>PUAN KAYBETTİĞİN ALT KONULAR</span>
              {ia.lostSubs.slice(0, 6).map((x) => (
                <div key={`${x.topic}|${x.sub}`} className="between" style={{ gap: 8 }}>
                  <span className="col" style={{ gap: 1, minWidth: 0 }}>
                    <span style={{ fontWeight: 650, fontSize: 14 }}>{x.sub}</span>
                    <span className="muted small">{topicName(x.topic)} · {x.lost}/{x.total} soru kayıp</span>
                  </span>
                  <button className="btn btn-glass btn-sm" style={{ minHeight: 38, flexShrink: 0 }} onClick={() => onStudySub(x.topic, x.sub)}>Çalış</button>
                </div>
              ))}
            </>
          ) : (
            <span className="small" style={{ color: '#6EE7A8' }}>Bu oturumda hiç puan kaybetmedin.</span>
          )}
        </section>

        <div className="row" style={{ gap: 8 }}>
          <button className="btn btn-glass btn-block" onClick={share} disabled={sharing}><IconShare size={18} />Sonucumu paylaş</button>
        </div>
        {wrongCount > 0 && (
          <button className="btn btn-primary btn-block" onClick={onReview}>Akıllı tekrara başla{isPro ? '' : ' · PRO'}</button>
        )}

        <div className="seg" role="group" aria-label="Soru filtresi">
          <button aria-pressed={filter === 'wrong'} onClick={() => setFilter('wrong')}>Yanlış/boş ({wrongCount})</button>
          <button aria-pressed={filter === 'all'} onClick={() => setFilter('all')}>Tümü ({record.total})</button>
        </div>

        {items.length === 0 && <p className="muted small" style={{ margin: 0 }}>Bu filtrede soru yok. Tebrikler!</p>}

        {items.map(({ q, a, n }) => {
          const correct = a === 0;
          let showExplain = canSeeAll;
          if (!canSeeAll && !correct && explainedSoFar < FREE_EXPLANATIONS) { showExplain = true; explainedSoFar += 1; }
          if (!canSeeAll && correct) showExplain = true;
          return (
            <section key={q.id} className="glass" style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <span className="between">
                <span className="muted small">Soru {n} · {correct ? 'Doğru' : a === null ? 'Boş' : 'Yanlış'}</span>
                <span className="row" style={{ gap: 0 }}>
                  <button className="icon-btn" style={{ background: 'transparent', border: 0, width: 40, height: 40 }} onClick={() => onReport(q)} aria-label="Hata bildir"><IconAlert color="#8D98AD" /></button>
                  <button className="icon-btn" style={{ background: 'transparent', border: 0, width: 40, height: 40 }} onClick={() => onFav(q.id)} aria-pressed={favs.has(q.id)} aria-label={favs.has(q.id) ? 'Favorilerden çıkar' : 'Favorilere ekle'}>
                    <IconStar size={18} color={favs.has(q.id) ? '#FFB366' : '#8D98AD'} filled={favs.has(q.id)} />
                  </button>
                </span>
              </span>
              <span style={{ fontSize: 14, fontWeight: 650, lineHeight: 1.45 }}>{q.q}</span>
              {!correct && a !== null && (
                <span className="small" style={{ color: '#FF8A8A' }}>Senin cevabın: {letterOfOriginal(q.id, a)}) {q.o[a]}</span>
              )}
              <span className="small" style={{ color: '#6EE7A8', fontWeight: 700 }}>Doğru cevap: {letterOfOriginal(q.id, 0)}) {q.o[0]}</span>
              {showExplain ? (
                <div className="explain" style={{ padding: 12 }}>
                  <span>{q.e}</span>
                  <span className="pill pill-glass" style={{ alignSelf: 'flex-start' }}>Dayanak: {q.ref}</span>
                </div>
              ) : (
                <button className="btn btn-glass btn-sm" onClick={onPro}><IconLock />Açıklamayı gör · PRO</button>
              )}
            </section>
          );
        })}

        <button className="btn btn-glass btn-block" onClick={onBack}>Tamam</button>
        <Signature />
      </main>
    </>
  );
}
