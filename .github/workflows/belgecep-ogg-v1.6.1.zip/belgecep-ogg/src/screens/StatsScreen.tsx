import { useState } from 'react';
import type { Question, SavedState, TopicId } from '../data/types';
import { SUB_STATE_LABEL, subtopicStatus, type SubState } from '../lib/analysis';
import { localDateKey } from '../lib/engine';
import { PASS_SCORE, TOPICS, topicName } from '../data/meta';
import { formatDuration } from '../lib/engine';
import { activity, denemeRecords, rankedTopics, readiness, streak, topicTotals, totals } from '../lib/selectors';
import { Bar, Blobs, Signature } from '../components/ui';
import { IconArrowRight, IconFire } from '../components/icons';

interface Props {
  state: SavedState;
  bank: Question[];
  onWrong: () => void;
  onExams: () => void;
  onStudySub: (topic: TopicId, sub: string) => void;
}

const STATE_COLOR: Record<SubState, string> = { ogrenildi: '#6EE7A8', gelisiyor: '#8FB0FF', zayif: '#FFB366', yeni: '#5F6B80' };

function Ring({ value }: { value: number }) {
  const r = 46;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value));
  const color = v >= 75 ? '#6EE7A8' : v >= 50 ? '#8FB0FF' : '#FFB366';
  return (
    <svg width="116" height="116" viewBox="0 0 116 116" role="img" aria-label={`Hazırlık puanı ${v}`}>
      <circle cx="58" cy="58" r={r} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="11" />
      <circle cx="58" cy="58" r={r} fill="none" stroke={color} strokeWidth="11" strokeLinecap="round"
        strokeDasharray={`${(c * v) / 100} ${c}`} transform="rotate(-90 58 58)" />
      <text x="58" y="66" textAnchor="middle" fill="#fff" fontSize="28" fontWeight="800">{v}</text>
    </svg>
  );
}

export default function StatsScreen({ state, bank, onWrong, onExams, onStudySub }: Props) {
  const [view, setView] = useState<SubState>('zayif');
  const now = new Date();
  const ready = readiness(state, bank, now);
  const t = totals(state);
  const acc = t.answered > 0 ? Math.round((t.correct / t.answered) * 100) : null;
  const days = streak(state, now);
  const act = activity(state, now, 14);
  const maxAct = Math.max(1, ...act.map((d) => d.count));
  const exams = denemeRecords(state).slice(-10);
  const ranked = rankedTopics(state);
  const strongest = ranked.length > 1 ? ranked[ranked.length - 1] : undefined;
  const weakest = ranked[0];
  const tt = topicTotals(state);
  const bookSize = Object.keys(state.srs).length;
  const subs = subtopicStatus(state, bank, localDateKey(now), state.pro);
  const counts: Record<SubState, number> = { ogrenildi: 0, gelisiyor: 0, zayif: 0, yeni: 0 };
  subs.forEach((x) => { counts[x.state] += 1; });
  const list = subs.filter((x) => x.state === view).sort((a, b) => view === 'zayif' ? (a.acc ?? 0) - (b.acc ?? 0) || b.due - a.due : view === 'ogrenildi' ? (b.acc ?? 0) - (a.acc ?? 0) : b.total - a.total);

  return (
    <>
      <Blobs a="#1FAE6B" b="#2F5BEA" />
      <main className="screen with-nav">
        <h1 className="h1">İstatistik</h1>

        <section className="glass row" style={{ padding: 16, gap: 16, alignItems: 'center' }}>
          {ready ? <Ring value={ready.score} /> : <Ring value={0} />}
          <div className="col" style={{ gap: 6, flex: 1 }}>
            <span className="h2">Hazırlık puanı</span>
            {ready ? (
              <>
                <span className="muted small">Doğruluk %{ready.acc} · Kapsama %{ready.cover} · Düzen %{ready.regular}</span>
                <span className="small" style={{ color: '#8D98AD', lineHeight: 1.4 }}>Son cevapların, bankanın ne kadarını gördüğün ve düzenli çalışman. Geçme olasılığı değildir.</span>
              </>
            ) : (
              <span className="muted small" style={{ lineHeight: 1.45 }}>En az 20 soru çözdüğünde hesaplanır.</span>
            )}
          </div>
        </section>

        <section style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
          <div className="glass stat-tile"><span className="muted small">Çözülen soru</span><span className="num stat-num">{t.answered}</span></div>
          <div className="glass stat-tile"><span className="muted small">Doğruluk</span><span className="num stat-num">{acc === null ? '—' : `%${acc}`}</span></div>
          <div className="glass stat-tile"><span className="muted small">Çalışma süresi</span><span className="num stat-num" style={{ fontSize: 20 }}>{formatDuration(t.seconds)}</span></div>
          <div className="glass stat-tile"><span className="muted small">Seri · en iyi {Math.max(state.best, days)}</span><span className="num stat-num row" style={{ gap: 6 }}><IconFire color={days > 0 ? '#FFB366' : '#A9B4C8'} />{days} gün</span></div>
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="between"><span className="h2">Son denemeler</span><span className="muted small">baraj {PASS_SCORE}</span></div>
          {exams.length === 0 ? (
            <button className="btn btn-glass btn-sm" onClick={onExams}>İlk denemeni çöz</button>
          ) : (
            <svg viewBox="0 0 300 140" width="100%" role="img" aria-label="Son deneme puanları">
              <line x1="0" x2="300" y1={130 - PASS_SCORE * 1.2} y2={130 - PASS_SCORE * 1.2} stroke="#FFB366" strokeDasharray="4 4" strokeWidth="1.5" />
              {exams.map((r, i) => {
                const w = 300 / 10;
                const h = Math.max(2, r.score * 1.2);
                return (
                  <g key={r.id}>
                    <rect x={i * w + 5} y={130 - h} width={w - 10} height={h} rx="5" fill={r.passed ? '#3FD38A' : '#5B7CFF'} />
                    <text x={i * w + w / 2} y={124 - h} textAnchor="middle" fill="#C8D3E6" fontSize="10" fontWeight="700">{r.score}</text>
                    <text x={i * w + w / 2} y="139" textAnchor="middle" fill="#8D98AD" fontSize="8">{r.total}</text>
                  </g>
                );
              })}
            </svg>
          )}
        </section>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="between"><span className="h2">Son 14 gün</span><span className="muted small">cevaplanan soru</span></div>
          <svg viewBox="0 0 280 90" width="100%" role="img" aria-label="Son 14 günde cevaplanan soru sayısı">
            {act.map((d, i) => {
              const w = 20;
              const h = d.count > 0 ? Math.max(4, (d.count / maxAct) * 70) : 2;
              return (
                <g key={d.day}>
                  <rect x={i * w + 3} y={76 - h} width={w - 6} height={h} rx="3" fill={d.count > 0 ? '#8FB0FF' : 'rgba(255,255,255,.12)'} />
                  <text x={i * w + w / 2} y="88" textAnchor="middle" fill="#8D98AD" fontSize="8">{d.day.slice(8)}</text>
                </g>
              );
            })}
          </svg>
        </section>

        {(weakest || strongest) && (
          <section className="glass" style={{ padding: '4px 0' }}>
            {weakest && <div className="list-row"><span>En zayıf ders</span><span style={{ fontWeight: 700, color: '#FFB366', textAlign: 'right' }}>{topicName(weakest.id)} · %{weakest.pct}</span></div>}
            {strongest && <div className="list-row"><span>En güçlü ders</span><span style={{ fontWeight: 700, color: '#6EE7A8', textAlign: 'right' }}>{topicName(strongest.id)} · %{strongest.pct}</span></div>}
          </section>
        )}

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }} aria-label="Konu durumu">
          <div className="between"><span className="h2">Konu durumu</span><span className="muted small">{subs.length} alt konu</span></div>
          <div className="seg" role="group" aria-label="Alt konu durumu">
            {(['zayif', 'gelisiyor', 'ogrenildi', 'yeni'] as const).map((k) => (
              <button key={k} aria-pressed={view === k} onClick={() => setView(k)} style={{ fontSize: 12, padding: '0 2px' }}>
                <span className="col" style={{ gap: 0, alignItems: 'center' }}><span className="num" style={{ fontWeight: 800, color: STATE_COLOR[k] }}>{counts[k]}</span><span>{SUB_STATE_LABEL[k]}</span></span>
              </button>
            ))}
          </div>
          <span className="muted small" style={{ lineHeight: 1.45 }}>
            {view === 'zayif' ? 'Başarısı %60\'ın altında olan veya tekrar zamanı gelen sorusu bulunan alt konular.'
              : view === 'ogrenildi' ? 'Başarısı en az %80 olan ve sorularının çoğunu gördüğün alt konular.'
              : view === 'gelisiyor' ? 'Çalışmaya başladığın ama henüz oturmamış alt konular.'
              : 'Henüz hiç soru çözmediğin alt konular.'}
          </span>
          {list.length === 0 ? <span className="muted small">Bu grupta alt konu yok.</span> : list.slice(0, 8).map((x) => (
            <div key={`${x.topic}|${x.sub}`} className="between" style={{ gap: 8 }}>
              <span className="row" style={{ gap: 8, minWidth: 0 }}>
                <span className="state-dot" style={{ background: STATE_COLOR[x.state] }} aria-hidden="true" />
                <span className="col" style={{ gap: 1, minWidth: 0 }}>
                  <span style={{ fontWeight: 650, fontSize: 14 }}>{x.sub}</span>
                  <span className="muted small">{topicName(x.topic)} · {x.seen}/{x.total} soru görüldü{x.acc !== null ? ` · %${x.acc}` : ''}{x.due > 0 ? ` · ${x.due} tekrar` : ''}</span>
                </span>
              </span>
              {x.state !== 'ogrenildi' && <button className="btn btn-glass btn-sm" style={{ minHeight: 38, flexShrink: 0 }} onClick={() => onStudySub(x.topic, x.sub)}>Çalış</button>}
            </div>
          ))}
          {list.length > 8 && <span className="muted small">+{list.length - 8} alt konu daha</span>}
        </section>

        <button className="glass list-row" style={{ color: '#fff', borderRadius: 'var(--radius)' }} onClick={onWrong}>
          <span>Tekrar defteri</span>
          <span className="row" style={{ gap: 6, color: '#8FB0FF', fontWeight: 700 }}>{bookSize} soru<IconArrowRight size={16} /></span>
        </button>

        <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <span className="h2">Ders bazında</span>
          {TOPICS.map((tp) => {
            const st = tt[tp.id];
            const p = st && st.t > 0 ? Math.round((st.c / st.t) * 100) : null;
            return (
              <div key={tp.id} className="col" style={{ gap: 5 }}>
                <div className="between small"><span>{tp.name}</span><span style={{ fontWeight: 700, color: p === null ? '#8D98AD' : p < PASS_SCORE ? '#FFB366' : '#fff', whiteSpace: 'nowrap' }}>{p === null ? '—' : `%${p} · ${st?.c ?? 0}/${st?.t ?? 0}`}</span></div>
                <Bar pct={p ?? 0} warn={p !== null && p < PASS_SCORE} />
              </div>
            );
          })}
        </section>
        <Signature />
      </main>
    </>
  );
}
