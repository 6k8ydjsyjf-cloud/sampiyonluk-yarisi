import type { SavedState, Variant } from '../data/types';
import { COMMON_TOPICS, topicName } from '../data/meta';
import { averageDist, FREQUENT_TOPICS, PAST_EXAMS, type CommonTopic, type PastExam } from '../data/exams';
import { examFormat } from '../lib/config';
import { Blobs, Signature } from '../components/ui';
import { IconBack, IconLock } from '../components/icons';

interface Props {
  state: SavedState;
  /** null: tüm kitapçıkların özeti */
  exam: PastExam | null;
  onBack: () => void;
  onOpen: (id: string) => void;
  onSimulate: (exam: PastExam, v: Variant) => void;
  onStudy: (topic: CommonTopic, sub?: string) => void;
}

function fmt(date: string | null): string {
  if (!date) return 'Kitapçıkta tarih yok';
  const [y, m, d] = date.split('-');
  return `${d}.${m}.${y}`;
}

/** 6'sında, 5'inde, 4'ünde, 3'ünde, 2'sinde, 1'inde */
function inSuffix(n: number): string {
  const s: Record<number, string> = { 1: 'inde', 2: 'sinde', 3: 'ünde', 4: 'ünde', 5: 'inde', 6: 'sında' };
  return `${n}'${s[n] ?? 'inde'}`;
}

function Dist({ dist, total }: { dist: Record<CommonTopic, number>; total: number }) {
  const rows = (COMMON_TOPICS as CommonTopic[]).map((t) => ({ t, n: dist[t] })).sort((a, b) => b.n - a.n);
  const max = Math.max(1, ...rows.map((r) => r.n));
  return (
    <div className="col" style={{ gap: 10 }}>
      {rows.map(({ t, n }) => (
        <div key={t} className="col" style={{ gap: 4 }}>
          <span className="between small">
            <span style={{ fontWeight: 600, minWidth: 0 }}>{topicName(t)}</span>
            <span className="num muted" style={{ whiteSpace: 'nowrap', flexShrink: 0, marginLeft: 8 }}>{n.toLocaleString('tr-TR', { maximumFractionDigits: 1 })} / {total}</span>
          </span>
          <span className="bar" role="img" aria-label={`${topicName(t)}: ${Math.round(n)} soru`}><i style={{ width: `${(n / max) * 100}%` }} /></span>
        </div>
      ))}
    </div>
  );
}

export default function PastExamScreen({ state, exam, onBack, onOpen, onSimulate, onStudy }: Props) {
  const avg = averageDist();
  const avg100 = Object.fromEntries(Object.entries(avg).map(([k, v]) => [k, Math.round(v * 1000) / 10])) as Record<CommonTopic, number>;
  const lock = !state.pro;
  const silahsiz = examFormat('silahsiz');
  const silahli = examFormat('silahli');

  return (
    <>
      <Blobs a="#2F5BEA" b="#A57BFF" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={onBack}><IconBack /></button>
          <span className="h2" style={{ textAlign: 'center' }}>{exam ? exam.short : 'Geçmiş sınav analizi'}</span>
          <span style={{ width: 44 }} />
        </div>

        {exam ? (
          <>
            <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <span style={{ fontWeight: 800, fontSize: 16 }}>{exam.name}</span>
              <span className="muted small">{fmt(exam.date)} · {exam.group} kitapçığı · {exam.common} ortak + {exam.silah} silah sorusu</span>
              {exam.newModules > 0 && (
                <span className="small" style={{ color: '#FFC98A', lineHeight: 1.45 }}>
                  {exam.newModules} soru yeni modüllerden: ÖGDB ve projeleri, problem çözme, grup davranışı, fiziksel müdahale, tutanak. Bu konular bankaya eklendi.
                </span>
              )}
            </section>

            <span className="h2">Ders dağılımı (ortak bölüm)</span>
            <section className="glass" style={{ padding: 16 }}><Dist dist={exam.dist} total={exam.common} /></section>

            <span className="h2">İkiz deneme</span>
            <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
              <span className="muted small" style={{ lineHeight: 1.5 }}>
                Bu sınavın birebir ders dağılımı ve resmî süresiyle, bankadaki özgün sorulardan kurulur. Kitapçıktaki soruların kendisi değildir.
              </span>
              {([['silahsiz', silahsiz], ['silahli', silahli]] as const).map(([v, f]) => (
                <button key={v} className="btn btn-glass btn-block" onClick={() => onSimulate(exam, v)} style={{ justifyContent: 'space-between', textAlign: 'left', minHeight: 60 }}>
                  <span className="col" style={{ gap: 2, alignItems: 'flex-start' }}>
                    <span>{v === 'silahsiz' ? 'Silahsız ikiz' : 'Silahlı ikiz'}</span>
                    <span className="muted small" style={{ fontWeight: 500 }}>{f.common + f.silah} soru · {f.minutes} dakika · baraj {f.pass}</span>
                  </span>
                  {lock ? <span className="row" style={{ gap: 6 }}><IconLock size={15} color="#FFB366" /><span className="tag-pro">PRO</span></span> : null}
                </button>
              ))}
            </section>
          </>
        ) : (
          <>
            <section className="glass" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <span style={{ fontWeight: 800 }}>{PAST_EXAMS.length} resmî kitapçık incelendi</span>
              <span className="muted small" style={{ lineHeight: 1.5 }}>
                EGM Özel Güvenlik Denetleme Başkanlığının yayımladığı kitapçıklardaki 100 ortak soru tek tek okunup derslere ayrıldı. Uygulamadaki denemeler bu ortalamaya göre kurulur.
              </span>
            </section>

            <span className="h2">Ortalama ders dağılımı</span>
            <section className="glass" style={{ padding: 16 }}><Dist dist={avg100} total={100} /></section>
            <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45 }}>
              Mesleki Davranış bu kitapçıklarda ayrı bir ders bloğu olarak yer almadı; konu çalışmasında duruyor, denemelere girmiyor.
            </span>

            <span className="h2">En sık çıkan konular</span>
            <section className="glass" style={{ padding: '4px 0' }}>
              {FREQUENT_TOPICS.map((f) => (
                <button key={f.label} className="list-row" style={{ width: '100%' }} onClick={() => onStudy(f.topic, f.sub)}>
                  <span className="col" style={{ gap: 2, alignItems: 'flex-start', padding: '8px 0', textAlign: 'left' }}>
                    <span style={{ fontWeight: 650 }}>{f.label}</span>
                    <span className="muted small">{PAST_EXAMS.length} sınavın {inSuffix(f.exams)} · yaklaşık {f.approx} soru</span>
                  </span>
                  <span className="pill pill-glass small">Çalış</span>
                </button>
              ))}
            </section>
            <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45 }}>Sayılar anahtar kelime taramasıyla çıkarıldı, yaklaşıktır.</span>

            <span className="h2">Kitapçıklar</span>
            <section className="glass" style={{ padding: '4px 0' }}>
              {PAST_EXAMS.map((e) => (
                <button key={e.id} className="list-row" style={{ width: '100%' }} onClick={() => onOpen(e.id)}>
                  <span className="col" style={{ gap: 2, alignItems: 'flex-start', padding: '8px 0', textAlign: 'left' }}>
                    <span style={{ fontWeight: 650 }}>{e.name}</span>
                    <span className="muted small">{fmt(e.date)} · {e.group} kitapçığı</span>
                  </span>
                  <span className="pill pill-glass small">İncele</span>
                </button>
              ))}
            </section>
          </>
        )}
        <Signature />
      </main>
    </>
  );
}
