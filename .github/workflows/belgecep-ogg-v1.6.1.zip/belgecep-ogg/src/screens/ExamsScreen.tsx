import type { SavedState, Variant } from '../data/types';
import { FREE_DENEME_PER_DAY } from '../data/meta';
import { configInfo, examFormat, examFormats } from '../lib/config';
import { denemeRecords, todayUsage } from '../lib/selectors';
import { PAST_EXAMS } from '../data/exams';
import { Blobs, Signature } from '../components/ui';
import { IconArrowRight, IconLock } from '../components/icons';

interface Props {
  state: SavedState;
  onStart: (v: Variant) => void;
  onPast: () => void;
  onOpenResult: (id: string) => void;
  onPro: () => void;
}

function fmtDate(ms: number): string {
  try {
    return new Date(ms).toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export default function ExamsScreen({ state, onPast, onStart, onOpenResult, onPro }: Props) {
  const left = Math.max(0, FREE_DENEME_PER_DAY - todayUsage(state, 'deneme', new Date()));
  const past = denemeRecords(state).slice().reverse().slice(0, 30);

  return (
    <>
      <Blobs a="#2F5BEA" b="#F08A3C" />
      <main className="screen with-nav">
        <h1 className="h1">Denemeler</h1>
        <p className="muted small" style={{ margin: 0 }}>Gerçek sınav süresi ve soru sayısıyla. Sorular derslere son resmî kitapçıkların ortalama dağılımına göre dağıtılır, daha önce az gördüğün sorular önce gelir.</p>

        <section className="col" style={{ gap: 10 }}>
          {examFormats().map((f) => {
            const locked = f.pro && !state.pro;
            const n = f.common + f.silah;
            return (
              <button key={f.variant} className="glass" style={{ padding: 16, textAlign: 'left', color: '#fff', display: 'flex', flexDirection: 'column', gap: 8 }} onClick={() => onStart(f.variant)}>
                <span className="between" style={{ width: '100%' }}>
                  <span style={{ fontSize: 16, fontWeight: 800 }}>{f.name}</span>
                  {locked ? <span className="row" style={{ gap: 6 }}><IconLock size={15} color="#FFB366" /><span className="tag-pro">PRO</span></span> : <IconArrowRight size={20} color="#8FB0FF" />}
                </span>
                <span className="muted small">{f.desc}</span>
                <span className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                  <span className="pill pill-glass">{n} soru</span>
                  <span className="pill pill-glass">{f.minutes} dakika</span>
                  <span className="pill pill-glass">baraj {f.pass}</span>
                </span>
              </button>
            );
          })}
          <span className="muted small">
            {state.pro ? 'Pro: tüm denemeler sınırsız.' : left > 0 ? `Silahsız denemede bugün ${left} ücretsiz hakkın var.` : 'Bugünkü ücretsiz deneme hakların bitti.'}
            {!state.pro && <button className="btn btn-sm" style={{ background: 'transparent', color: '#FFB366', minHeight: 32, padding: '0 6px' }} onClick={onPro}>Pro'ya geç</button>}
          </span>
          <span className="small" style={{ color: '#8D98AD', lineHeight: 1.45 }}>
            Silahlı denemede iki yazılı kısmın ayrı ayrı barajı geçmesi aranır; resmî sınavda ayrıca atış sınavından da en az 60 gerekir. Soru sayısı, süre ve baraj {configInfo().source === 'remote' ? `${configInfo().updated ?? ''} tarihli güncel yapılandırmaya` : 'uygulamadaki varsayılan değerlere'} göredir; resmî kurallar için EGM duyurularını takip et.
          </span>
        </section>

        <button className="glass" style={{ padding: 16, textAlign: 'left', color: '#fff', display: 'flex', flexDirection: 'column', gap: 6 }} onClick={onPast}>
          <span className="between" style={{ width: '100%' }}>
            <span style={{ fontSize: 16, fontWeight: 800 }}>Geçmiş sınav analizi</span>
            <IconArrowRight size={20} color="#8FB0FF" />
          </span>
          <span className="muted small">{PAST_EXAMS.length} resmî kitapçığın ders dağılımı, en sık çıkan konular ve her dönemin ikiz denemesi.</span>
        </button>

        <span className="h2">Geçmiş denemeler</span>
        {past.length === 0 ? (
          <section className="glass" style={{ padding: 16 }}>
            <span className="muted small">Henüz deneme çözmedin. İlk denemeni çöz; sonuçların burada listelenir.</span>
          </section>
        ) : (
          <section className="glass" style={{ padding: '4px 0' }}>
            {past.map((r) => (
              <button key={r.id} className="list-row" style={{ width: '100%' }} onClick={() => onOpenResult(r.id)}>
                <span className="col" style={{ gap: 2, alignItems: 'flex-start', padding: '8px 0' }}>
                  <span style={{ fontWeight: 650 }}>{r.title.includes('ikizi') ? r.title.split(' · ').slice(0, 2).join(' · ') : r.variant ? examFormat(r.variant).short : 'Deneme'} · {r.correct}/{r.total}</span>
                  <span className="muted small">{fmtDate(r.finishedAt)}</span>
                </span>
                <span className="num" style={{ fontWeight: 800, fontSize: 18, color: r.passed ? '#6EE7A8' : '#FFB366' }}>{r.score}</span>
              </button>
            ))}
          </section>
        )}
        <Signature />
      </main>
    </>
  );
}
