import { useState } from 'react';
import type { Question, SavedState } from '../data/types';
import { SRS_INTERVALS, topicName } from '../data/meta';
import { daysUntil, localDateKey } from '../lib/engine';
import { Blobs, ConfirmSheet, Signature } from '../components/ui';
import { IconBack } from '../components/icons';

interface Props {
  state: SavedState;
  byId: Map<string, Question>;
  onBack: () => void;
  onReview: () => void;
  onCards: () => void;
  onClear: () => void;
}

function dueLabel(due: string, now: Date): string {
  const d = due ? daysUntil(due, now) : 0;
  if (d === null || d <= 0) return 'Bugün';
  if (d === 1) return 'Yarın';
  return `${d} gün sonra`;
}

export default function WrongScreen({ state, byId, onBack, onReview, onCards, onClear }: Props) {
  const [confirm, setConfirm] = useState(false);
  const now = new Date();
  const today = localDateKey(now);
  const items = Object.entries(state.srs)
    .map(([id, s]) => ({ q: byId.get(id), s }))
    .filter((x): x is { q: Question; s: { box: number; due: string } } => x.q !== undefined)
    .sort((a, b) => (a.s.due < b.s.due ? -1 : a.s.due > b.s.due ? 1 : 0));
  const due = items.filter((x) => x.s.due <= today).length;

  return (
    <>
      <Blobs a="#8B3CF0" b="#1FAE6B" />
      <main className="screen">
        <div className="row">
          <button className="icon-btn" aria-label="Geri" onClick={onBack}><IconBack /></button>
          <h1 className="h1">Tekrar defteri</h1>
        </div>
        <p className="muted small" style={{ margin: 0, lineHeight: 1.5 }}>
          Yanlış ya da boş bıraktığın sorular buraya düşer. Doğru çözdükçe {SRS_INTERVALS.join('-')} gün aralıkla yeniden karşına çıkar; son aşamada da doğru çözersen öğrenilmiş sayılır ve defterden çıkar.
        </p>
        {items.length === 0 ? (
          <section className="glass" style={{ padding: 18 }}>
            <p className="h2">Defterin boş</p>
            <p className="muted small" style={{ marginBottom: 0 }}>Bir deneme ya da konu testi çöz; yanlışların otomatik olarak buraya eklenir.</p>
          </section>
        ) : (
          <>
            <section style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
              <div className="glass stat-tile"><span className="muted small">Bugün tekrar</span><span className="num stat-num" style={{ color: due > 0 ? '#6EE7A8' : '#fff' }}>{due}</span></div>
              <div className="glass stat-tile"><span className="muted small">Defterde</span><span className="num stat-num">{items.length}</span></div>
            </section>
            <button className="btn btn-primary btn-block" onClick={onReview}>
              {due > 0 ? `Bugünkü ${due} soruyu tekrar et` : 'Erken tekrar et'}{state.pro ? '' : ' · PRO'}
            </button>
            <button className="btn btn-glass btn-block" onClick={onCards}>Kartlarla hızlı tekrar{state.pro ? '' : ' · PRO'}</button>
            <section className="glass" style={{ padding: '4px 0' }}>
              {items.slice(0, 60).map(({ q, s }) => (
                <div key={q.id} className="list-row" style={{ flexDirection: 'column', alignItems: 'flex-start', padding: '12px 14px', gap: 4 }}>
                  <span className="between small" style={{ width: '100%' }}>
                    <span className="muted">{topicName(q.topic)}</span>
                    <span style={{ color: s.due <= today ? '#6EE7A8' : '#A9B4C8', fontWeight: 700, whiteSpace: 'nowrap' }}>{dueLabel(s.due, now)} · {s.box}/{SRS_INTERVALS.length}</span>
                  </span>
                  <span style={{ lineHeight: 1.4 }}>{q.topic === 'silah' && !state.pro ? 'Silah Bilgisi sorusu · Pro ile açılır' : q.q}</span>
                </div>
              ))}
            </section>
            {items.length > 60 && <p className="muted small" style={{ margin: 0 }}>+{items.length - 60} soru daha</p>}
            <button className="btn btn-glass btn-sm" onClick={() => setConfirm(true)}>Defteri temizle</button>
          </>
        )}
        <Signature />
      </main>
      {confirm && (
        <ConfirmSheet
          title="Defter temizlensin mi?"
          text="Tekrar defterindeki tüm sorular kaldırılacak. Bu işlem geri alınamaz."
          confirmLabel="Temizle"
          onConfirm={() => { setConfirm(false); onClear(); }}
          onCancel={() => setConfirm(false)}
        />
      )}
    </>
  );
}
