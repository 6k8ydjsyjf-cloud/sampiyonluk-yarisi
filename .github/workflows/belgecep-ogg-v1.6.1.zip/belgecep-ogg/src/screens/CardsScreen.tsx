import { useEffect, useState, type MutableRefObject } from 'react';
import type { Question } from '../data/types';
import { topicName } from '../data/meta';
import { Blobs, Signature } from '../components/ui';
import { IconBack } from '../components/icons';

interface Props {
  deck: Question[];
  backRef: MutableRefObject<(() => boolean) | null>;
  onGrade: (qid: string, knew: boolean) => void;
  onClose: () => void;
}

/**
 * Hızlı tekrar kartları: soru → cevabı göster → "Biliyordum / Bilmiyordum".
 * Öz değerlendirme akıllı tekrar takvimini günceller; deneme istatistiklerine ve seriye sayılmaz.
 */
export default function CardsScreen({ deck, backRef, onGrade, onClose }: Props) {
  const [i, setI] = useState(0);
  const [shown, setShown] = useState(false);
  const [knew, setKnew] = useState(0);
  const q = deck[i];
  const finished = i >= deck.length;

  useEffect(() => {
    backRef.current = () => { onClose(); return true; };
    return () => { backRef.current = null; };
  }, [backRef, onClose]);

  const grade = (k: boolean) => {
    if (!q) return;
    onGrade(q.id, k);
    if (k) setKnew((n) => n + 1);
    setShown(false);
    setI((n) => n + 1);
  };

  return (
    <>
      <Blobs a="#1FAE6B" b="#8B3CF0" />
      <main className="screen">
        <div className="between">
          <button className="icon-btn" aria-label="Geri" onClick={onClose}><IconBack /></button>
          <span className="h2">Hızlı tekrar kartları</span>
          <span className="muted small num" style={{ minWidth: 44, textAlign: 'right' }}>{Math.min(i + 1, deck.length)}/{deck.length}</span>
        </div>
        <div className="bar" aria-hidden="true"><i style={{ width: `${Math.round((Math.min(i, deck.length) / Math.max(1, deck.length)) * 100)}%` }} /></div>

        {finished || !q ? (
          <section className="glass" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'center', textAlign: 'center' }}>
            <span className="h1" style={{ fontSize: 22 }}>Kartlar bitti</span>
            <span className="muted">{knew}/{deck.length} kartı bildiğini işaretledin. Bilmediklerin akıllı tekrara eklendi.</span>
            <button className="btn btn-primary btn-block" onClick={onClose}>Tamam</button>
          </section>
        ) : (
          <>
            <section className="glass flash-card" aria-live="polite">
              <span className="pill pill-glass" style={{ alignSelf: 'flex-start' }}>{topicName(q.topic)}</span>
              <span className="muted small">{q.sub}</span>
              <p style={{ margin: 0, fontSize: 18, lineHeight: 1.5, fontWeight: 650 }}>{q.q}</p>
              {shown ? (
                <div className="explain">
                  <strong style={{ color: '#6EE7A8' }}>{q.o[0]}</strong>
                  <span>{q.e}</span>
                  <span className="pill pill-glass" style={{ alignSelf: 'flex-start', whiteSpace: 'normal' }}>Dayanak: {q.ref}</span>
                </div>
              ) : (
                <span className="muted small">Cevabı aklından söyle, sonra kontrol et.</span>
              )}
            </section>
            {shown ? (
              <div className="row" style={{ gap: 10 }}>
                <button className="btn btn-glass" style={{ flex: 1 }} onClick={() => grade(false)}>Bilmiyordum</button>
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => grade(true)}>Biliyordum</button>
              </div>
            ) : (
              <button className="btn btn-primary btn-block" onClick={() => setShown(true)}>Cevabı göster</button>
            )}
          </>
        )}
        <Signature />
      </main>
    </>
  );
}
