export type TopicId =
  | 'hukuk' | 'tedbir' | 'sistem' | 'kolluk' | 'iletisim' | 'kalabalik' | 'koruma'
  | 'uyusturucu' | 'yangin' | 'ilkyardim' | 'olayyeri' | 'meslek' | 'silah';

export type Difficulty = 1 | 2 | 3;

/** Soru. DOĞRU CEVAP HER ZAMAN o[0]'dır; ekranda şıklar soru kimliğine göre sabit bir sırayla karıştırılır. */
export interface Question {
  id: string;
  topic: TopicId;
  /** Alt konu (müfredattaki başlık) */
  sub: string;
  /** Zorluk: 1 kolay, 2 orta, 3 zor */
  d: Difficulty;
  q: string;
  o: [string, string, string, string, string];
  /** Açıklama: doğru cevabın gerekçesi */
  e: string;
  /** Dayanak: kanun maddesi veya resmî eğitim kaynağı */
  ref: string;
  /** İçeriğin kaynakla son karşılaştırıldığı tarih (YYYY-MM-DD) */
  checked: string;
}

export interface Topic {
  id: TopicId;
  name: string;
}

export interface ExamDate {
  name: string;
  /** YYYY-MM-DD, yerel saat */
  date: string;
}

export type SessionMode = 'exam' | 'study';
export type SessionKind = 'deneme' | 'konu' | 'yanlis' | 'favori';
/** Deneme türü: silahsız (100 soru), silahlı (100 + 25 silah), silah farkı (25 silah) */
export type Variant = 'silahsiz' | 'silahli' | 'fark';

export interface ActiveSession {
  id: string;
  kind: SessionKind;
  mode: SessionMode;
  title: string;
  qids: string[];
  /** Kullanıcının seçtiği ORİJİNAL şık indeksi (0 = doğru), cevapsız ise null */
  answers: (number | null)[];
  flags: boolean[];
  index: number;
  startedAt: number;
  /** Süreli sınavlarda bitiş zamanı (ms), süresizse null */
  endAt: number | null;
  /** Yalnızca deneme sınavlarında */
  variant?: Variant;
  /** Oturum başlarken geçerli olan baraj puanı */
  pass?: number;
}

export interface TopicStat {
  c: number;
  t: number;
}

export interface SessionRecord {
  id: string;
  kind: SessionKind;
  mode: SessionMode;
  title: string;
  finishedAt: number;
  total: number;
  correct: number;
  blank: number;
  score: number;
  passed: boolean;
  durationSec: number;
  topicStats: Partial<Record<TopicId, TopicStat>>;
  qids: string[];
  answers: (number | null)[];
  variant?: Variant;
  pass?: number;
  /** Silahlı denemede bölüm sonuçları */
  sections?: { genel: TopicStat; silah: TopicStat };
}

/** Akıllı tekrar kutusu: box 0 = bugün tekrar; doğru cevapla bir üst kutuya çıkar. */
export interface SrsItem {
  box: number;
  /** YYYY-MM-DD; bu tarihte veya sonrasında tekrar edilir */
  due: string;
}

/** Günlük kayıt: cevaplanan soru sayısı ve o gün hedefin tutturulup tutturulmadığı */
export interface DayLog {
  n: number;
  met: boolean;
}

export interface NotifSettings {
  /** Kullanıcı bildirimleri açtı mı (izin ayrıca işletim sisteminden alınır) */
  on: boolean;
  /** HH:MM, yerel saat */
  time: string;
  daily: boolean;
  review: boolean;
  exam: boolean;
}

export interface SavedState {
  v: 2;
  pro: boolean;
  history: SessionRecord[];
  /** Yanlış defteri + akıllı tekrar takvimi */
  srs: Record<string, SrsItem>;
  favs: string[];
  /** YYYY-MM-DD → günlük kayıt (seri için kalıcı; geçmiş 50 oturumla sınırlıyken bu sınırsız sayılır, 400 güne kırpılır) */
  days: Record<string, DayLog>;
  /** Günlük soru hedefi */
  goal: number;
  /** En uzun seri */
  best: number;
  notif: NotifSettings;
  /** Bildirim izni bir kez soruldu mu */
  notifAsked: boolean;
  /** Soru bazında kalıcı istatistik (madde analizi ve konu durumu için) */
  qstats: Record<string, QStat>;
  /** Kullanıcının elle girdiği sınav tarihi (YYYY-MM-DD) veya null */
  examDate: string | null;
  /** Son yedeğin alındığı zaman (ms) veya null */
  lastBackup: number | null;
  daily: { date: string; deneme: number; study: number };
  /** Özel güvenlik kimlik kartının bitiş tarihi (YYYY-AA-GG) veya null */
  cardExpiry: string | null;
  active: ActiveSession | null;
}

/** Soru istatistiği: kaç kez cevaplandı, kaç kez yanlış/boş, son görüldüğü gün */
export interface QStat {
  s: number;
  w: number;
  last: string;
}
