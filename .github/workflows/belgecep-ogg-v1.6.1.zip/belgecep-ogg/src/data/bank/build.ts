import type { Difficulty, Question, TopicId } from '../types';

/** Bankanın kaynakla son karşılaştırma tarihi */
export const CHECKED = '2026-11-16';

/**
 * Kısa satır biçimi: [alt konu, zorluk, soru, [DOĞRU, yanlış, yanlış, yanlış, yanlış], açıklama, dayanak]
 * KURAL: Kimlikler dizideki sıradan üretilir (önek-001, önek-002...). Yeni soruyu SADECE SONA EKLE;
 * araya ekleme veya silme yapma, yoksa kullanıcıların yanlış defteri başka soruları gösterir.
 * Bir soruyu kaldırmak gerekirse satırı silme; RETIRED listesine kimliğini yaz.
 */
export type Row = [string, Difficulty, string, [string, string, string, string, string], string, string];

export function build(topic: TopicId, prefix: string, rows: Row[], retired: string[] = []): Question[] {
  const out: Question[] = [];
  rows.forEach((r, i) => {
    const id = `${prefix}-${String(i + 1).padStart(3, '0')}`;
    if (retired.includes(id)) return;
    out.push({ id, topic, sub: r[0], d: r[1], q: r[2], o: r[3], e: r[4], ref: r[5], checked: CHECKED });
  });
  return out;
}
