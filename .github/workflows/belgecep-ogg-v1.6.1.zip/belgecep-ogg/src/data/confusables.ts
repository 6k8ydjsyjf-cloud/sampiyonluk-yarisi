import type { Question, TopicId } from './types';

/**
 * Karıştırılan konular: resmî kitapçıklarda birbirinin yerine şık olarak verilen kavram grupları.
 * Her grup: kavramları ayıran tek satırlık anahtar + dayanak; `match` ile bankadan ilgili sorular çekilir.
 * Bilgiler soru bankasındaki açıklamalar ve dayanaklarla aynıdır.
 */
export interface ConfusableItem {
  name: string;
  key: string;
}

export interface Confusable {
  id: string;
  title: string;
  topic: TopicId;
  items: ConfusableItem[];
  /** Akılda tutma ipucu */
  tip: string;
  ref: string;
  /** Soru metninde veya şıklarda aranacak ifade (büyük/küçük harf duyarsız) */
  match: string;
}

export const CONFUSABLES: Confusable[] = [
  {
    id: 'mudahale-duzenleri', title: 'Kama, hat ve çember düzeni', topic: 'kalabalik',
    items: [
      { name: 'Kama düzeni', key: 'Kalabalığı bölmek, yanlara dağıtmak, içinden yol açmak.' },
      { name: 'Hat düzeni', key: 'Yan yana dizilip yolu kapatmak, ilerlemeyi durdurmak, alanı korumak.' },
      { name: 'Çember düzeni', key: 'Topluluğun etrafını sarıp kontrol altına almak (gözaltı için).' },
    ],
    tip: 'Kama böler, hat durdurur, çember sarar.',
    ref: 'ÖGG Temel Eğitim · Kalabalık Yönetimi', match: 'kama düzen|hat düzen|çember düzen',
  },
  {
    id: 'kolluk-turleri', title: 'Genel kolluk, özel kolluk, özel güvenlik', topic: 'kolluk',
    items: [
      { name: 'Genel kolluk', key: 'Polis, jandarma, sahil güvenlik: genel emniyet ve asayişten sorumlu.' },
      { name: 'Özel kolluk', key: 'Belirli bir alanda görevli kolluk; örneğin belediye zabıtası.' },
      { name: 'Özel güvenlik', key: 'Kamu güvenliğini tamamlayıcıdır; yetkileri 5188 md. 7 ile sınırlı, yalnızca görev alanında ve süresinde.' },
    ],
    tip: 'Özel güvenlik kolluk değildir; yetkisi kanunda tek tek sayılanlarla sınırlıdır.',
    ref: '5188 s. Kanun md. 1, 7, 9', match: 'genel kolluk|özel kolluk',
  },
  {
    id: 'empati-sempati', title: 'Empati ve sempati', topic: 'iletisim',
    items: [
      { name: 'Empati', key: 'Karşındakinin yerine kendini koyup duygu ve düşüncesini anlamak; onunla aynı duyguya kapılmadan.' },
      { name: 'Sempati', key: 'Karşındakine duyulan olumlu duygu, yakınlık ve beğeni.' },
    ],
    tip: 'Empati anlamaktır, sempati hoşlanmaktır.',
    ref: 'ÖGG Temel Eğitim · Etkili İletişim', match: 'empati|sempati',
  },
  {
    id: 'yangin-siniflari', title: 'Yangın sınıfları', topic: 'yangin',
    items: [
      { name: 'A sınıfı', key: 'Katı maddeler; kor bırakarak yanar (odun, kâğıt, kumaş).' },
      { name: 'B sınıfı', key: 'Sıvı veya sıvılaşabilen katılar (benzin, tiner, gazyağı).' },
      { name: 'C sınıfı', key: 'Gazlar (doğal gaz, LPG).' },
      { name: 'D sınıfı', key: 'Yanabilen metaller (alüminyum, sodyum, titanyum).' },
      { name: 'F sınıfı', key: 'Pişirme yağları (bitkisel ve hayvansal yağlar).' },
    ],
    tip: 'Katı-Sıvı-Gaz-Metal-Yağ sırası: A, B, C, D, F.',
    ref: 'TS EN 2 · Yangın sınıfları', match: 'sınıf',
  },
  {
    id: 'yakalama', title: 'Özel güvenliğin yakalama halleri', topic: 'hukuk',
    items: [
      { name: 'md. 7/c', key: 'CMK 90: suçüstü veya izlenirken yakalama.' },
      { name: 'md. 7/d', key: 'Görev alanında hakkında yakalama emri ya da mahkûmiyet kararı olan kişi.' },
      { name: 'md. 7/ı', key: 'Bir kişinin vücut veya sağlığına yönelik mevcut tehlikeyi önlemek için.' },
      { name: 'md. 7/j', key: 'CMK 168: olay yerini ve delilleri korumak için.' },
    ],
    tip: 'Yakalanan kişi en kısa sürede genel kolluğa teslim edilir (md. 9).',
    ref: '5188 s. Kanun md. 7, 9', match: 'yakala',
  },
  {
    id: 'emanete-alma', title: 'İki tür emanete alma', topic: 'hukuk',
    items: [
      { name: 'md. 7/g', key: 'Aramada bulunan, suç teşkil eden, delil olabilecek veya tehlike doğurabilecek eşya; genel kolluğa derhal bildirme şartıyla.' },
      { name: 'md. 7/h', key: 'Terk edilmiş veya bulunmuş eşya.' },
    ],
    tip: '"Aramada bulunan" eşyada derhal kolluğa bildirim şarttır.',
    ref: '5188 s. Kanun md. 7', match: 'emanet',
  },
  {
    id: 'kimlik-sorma', title: 'Kimlik nerede sorulur?', topic: 'hukuk',
    items: [
      { name: 'Etkinlikler (md. 7/b)', key: 'Toplantı, konser, spor müsabakası, sahne gösterisi, cenaze ve düğün.' },
      { name: 'Toplu ulaşım (md. 7/f)', key: 'Hava meydanı, liman, gar, istasyon ve terminaller.' },
      { name: 'Diğer yerler', key: 'Kimlik sorma yetkisi yoktur; duyarlı kapı, dedektör ve X-ray kontrolü yapılabilir (md. 7/a).' },
    ],
    tip: 'Kimlik sorma yalnızca b ve f bentlerindeki yerlerde.',
    ref: '5188 s. Kanun md. 7', match: 'kimlik sor',
  },
  {
    id: 'grup-asamalari', title: 'Grup gelişim aşamaları', topic: 'kalabalik',
    items: [
      { name: 'Oluşum', key: 'Tanışma, belirsizlik, çekingenlik.' },
      { name: 'Fırtına', key: 'Görüş ayrılıkları, rol ve liderlik çatışması.' },
      { name: 'Kurallar (normlaşma)', key: 'Ortak kurallar benimsenir, uyum ve güven artar.' },
      { name: 'Performans', key: 'Enerji göreve yönelir, grup verimli çalışır.' },
      { name: 'Dağılma', key: 'Görev biter, grup çözülür.' },
    ],
    tip: 'Oluş, fırtına, kural, performans, dağıl.',
    ref: 'ÖGG Temel Eğitim · Grup dinamiği (Tuckman)', match: 'aşama',
  },
  {
    id: 'grup-turleri', title: 'Temel grup ve ikincil grup', topic: 'kalabalik',
    items: [
      { name: 'Temel (birincil) grup', key: 'Yüz yüze, samimi, uzun süreli ilişkiler: aile, yakın arkadaşlar.' },
      { name: 'Temel olmayan (ikincil) grup', key: 'Resmî, kurallı, amaca yönelik ilişkiler: iş yeri, fabrika çalışanları.' },
    ],
    tip: 'Duygu varsa temel, görev varsa ikincil.',
    ref: 'ÖGG Temel Eğitim · Grup dinamiği', match: 'temel grup|ikincil|grup türü|grup dinamiği|birincil',
  },
  {
    id: 'alti-sapka', title: 'Altı düşünce şapkası', topic: 'iletisim',
    items: [
      { name: 'Beyaz', key: 'Bilgi, veri, olgular.' },
      { name: 'Kırmızı', key: 'Duygu ve sezgi.' },
      { name: 'Siyah', key: 'Riskler, tehlikeler, eleştiri.' },
      { name: 'Sarı', key: 'Faydalar, olumlu yönler.' },
      { name: 'Yeşil', key: 'Yaratıcılık, yeni fikirler.' },
      { name: 'Mavi', key: 'Süreci yönetmek, kontrol.' },
    ],
    tip: 'Mor şapka yoktur.',
    ref: 'Edward de Bono · Altı Düşünce Şapkası', match: 'şapka',
  },
  {
    id: 'puko', title: 'Problem çözme teknikleri', topic: 'iletisim',
    items: [
      { name: 'PUKO', key: 'Planla, Uygula, Kontrol et, Önlem al.' },
      { name: '5N1K', key: 'Ne, Nerede, Ne zaman, Nasıl, Neden, Kim.' },
      { name: 'Balık kılçığı', key: 'Neden-sonuç diyagramı (Ishikawa).' },
      { name: 'Beyin fırtınası', key: 'Eleştirisiz, çok sayıda fikir üretmek.' },
    ],
    tip: 'Beyin fırtınası bir tekniktir, PUKO aşaması değildir.',
    ref: 'ÖGG Temel Eğitim · Problem çözme', match: 'puko|5n1k|balık kılçığı|beyin fırtınası',
  },
  {
    id: 'xray-renkleri', title: 'X-ray ekran renkleri', topic: 'sistem',
    items: [
      { name: 'Turuncu', key: 'Organik maddeler.' },
      { name: 'Yeşil', key: 'Karışık veya orta yoğunluktaki maddeler.' },
      { name: 'Mavi', key: 'İnorganik maddeler ve metaller.' },
    ],
    tip: 'Tonlar cihaz üreticisine göre değişebilir.',
    ref: 'ÖGG Temel Eğitim · Güvenlik Sistem ve Cihazları', match: 'x-?\\s?ray|renk',
  },
];

function text(q: Question): string {
  return `${q.q} ${q.o[0]}`.toLocaleLowerCase('tr');
}

/** Bir gruba ait sorular: aynı dersten, soru veya şıklarında grubun ifadesi geçenler. */
export function confusableQuestions(c: Confusable, bank: Question[]): Question[] {
  const re = new RegExp(c.match, 'i');
  return bank.filter((q) => q.topic === c.topic && re.test(text(q)));
}
