import type { Question } from './types';
import { QUESTIONS_5188 } from './bank/k5188.ts';
import { HUKUK } from './bank/hukuk.ts';
import { TEDBIR } from './bank/tedbir.ts';
import { SISTEM } from './bank/sistem.ts';
import { KOLLUK } from './bank/kolluk.ts';
import { ILETISIM } from './bank/iletisim.ts';
import { KALABALIK } from './bank/kalabalik.ts';
import { KORUMA } from './bank/koruma.ts';
import { UYUSTURUCU } from './bank/uyusturucu.ts';
import { YANGIN } from './bank/yangin.ts';
import { ILKYARDIM } from './bank/ilkyardim.ts';
import { OLAYYERI } from './bank/olayyeri.ts';
import { MESLEK } from './bank/meslek.ts';
import { SILAH } from './bank/silah.ts';
import { DIFFICULTY_OVERRIDE } from './bank/difficulty.ts';

/** Tüm soru bankası. Ders dosyaları src/data/bank altında. */
export const QUESTIONS: Question[] = [
  ...QUESTIONS_5188, ...HUKUK, ...TEDBIR, ...SISTEM, ...KOLLUK, ...ILETISIM, ...KALABALIK,
  ...KORUMA, ...UYUSTURUCU, ...YANGIN, ...ILKYARDIM, ...OLAYYERI, ...MESLEK, ...SILAH,
].map((q) => {
  const d = DIFFICULTY_OVERRIDE[q.id];
  return d && d !== q.d ? { ...q, d } : q;
});
