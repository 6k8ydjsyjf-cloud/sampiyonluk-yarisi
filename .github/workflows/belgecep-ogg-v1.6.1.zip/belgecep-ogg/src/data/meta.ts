import type { ExamDate, Topic, TopicId, Variant } from './types';

export const APP_ID = 'com.noventra.belgecep.ogg';
export const APP_VERSION = '1.6.1';
export const PLAY_URL = `https://play.google.com/store/apps/details?id=${APP_ID}`;
export const PRO_PRODUCT_ID = 'belgecep_ogg_pro';
export const PRO_FALLBACK_PRICE = '249,99 ₺';

/** Gizlilik politikası adresi — GitHub Pages'te yayınladıktan sonra burayı güncelle. */
export const PRIVACY_URL = 'https://noventrastudios.github.io/belgecep/gizlilik.html';
export const EGM_EXAMS_URL = 'https://www.egm.gov.tr/ozelguvenlik';
/** Hata bildirimlerinin gideceği e-posta. Boş bırakılırsa bildirim paylaşım menüsüyle gönderilir. */
export const SUPPORT_EMAIL = '';

export const FREE_DENEME_PER_DAY = 2;
export const FREE_STUDY_PER_DAY = 10;
export const FREE_EXPLANATIONS = 3;

export const SECONDS_PER_QUESTION = 72; // 100 soru = 120 dk, 125 soru = 150 dk, 25 soru = 30 dk
export const PASS_SCORE = 60;
export const TOPIC_TEST_SIZE = 20;
export const SILAH_SECTION_SIZE = 25;

/** Seri: günlük hedef seçenekleri ve rozet eşikleri (gün) */
export const GOAL_OPTIONS = [10, 20, 30, 50] as const;
export const DEFAULT_GOAL = 10;
export const STREAK_MILESTONES = [3, 7, 14, 30, 60, 100] as const;

/** Bildirim: varsayılan saat, sınava kaç gün kala hatırlatılacağı, bir tekrar bildirimi için en az bekleyen soru */
export const DEFAULT_NOTIF_TIME = '20:00';
export const EXAM_REMIND_DAYS = [30, 7, 3, 1] as const;
export const REVIEW_NOTIFY_MIN = 5;
export const NOTIF_DAYS_AHEAD = 14;

/** Akıllı tekrar aralıkları (gün). Son kutuda da doğru cevaplanan soru "öğrenildi" sayılıp defterden çıkar. */
export const SRS_INTERVALS = [1, 3, 7, 14, 30] as const;

/** Yürürlükteki temel eğitim müfredatı: 12 ortak ders + silahlılar için Silah Bilgisi ve Atış */
export const TOPICS: Topic[] = [
  { id: 'hukuk', name: 'Özel Güvenlik Hukuku ve Kişi Hakları' },
  { id: 'tedbir', name: 'Güvenlik Tedbirleri' },
  { id: 'sistem', name: 'Güvenlik Sistem ve Cihazları' },
  { id: 'kolluk', name: 'Genel Kollukla İlişkiler' },
  { id: 'iletisim', name: 'Etkili İletişim' },
  { id: 'kalabalik', name: 'Kalabalık Yönetimi' },
  { id: 'koruma', name: 'Kişi Koruma' },
  { id: 'uyusturucu', name: 'Uyuşturucu Madde Bilgileri' },
  { id: 'yangin', name: 'Yangın Güvenliği ve Tabii Felaketlerde Müdahale' },
  { id: 'ilkyardim', name: 'İlk Yardım' },
  { id: 'olayyeri', name: 'Olay Yeri Koruma' },
  { id: 'meslek', name: 'Özel Güvenlikte Mesleki Davranış' },
  { id: 'silah', name: 'Silah Bilgisi ve Atış' },
];

export const COMMON_TOPICS: TopicId[] = TOPICS.filter((t) => t.id !== 'silah').map((t) => t.id);

/**
 * Deneme sınavında 100 ortak sorunun derslere dağılımı. Resmî bir dağılım ilan edilmediği için
 * müfredattaki ders ağırlığına göre yaklaşık olarak belirlenmiştir (toplam 100).
 */
export const DENEME_WEIGHTS: Record<Exclude<TopicId, 'silah'>, number> = {
  // Altı resmî kitapçığın (121-122. Temel, 97-98. Yenileme, iki tarihsiz kitapçık) ortalama ders dağılımı — bkz. data/exams.ts.
  // Mesleki Davranış bu kitapçıklarda ayrı bir ders bloğu olarak yer almadı; derste çalışılabilir, denemeye girmez.
  hukuk: 21, tedbir: 12, sistem: 6, kolluk: 8, iletisim: 13, kalabalik: 10,
  koruma: 8, uyusturucu: 2, yangin: 8, ilkyardim: 10, olayyeri: 2, meslek: 0,
};

export interface ExamFormat {
  variant: Variant;
  name: string;
  short: string;
  /** Ortak derslerden soru sayısı */
  common: number;
  /** Silah Bilgisi ve Atış soru sayısı */
  silah: number;
  /** Sınav süresi (dakika) */
  minutes: number;
  /** Baraj puanı (100 üzerinden; silahlıda her bölüm için ayrı ayrı) */
  pass: number;
  pro: boolean;
  desc: string;
}

/**
 * UYGULAMAYLA GELEN VARSAYILAN sınav formatları. Güncel değerler uzaktan yapılandırma dosyasından
 * (docs/ogg-config.json) okunur; bkz. src/lib/config.ts. Doğrudan bu diziyi değil, config.examFormat() kullanın.
 */
export const DEFAULT_EXAM_FORMATS: ExamFormat[] = [
  { variant: 'silahsiz', name: 'Silahsız deneme', short: 'Silahsız', common: 100, silah: 0, minutes: 120, pass: PASS_SCORE, pro: false, desc: '12 ortak dersten sorular' },
  { variant: 'silahli', name: 'Silahlı deneme', short: 'Silahlı', common: 100, silah: SILAH_SECTION_SIZE, minutes: 150, pass: PASS_SCORE, pro: true, desc: 'Ortak dersler + Silah Bilgisi ve Atış bölümü' },
  { variant: 'fark', name: 'Silah farkı sınavı', short: 'Silah farkı', common: 0, silah: SILAH_SECTION_SIZE, minutes: 30, pass: PASS_SCORE, pro: true, desc: 'Silahsız kimlikten silahlıya geçiş' },
];

/** Uygulamayla gelen varsayılan sınav takvimi; güncel takvim uzaktan yapılandırmadan gelir. */
export const DEFAULT_EXAM_DATES: ExamDate[] = [
  { name: '124. Dönem Temel Eğitim Sınavı', date: '2026-12-27' },
];

/** Uzaktan yapılandırma dosyasının adresi (GitHub Pages). Yayınladıktan sonra kendi adresinle güncelle. */
export const CONFIG_URL = 'https://noventrastudios.github.io/belgecep/ogg-config.json';

export const DIFFICULTY_LABEL = ['', 'Kolay', 'Orta', 'Zor'] as const;

export function topicName(id: string): string {
  return TOPICS.find((t) => t.id === id)?.name ?? id;
}
