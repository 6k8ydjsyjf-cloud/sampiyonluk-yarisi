import type { TopicId } from './types';

/**
 * Cep mevzuatı: görevde ve sınavda en çok bakılan hükümlerin kısa, kendi cümlelerimizle özeti.
 * Kanun metninin yerine geçmez; her kartta dayanak madde yazılıdır. Güncel metin: mevzuat.gov.tr
 */
export interface LawCard {
  id: string;
  title: string;
  ref: string;
  items: string[];
  /** Kartın altındaki "soru çöz" bağlantısı */
  practice?: { topic: TopicId; sub?: string };
  note?: string;
}

export const MEVZUAT_CHECKED = '17.11.2026';

export const LAW_CARDS: LawCard[] = [
  {
    id: 'yetkiler', title: 'Özel güvenlik görevlisinin yetkileri', ref: '5188 s. Kanun md. 7',
    items: [
      'a) Korunan alana girenleri duyarlı kapıdan geçirmek, üstlerini dedektörle aramak, eşyalarını X-ray veya benzeri cihazdan geçirmek.',
      'b) Toplantı, konser, spor müsabakası, sahne gösterisi, cenaze ve düğünde kimlik sormak; duyarlı kapı, dedektör ve X-ray kontrolü yapmak.',
      'c) CMK md. 90’a göre (suçüstü) yakalama.',
      'd) Görev alanında hakkında yakalama emri veya mahkûmiyet kararı olan kişiyi yakalamak ve aramak.',
      'e) Yangın, deprem gibi afetlerde ve imdat istenmesi hâlinde görev alanındaki iş yeri ve konutlara girmek.',
      'f) Hava meydanı, liman, gar, istasyon ve terminallerde (b) bendindeki kontrolleri yapmak.',
      'g) Aramada bulunan, suç teşkil eden, delil olabilecek veya tehlike doğurabilecek eşyayı, genel kolluğa derhal bildirmek şartıyla emanete almak.',
      'h) Terk edilmiş veya bulunmuş eşyayı emanete almak.',
      'ı) Bir kişinin vücut veya sağlığına yönelik mevcut tehlikeyi önlemek için yakalama.',
      'j) Olay yerini ve delilleri korumak için CMK md. 168’e göre yakalama.',
      'k) TMK 981, BK 52 (bugün TBK 64), TCK 24 ve 25’e göre zor kullanma.',
    ],
    note: 'Gözaltına alma ve ifade alma yetkisi yoktur; yakalanan kişi genel kolluğa teslim edilir.',
    practice: { topic: 'hukuk', sub: 'Yetkiler ve sınırları' },
  },
  {
    id: 'gorev-alani', title: 'Görev alanı ve süresi', ref: '5188 s. Kanun md. 9',
    items: [
      'Yetkiler yalnızca görev süresi içinde ve görev alanında kullanılır.',
      'Silahlar görev alanı dışına çıkarılamaz.',
      'Şüpheli takibi, dışarıdan saldırıya karşı önlem, para ve değerli eşya nakli, cenaze töreni gibi güzergâh gerektiren işlerde güzergâh görev alanı sayılır.',
      'Zorunlu hâllerde görev alanı komisyon kararıyla genişletilebilir.',
      'Kişi korumada: korunan kişi yanındayken ülke geneli, yanında değilken izin verilen ilin sınırları.',
      'Zor kullanma ve yakalama gerektiren olaylar en hızlı şekilde genel kolluğa bildirilir; yakalanan kişi ve eşya genel kolluğa teslim edilir.',
    ],
    practice: { topic: 'hukuk', sub: 'Görev alanı ve süresi' },
  },
  {
    id: 'kimlik-karti', title: 'Kimlik kartı ve yenileme', ref: '5188 s. Kanun md. 12 · Yönetmelik md. 34',
    items: [
      'Kimlik kartını valilik verir; kartta silahlı veya silahsız olduğu yazar.',
      'Kart, görev alanında ve görev süresince yakaya, herkesin görebileceği şekilde takılır.',
      'Kimlik kartı olmayan görevli md. 7’deki yetkileri kullanamaz.',
      'Kart beş yıl geçerlidir; yenilemek için beş yılda bir yenileme eğitimi alıp sınavı geçmek gerekir.',
      'İlk kartın geçerlilik süresi, başarılı olunan sınav tarihine beş yıl eklenerek belirlenir.',
      'Göreve başlayan ve görevden ayrılan görevliler işveren tarafından 15 gün içinde valiliğe bildirilir.',
    ],
    practice: { topic: 'hukuk', sub: 'Kimlik kartı ve çalışma izni' },
  },
  {
    id: 'silah', title: 'Silah bulundurma ve taşıma', ref: '5188 s. Kanun md. 8',
    items: [
      'Hangi hizmette ne tür ve ne kadar silah bulundurulacağına özel güvenlik komisyonu karar verir.',
      'Eğitim ve öğretim kurumları, sağlık tesisleri, talih oyunları işletmeleri ve içkili yerlerde silahlı özel güvenlik görevlisi çalıştırılamaz.',
      'Toplantı, spor müsabakası, sahne gösterisi ve benzeri etkinliklerde görevliler silahlı görev yapamaz.',
      'Silah ve teçhizatı hizmeti alan kişi veya kuruluş temin eder; özel güvenlik şirketleri kural olarak silah alamaz ve bulunduramaz.',
    ],
    practice: { topic: 'hukuk', sub: 'Silah bulundurma ve taşıma' },
  },
  {
    id: 'sartlar', title: 'Görevli olma şartları', ref: '5188 s. Kanun md. 10',
    items: [
      'Türkiye Cumhuriyeti vatandaşı olmak.',
      'Silahsız görev için en az sekiz yıllık ilköğretim veya ortaokul; silahlı görev için en az lise veya dengi okul mezunu olmak.',
      '18 yaşını doldurmuş olmak.',
      'Kanunda sayılan adli sicil şartlarını taşımak (kasıtlı suçtan bir yıl veya daha fazla hapis cezası almamış olmak vb.).',
      'Görevi yapmaya engel bedensel veya zihinsel hastalığı bulunmamak.',
      'Özel güvenlik temel eğitimini başarıyla tamamlamış olmak.',
      'Güvenlik soruşturmasının olumlu sonuçlanması.',
    ],
    practice: { topic: 'hukuk', sub: 'Görevlide aranan şartlar' },
  },
  {
    id: 'egitim', title: 'Eğitim süreleri', ref: '5188 s. Kanun md. 14',
    items: [
      'Temel eğitim en az 120 ders saatidir; teorik, pratik ve silah eğitiminden oluşur.',
      'Yenileme eğitimi en az 60 ders saatidir.',
      'Güvenlikle ilgili fakülte, yüksekokul veya meslek yüksekokulu mezunları, silah eğitimi dışında temel eğitimden muaftır.',
      'Genel kolluk veya MİT’ten emekli olanlar ya da en az beş yıl çalışıp kendi isteğiyle ayrılanlar temel eğitim ve öğrenim şartından muaftır.',
    ],
    practice: { topic: 'hukuk', sub: 'Eğitim' },
  },
  {
    id: 'sinav', title: 'Sınavda başarı ve puanlama', ref: 'Yönetmelik md. 39 (RG 04.07.2025)',
    items: [
      'Yazılı sınavın birinci kısmı (100 genel soru), ikinci kısmı (25 silah bilgisi sorusu) ve uygulamalı atış sınavı ayrı ayrı 100 puan üzerinden değerlendirilir.',
      'Silahsız aday yalnızca birinci kısma girer; en az 60 puan alan başarılı sayılır.',
      'Silahlı aday, yazılı sınavın iki kısmından ve uygulamalı sınavdan ayrı ayrı en az 60 almak zorundadır.',
      'Sınav puanı: birinci kısmın %50’si + ikinci kısmın %25’i + uygulamalı sınavın %25’i.',
      'Sınav süresi: silahsız 120 dakika, silahlı 150 dakika, silah farkı 30 dakika (EGM sınav kılavuzu).',
    ],
    note: 'EGM sınav talimatı silah farkı sınavının değerlendirmesini ayrıca açıklayabilir; her dönemin kılavuzunu kontrol et.',
    practice: { topic: 'hukuk', sub: 'Eğitim' },
  },
  {
    id: 'calisma', title: 'Çalışma süreleri ve fazla mesai', ref: '4857 s. İş Kanunu md. 41, 46, 63, 68, 69',
    items: [
      'Haftalık çalışma süresi en çok 45 saattir (md. 63).',
      'Fazla çalışmanın her saati, normal saat ücretinin yüzde elli fazlasıyla ödenir (md. 41).',
      'İşçi isterse her fazla çalışma saati için ücret yerine 1 saat 30 dakika serbest zaman kullanabilir; bu süre altı ay içinde kullanılır (md. 41).',
      'Yıllık fazla çalışma en çok 270 saattir (md. 41).',
      'Gece çalışması kural olarak 7,5 saati geçemez (md. 69).',
      'Ara dinlenme: 4 saate kadar 15 dakika, 4–7,5 saat arası yarım saat, 7,5 saatten uzun işlerde 1 saat (md. 68).',
      'Yedi günlük dönemde kesintisiz en az 24 saat hafta tatili verilir (md. 46).',
    ],
    practice: { topic: 'hukuk', sub: 'Çalışma hayatı' },
  },
];
