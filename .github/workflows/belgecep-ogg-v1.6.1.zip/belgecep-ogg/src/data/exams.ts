import type { TopicId } from './types';

/**
 * Geçmiş sınav analizi — EGM Özel Güvenlik Denetleme Başkanlığının yayımladığı kitapçıklardan.
 * Her kitapçıktaki 100 ortak soru tek tek okunup uygulamadaki 12 ortak derse elle atanmıştır.
 * Soruların METNİ uygulamada YOKTUR; yalnızca ders dağılımı tutulur. Bu dosya soru bankasından ayrıdır.
 * Yeni kitapçık eklemek: dağılımı aynı yöntemle çıkarıp listeye ekle; toplam ortak soru sayısı `common` olmalı.
 */
export type CommonTopic = Exclude<TopicId, 'silah'>;

export interface PastExam {
  id: string;
  name: string;
  short: string;
  /** Kitapçıkta yazan sınav tarihi (YYYY-AA-GG); kitapçıkta tarih yoksa null */
  date: string | null;
  kind: 'temel' | 'yenileme';
  group: 'A' | 'B';
  common: number;
  silah: number;
  dist: Record<CommonTopic, number>;
  /** Eski müfredatta ayrı başlığı olmayan yeni modüllerden gelen soru sayısı (ÖGDB, problem çözme, grup, müdahale, tutanak) */
  newModules: number;
}

export const PAST_EXAMS: PastExam[] = [
  { id: 't122a', name: '122. Dönem Temel Eğitim', short: '122. Temel', date: '2026-08-29', kind: 'temel', group: 'A', common: 100, silah: 25,
    dist: { hukuk: 21, tedbir: 13, sistem: 5, kolluk: 6, iletisim: 13, kalabalik: 11, koruma: 8, uyusturucu: 2, yangin: 8, ilkyardim: 10, olayyeri: 3, meslek: 0 },
    newModules: 12 },
  { id: 'y98a', name: '98. Dönem Yenileme Eğitimi', short: '98. Yenileme', date: '2026-08-29', kind: 'yenileme', group: 'A', common: 100, silah: 25,
    dist: { hukuk: 21, tedbir: 12, sistem: 6, kolluk: 7, iletisim: 13, kalabalik: 11, koruma: 8, uyusturucu: 2, yangin: 8, ilkyardim: 10, olayyeri: 2, meslek: 0 },
    newModules: 11 },
  { id: 't121a', name: '121. Dönem Temel Eğitim', short: '121. Temel', date: '2026-07-05', kind: 'temel', group: 'A', common: 100, silah: 25,
    dist: { hukuk: 21, tedbir: 12, sistem: 4, kolluk: 9, iletisim: 12, kalabalik: 11, koruma: 9, uyusturucu: 2, yangin: 8, ilkyardim: 10, olayyeri: 2, meslek: 0 },
    newModules: 18 },
  { id: 'y97a', name: '97. Dönem Yenileme Eğitimi', short: '97. Yenileme', date: '2026-07-05', kind: 'yenileme', group: 'A', common: 100, silah: 25,
    dist: { hukuk: 23, tedbir: 12, sistem: 5, kolluk: 7, iletisim: 12, kalabalik: 12, koruma: 7, uyusturucu: 2, yangin: 8, ilkyardim: 10, olayyeri: 2, meslek: 0 },
    newModules: 17 },
  { id: 't2026m-b', name: 'Temel Eğitim (B kitapçığı, tarihsiz)', short: 'Temel B (tarihsiz)', date: null, kind: 'temel', group: 'B', common: 100, silah: 25,
    dist: { hukuk: 19, tedbir: 14, sistem: 6, kolluk: 9, iletisim: 16, kalabalik: 7, koruma: 7, uyusturucu: 2, yangin: 9, ilkyardim: 9, olayyeri: 2, meslek: 0 },
    newModules: 9 },
  { id: 'y2026m-a', name: 'Yenileme Eğitimi (A kitapçığı, tarihsiz)', short: 'Yenileme A (tarihsiz)', date: null, kind: 'yenileme', group: 'A', common: 100, silah: 25,
    dist: { hukuk: 20, tedbir: 11, sistem: 8, kolluk: 8, iletisim: 14, kalabalik: 7, koruma: 9, uyusturucu: 2, yangin: 8, ilkyardim: 11, olayyeri: 2, meslek: 0 },
    newModules: 8 },];

export interface FrequentTopic {
  label: string;
  topic: CommonTopic;
  /** Bankadaki alt konu; yoksa dersin tamamı çalışılır */
  sub?: string;
  /** Kaç kitapçıkta geçtiği */
  exams: number;
  /** Altı kitapçıkta yaklaşık toplam soru */
  approx: number;
}

/** Altı kitapçıkta anahtar kelime taramasıyla sayılan, en sık tekrar eden konular (yaklaşık). */
export const FREQUENT_TOPICS: FrequentTopic[] = [
  { label: 'Özel güvenlik görevlisinin yetkileri ve sınırları', topic: 'hukuk', sub: 'Yetkiler ve sınırları', exams: 6, approx: 55 },
  { label: 'Kontrol noktaları ve giriş-çıkış kontrolü', topic: 'tedbir', sub: 'Giriş-çıkış kontrolü', exams: 6, approx: 21 },
  { label: 'Genel kolluk – özel kolluk ayrımı', topic: 'kolluk', sub: 'Genel kolluk kavramı', exams: 6, approx: 20 },
  { label: 'Devriye yöntemleri ve görevleri', topic: 'tedbir', sub: 'Devriye hizmetleri', exams: 6, approx: 19 },
  { label: 'Uyuşturucu maddeler ve kullanım belirtileri', topic: 'uyusturucu', exams: 6, approx: 18 },
  { label: 'Grup türleri ve grup gelişim aşamaları', topic: 'kalabalik', sub: 'Grup gelişim aşamaları', exams: 6, approx: 17 },
  { label: 'Kalabalık türleri ve panik', topic: 'kalabalik', sub: 'Kalabalık türleri', exams: 6, approx: 16 },
  { label: 'Araçlı ve yaya koruma düzenleri', topic: 'koruma', exams: 6, approx: 12 },
  { label: 'Yangın söndürme maddeleri ve yöntemleri', topic: 'yangin', exams: 6, approx: 10 },
  { label: 'Yakalama ve genel kolluğa teslim', topic: 'hukuk', sub: 'Yakalama', exams: 6, approx: 9 },
  { label: 'Empati ve sempati', topic: 'iletisim', sub: 'Empati', exams: 5, approx: 9 },
  { label: 'İletişim süreci (kodlama, kanal, geri bildirim)', topic: 'iletisim', sub: 'İletişim süreci', exams: 5, approx: 9 },
  { label: 'Temel hak ve özgürlükler', topic: 'hukuk', sub: 'Temel hak ve özgürlükler', exams: 5, approx: 8 },
  { label: 'Problem çözme teknikleri (PUKO, altı şapka)', topic: 'iletisim', sub: 'Problem çözme', exams: 4, approx: 8 },
  { label: 'Çalışma hayatı (fazla çalışma, haftalık süre)', topic: 'hukuk', sub: 'Çalışma hayatı', exams: 5, approx: 7 },
  { label: 'ÖGDB projeleri (KAAN, ÖGNET, PATBİS)', topic: 'kolluk', sub: 'ÖGDB projeleri', exams: 3, approx: 6 },
];

/** Altı kitapçığın ortalama ders dağılımı (100 ortak soruya yuvarlanmış). */
export function averageDist(exams: PastExam[] = PAST_EXAMS): Record<CommonTopic, number> {
  const keys = Object.keys(exams[0]?.dist ?? {}) as CommonTopic[];
  const out = {} as Record<CommonTopic, number>;
  for (const k of keys) out[k] = exams.reduce((a, e) => a + e.dist[k] / e.common, 0) / Math.max(1, exams.length);
  return out;
}

export function pastExam(id: string): PastExam | undefined {
  return PAST_EXAMS.find((e) => e.id === id);
}
