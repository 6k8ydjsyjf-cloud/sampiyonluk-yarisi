// Soru bankası doğrulayıcı — `npm run validate`. Hata varsa build durur.
import { QUESTIONS } from '../src/data/questions.ts';

const TOPICS = new Set(['hukuk', 'tedbir', 'sistem', 'kolluk', 'iletisim', 'kalabalik', 'koruma', 'uyusturucu', 'yangin', 'ilkyardim', 'olayyeri', 'meslek', 'silah']);
const errors = [];
const ids = new Set();
const texts = new Set();

for (const [i, q] of QUESTIONS.entries()) {
  const where = `#${i + 1} (${q?.id ?? 'kimliksiz'})`;
  if (!q || typeof q !== 'object') { errors.push(`${where}: geçersiz kayıt`); continue; }
  if (typeof q.id !== 'string' || !/^[a-z0-9]+-\d{3,}$/.test(q.id)) errors.push(`${where}: kimlik biçimi hatalı`);
  if (ids.has(q.id)) errors.push(`${where}: kimlik tekrar ediyor`);
  ids.add(q.id);
  if (!TOPICS.has(q.topic)) errors.push(`${where}: konu geçersiz (${q.topic})`);
  if (typeof q.q !== 'string' || q.q.trim().length < 8) errors.push(`${where}: soru metni çok kısa`);
  const norm = String(q.q).trim().toLocaleLowerCase('tr');
  if (texts.has(norm)) errors.push(`${where}: aynı soru metni tekrar ediyor`);
  texts.add(norm);
  if (!Array.isArray(q.o) || q.o.length !== 5) errors.push(`${where}: tam olarak 5 şık olmalı`);
  else {
    const seen = new Set();
    q.o.forEach((o, j) => {
      if (typeof o !== 'string' || o.trim().length === 0) errors.push(`${where}: ${j + 1}. şık boş`);
      const k = String(o).trim().toLocaleLowerCase('tr');
      if (seen.has(k)) errors.push(`${where}: şıklar tekrar ediyor ("${o}")`);
      seen.add(k);
      if (/hepsi|hiçbiri|yukarıdakiler/i.test(String(o))) errors.push(`${where}: "hepsi/hiçbiri" tipi şık karıştırmayla uyumsuz`);
    });
  }
  if (typeof q.e !== 'string' || q.e.trim().length < 15) errors.push(`${where}: açıklama eksik`);
  if (typeof q.ref !== 'string' || q.ref.trim().length < 3) errors.push(`${where}: dayanak eksik`);
  if (q.topic === 'hukuk' && !/md\.\s*\d+/.test(q.ref)) errors.push(`${where}: hukuk sorusunda madde (md. X) dayanağı zorunlu`);
  if (typeof q.sub !== 'string' || q.sub.trim().length < 2) errors.push(`${where}: alt konu eksik`);
  if (![1, 2, 3].includes(q.d)) errors.push(`${where}: zorluk 1-3 olmalı`);
  if (typeof q.checked !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(q.checked)) errors.push(`${where}: doğrulama tarihi eksik`);
}

const byTopic = {};
for (const q of QUESTIONS) byTopic[q.topic] = (byTopic[q.topic] ?? 0) + 1;

// Uyarı: doğru cevabın en uzun şık olma oranı çok yüksekse kullanıcı kalıbı yakalayabilir
const longest = QUESTIONS.filter((q) => q.o[0].length >= Math.max(...q.o.map((o) => o.length))).length;
const longestPct = Math.round((longest / QUESTIONS.length) * 100);

if (errors.length > 0) {
  console.error(`Soru bankası doğrulaması BAŞARISIZ (${errors.length} hata):`);
  for (const e of errors) console.error(' - ' + e);
  process.exit(1);
}
console.log(`Soru bankası geçerli: ${QUESTIONS.length} soru`, byTopic);
console.log(`Bilgi: doğru cevabın en uzun şık olduğu soru oranı %${longestPct}`);
